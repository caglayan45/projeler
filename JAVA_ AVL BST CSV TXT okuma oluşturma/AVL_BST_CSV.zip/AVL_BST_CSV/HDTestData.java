package AVL_BST_CSV;

public class HDTestData {

    String serialNumber,model,capacityBytes;
    int powerOnHours;

    public HDTestData(String serialNumber,String model,String capacityBytes,int powerOnHours){
        this.serialNumber = serialNumber;
        this.model = model;
        this.capacityBytes = capacityBytes;
        this.powerOnHours = powerOnHours;
    }

}
