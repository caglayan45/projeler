﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnOgrtDers = New System.Windows.Forms.Button()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.btnOgretmenleriGetir = New System.Windows.Forms.Button()
        Me.RadioButtonTumBilgiler = New System.Windows.Forms.RadioButton()
        Me.RadioButtonArananOgrtNo = New System.Windows.Forms.RadioButton()
        Me.btnPersonel = New System.Windows.Forms.Button()
        Me.btnPersonelMaasHesap = New System.Windows.Forms.Button()
        Me.btnPersonelGoruntule = New System.Windows.Forms.Button()
        Me.btnPersonelEkle = New System.Windows.Forms.Button()
        Me.btnApartman = New System.Windows.Forms.Button()
        Me.btnApartmanSakiniBul = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnOgrtDers
        '
        Me.btnOgrtDers.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.btnOgrtDers.Location = New System.Drawing.Point(12, 12)
        Me.btnOgrtDers.Name = "btnOgrtDers"
        Me.btnOgrtDers.Size = New System.Drawing.Size(245, 34)
        Me.btnOgrtDers.TabIndex = 0
        Me.btnOgrtDers.Text = "Öğretmenler ve Dersler"
        Me.btnOgrtDers.UseVisualStyleBackColor = True
        '
        'ListBox1
        '
        Me.ListBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 16
        Me.ListBox1.Location = New System.Drawing.Point(508, 12)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(280, 420)
        Me.ListBox1.TabIndex = 1
        '
        'btnOgretmenleriGetir
        '
        Me.btnOgretmenleriGetir.Enabled = False
        Me.btnOgretmenleriGetir.Location = New System.Drawing.Point(12, 75)
        Me.btnOgretmenleriGetir.Name = "btnOgretmenleriGetir"
        Me.btnOgretmenleriGetir.Size = New System.Drawing.Size(245, 23)
        Me.btnOgretmenleriGetir.TabIndex = 2
        Me.btnOgretmenleriGetir.Text = "Öğretmenleri Getir"
        Me.btnOgretmenleriGetir.UseVisualStyleBackColor = True
        '
        'RadioButtonTumBilgiler
        '
        Me.RadioButtonTumBilgiler.AutoSize = True
        Me.RadioButtonTumBilgiler.Checked = True
        Me.RadioButtonTumBilgiler.Location = New System.Drawing.Point(12, 52)
        Me.RadioButtonTumBilgiler.Name = "RadioButtonTumBilgiler"
        Me.RadioButtonTumBilgiler.Size = New System.Drawing.Size(106, 17)
        Me.RadioButtonTumBilgiler.TabIndex = 3
        Me.RadioButtonTumBilgiler.TabStop = True
        Me.RadioButtonTumBilgiler.Text = "Tüm Öğretmenler"
        Me.RadioButtonTumBilgiler.UseVisualStyleBackColor = True
        '
        'RadioButtonArananOgrtNo
        '
        Me.RadioButtonArananOgrtNo.AutoSize = True
        Me.RadioButtonArananOgrtNo.Location = New System.Drawing.Point(124, 52)
        Me.RadioButtonArananOgrtNo.Name = "RadioButtonArananOgrtNo"
        Me.RadioButtonArananOgrtNo.Size = New System.Drawing.Size(125, 17)
        Me.RadioButtonArananOgrtNo.TabIndex = 4
        Me.RadioButtonArananOgrtNo.Text = "Aranan Öğretmen No"
        Me.RadioButtonArananOgrtNo.UseVisualStyleBackColor = True
        '
        'btnPersonel
        '
        Me.btnPersonel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.btnPersonel.Location = New System.Drawing.Point(12, 160)
        Me.btnPersonel.Name = "btnPersonel"
        Me.btnPersonel.Size = New System.Drawing.Size(245, 34)
        Me.btnPersonel.TabIndex = 5
        Me.btnPersonel.Text = "Personeller"
        Me.btnPersonel.UseVisualStyleBackColor = True
        '
        'btnPersonelMaasHesap
        '
        Me.btnPersonelMaasHesap.Enabled = False
        Me.btnPersonelMaasHesap.Location = New System.Drawing.Point(12, 200)
        Me.btnPersonelMaasHesap.Name = "btnPersonelMaasHesap"
        Me.btnPersonelMaasHesap.Size = New System.Drawing.Size(245, 23)
        Me.btnPersonelMaasHesap.TabIndex = 6
        Me.btnPersonelMaasHesap.Text = "Maaşları Hesapla"
        Me.btnPersonelMaasHesap.UseVisualStyleBackColor = True
        '
        'btnPersonelGoruntule
        '
        Me.btnPersonelGoruntule.Enabled = False
        Me.btnPersonelGoruntule.Location = New System.Drawing.Point(12, 229)
        Me.btnPersonelGoruntule.Name = "btnPersonelGoruntule"
        Me.btnPersonelGoruntule.Size = New System.Drawing.Size(245, 23)
        Me.btnPersonelGoruntule.TabIndex = 7
        Me.btnPersonelGoruntule.Text = "Personelleri Görüntüle"
        Me.btnPersonelGoruntule.UseVisualStyleBackColor = True
        '
        'btnPersonelEkle
        '
        Me.btnPersonelEkle.Enabled = False
        Me.btnPersonelEkle.Location = New System.Drawing.Point(12, 258)
        Me.btnPersonelEkle.Name = "btnPersonelEkle"
        Me.btnPersonelEkle.Size = New System.Drawing.Size(245, 23)
        Me.btnPersonelEkle.TabIndex = 8
        Me.btnPersonelEkle.Text = "Personel Ekle"
        Me.btnPersonelEkle.UseVisualStyleBackColor = True
        '
        'btnApartman
        '
        Me.btnApartman.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.btnApartman.Location = New System.Drawing.Point(12, 328)
        Me.btnApartman.Name = "btnApartman"
        Me.btnApartman.Size = New System.Drawing.Size(245, 34)
        Me.btnApartman.TabIndex = 9
        Me.btnApartman.Text = "Apartman"
        Me.btnApartman.UseVisualStyleBackColor = True
        '
        'btnApartmanSakiniBul
        '
        Me.btnApartmanSakiniBul.Enabled = False
        Me.btnApartmanSakiniBul.Location = New System.Drawing.Point(12, 368)
        Me.btnApartmanSakiniBul.Name = "btnApartmanSakiniBul"
        Me.btnApartmanSakiniBul.Size = New System.Drawing.Size(245, 23)
        Me.btnApartmanSakiniBul.TabIndex = 10
        Me.btnApartmanSakiniBul.Text = "Apartman Sakini Getir"
        Me.btnApartmanSakiniBul.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnApartmanSakiniBul)
        Me.Controls.Add(Me.btnApartman)
        Me.Controls.Add(Me.btnPersonelEkle)
        Me.Controls.Add(Me.btnPersonelGoruntule)
        Me.Controls.Add(Me.btnPersonelMaasHesap)
        Me.Controls.Add(Me.btnPersonel)
        Me.Controls.Add(Me.RadioButtonArananOgrtNo)
        Me.Controls.Add(Me.RadioButtonTumBilgiler)
        Me.Controls.Add(Me.btnOgretmenleriGetir)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.btnOgrtDers)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnOgrtDers As Button
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents btnOgretmenleriGetir As Button
    Friend WithEvents RadioButtonTumBilgiler As RadioButton
    Friend WithEvents RadioButtonArananOgrtNo As RadioButton
    Friend WithEvents btnPersonel As Button
    Friend WithEvents btnPersonelMaasHesap As Button
    Friend WithEvents btnPersonelGoruntule As Button
    Friend WithEvents btnPersonelEkle As Button
    Friend WithEvents btnApartman As Button
    Friend WithEvents btnApartmanSakiniBul As Button
End Class
