﻿namespace ManavOtomasyonuTxt
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tabControlSiparisVerUrunEkle = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtUrunSilAdi = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtUrunSilFiyati = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnUrunSil = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtUrunGuncelleAdi = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtUrunGuncelleFiyati = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnUrunGuncelle = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtUrunEkleUrunAdi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtUrunEkleBirimFiyati = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnUrunEkle = new System.Windows.Forms.Button();
            this.btnSepettenCikar = new System.Windows.Forms.Button();
            this.btnSiparisVer = new System.Windows.Forms.Button();
            this.txtSepetToplam = new System.Windows.Forms.TextBox();
            this.checkedListBoxSepet = new System.Windows.Forms.CheckedListBox();
            this.dgvSiparisVer = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dgvSiparisler = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label11 = new System.Windows.Forms.Label();
            this.btnGuncelle = new System.Windows.Forms.Button();
            this.txtGuncelleSifre = new System.Windows.Forms.TextBox();
            this.txtGuncelleKullaniciAdi = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.btnCikis = new System.Windows.Forms.Button();
            this.panelGiris = new System.Windows.Forms.Panel();
            this.groupBoxGirisKayit = new System.Windows.Forms.GroupBox();
            this.linkLabelGirisKayit = new System.Windows.Forms.LinkLabel();
            this.btnGirisKayit = new System.Windows.Forms.Button();
            this.txtGirisKayitSifre = new System.Windows.Forms.TextBox();
            this.txtGirisKayitKullaniciAdi = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.tabControlSiparisVerUrunEkle.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSiparisVer)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSiparisler)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.panelGiris.SuspendLayout();
            this.groupBoxGirisKayit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 451);
            this.panel1.TabIndex = 0;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(152, 379);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(502, 23);
            this.progressBar1.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.progressBar1.TabIndex = 1;
            // 
            // timer1
            // 
            this.timer1.Interval = 50;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tabControlSiparisVerUrunEkle
            // 
            this.tabControlSiparisVerUrunEkle.Controls.Add(this.tabPage1);
            this.tabControlSiparisVerUrunEkle.Controls.Add(this.tabPage2);
            this.tabControlSiparisVerUrunEkle.Controls.Add(this.tabPage3);
            this.tabControlSiparisVerUrunEkle.Location = new System.Drawing.Point(0, 0);
            this.tabControlSiparisVerUrunEkle.Name = "tabControlSiparisVerUrunEkle";
            this.tabControlSiparisVerUrunEkle.SelectedIndex = 0;
            this.tabControlSiparisVerUrunEkle.Size = new System.Drawing.Size(800, 451);
            this.tabControlSiparisVerUrunEkle.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.btnSepettenCikar);
            this.tabPage1.Controls.Add(this.btnSiparisVer);
            this.tabPage1.Controls.Add(this.txtSepetToplam);
            this.tabPage1.Controls.Add(this.checkedListBoxSepet);
            this.tabPage1.Controls.Add(this.dgvSiparisVer);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(792, 425);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Sipariş ver/Ürün Ekle";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtUrunSilAdi);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.txtUrunSilFiyati);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.btnUrunSil);
            this.groupBox3.Location = new System.Drawing.Point(368, 281);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(217, 118);
            this.groupBox3.TabIndex = 12;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Ürün Sil";
            // 
            // txtUrunSilAdi
            // 
            this.txtUrunSilAdi.Location = new System.Drawing.Point(77, 24);
            this.txtUrunSilAdi.Name = "txtUrunSilAdi";
            this.txtUrunSilAdi.ReadOnly = true;
            this.txtUrunSilAdi.Size = new System.Drawing.Size(125, 20);
            this.txtUrunSilAdi.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Ürün Adı : ";
            // 
            // txtUrunSilFiyati
            // 
            this.txtUrunSilFiyati.Location = new System.Drawing.Point(77, 48);
            this.txtUrunSilFiyati.Name = "txtUrunSilFiyati";
            this.txtUrunSilFiyati.ReadOnly = true;
            this.txtUrunSilFiyati.Size = new System.Drawing.Size(125, 20);
            this.txtUrunSilFiyati.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 51);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 13);
            this.label8.TabIndex = 5;
            this.label8.Text = "Birim Fiyatı : ";
            // 
            // btnUrunSil
            // 
            this.btnUrunSil.Location = new System.Drawing.Point(77, 74);
            this.btnUrunSil.Name = "btnUrunSil";
            this.btnUrunSil.Size = new System.Drawing.Size(125, 23);
            this.btnUrunSil.TabIndex = 6;
            this.btnUrunSil.Text = "Ürünü Sil";
            this.btnUrunSil.UseVisualStyleBackColor = true;
            this.btnUrunSil.Click += new System.EventHandler(this.btnUrunSil_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtUrunGuncelleAdi);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txtUrunGuncelleFiyati);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.btnUrunGuncelle);
            this.groupBox2.Location = new System.Drawing.Point(368, 143);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(217, 118);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Ürün Güncelle";
            // 
            // txtUrunGuncelleAdi
            // 
            this.txtUrunGuncelleAdi.Location = new System.Drawing.Point(77, 24);
            this.txtUrunGuncelleAdi.Name = "txtUrunGuncelleAdi";
            this.txtUrunGuncelleAdi.Size = new System.Drawing.Size(125, 20);
            this.txtUrunGuncelleAdi.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Ürün Adı : ";
            // 
            // txtUrunGuncelleFiyati
            // 
            this.txtUrunGuncelleFiyati.Location = new System.Drawing.Point(77, 48);
            this.txtUrunGuncelleFiyati.Name = "txtUrunGuncelleFiyati";
            this.txtUrunGuncelleFiyati.Size = new System.Drawing.Size(125, 20);
            this.txtUrunGuncelleFiyati.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 51);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Birim Fiyatı : ";
            // 
            // btnUrunGuncelle
            // 
            this.btnUrunGuncelle.Location = new System.Drawing.Point(77, 74);
            this.btnUrunGuncelle.Name = "btnUrunGuncelle";
            this.btnUrunGuncelle.Size = new System.Drawing.Size(125, 23);
            this.btnUrunGuncelle.TabIndex = 6;
            this.btnUrunGuncelle.Text = "Ürünü Güncelle";
            this.btnUrunGuncelle.UseVisualStyleBackColor = true;
            this.btnUrunGuncelle.Click += new System.EventHandler(this.btnUrunGuncelle_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtUrunEkleUrunAdi);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtUrunEkleBirimFiyati);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.btnUrunEkle);
            this.groupBox1.Location = new System.Drawing.Point(368, 7);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(217, 118);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ürün Ekleme";
            // 
            // txtUrunEkleUrunAdi
            // 
            this.txtUrunEkleUrunAdi.Location = new System.Drawing.Point(77, 24);
            this.txtUrunEkleUrunAdi.Name = "txtUrunEkleUrunAdi";
            this.txtUrunEkleUrunAdi.Size = new System.Drawing.Size(125, 20);
            this.txtUrunEkleUrunAdi.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Ürün Adı : ";
            // 
            // txtUrunEkleBirimFiyati
            // 
            this.txtUrunEkleBirimFiyati.Location = new System.Drawing.Point(77, 48);
            this.txtUrunEkleBirimFiyati.Name = "txtUrunEkleBirimFiyati";
            this.txtUrunEkleBirimFiyati.Size = new System.Drawing.Size(125, 20);
            this.txtUrunEkleBirimFiyati.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 51);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Birim Fiyatı : ";
            // 
            // btnUrunEkle
            // 
            this.btnUrunEkle.Location = new System.Drawing.Point(77, 74);
            this.btnUrunEkle.Name = "btnUrunEkle";
            this.btnUrunEkle.Size = new System.Drawing.Size(125, 23);
            this.btnUrunEkle.TabIndex = 6;
            this.btnUrunEkle.Text = "Ürün Ekle";
            this.btnUrunEkle.UseVisualStyleBackColor = true;
            this.btnUrunEkle.Click += new System.EventHandler(this.btnUrunEkle_Click);
            // 
            // btnSepettenCikar
            // 
            this.btnSepettenCikar.Location = new System.Drawing.Point(590, 357);
            this.btnSepettenCikar.Name = "btnSepettenCikar";
            this.btnSepettenCikar.Size = new System.Drawing.Size(193, 23);
            this.btnSepettenCikar.TabIndex = 9;
            this.btnSepettenCikar.Text = "Seçilenleri sepetten çıkar";
            this.btnSepettenCikar.UseVisualStyleBackColor = true;
            this.btnSepettenCikar.Click += new System.EventHandler(this.btnSepettenCikar_Click);
            // 
            // btnSiparisVer
            // 
            this.btnSiparisVer.Location = new System.Drawing.Point(590, 386);
            this.btnSiparisVer.Name = "btnSiparisVer";
            this.btnSiparisVer.Size = new System.Drawing.Size(193, 23);
            this.btnSiparisVer.TabIndex = 8;
            this.btnSiparisVer.Text = "Sipariş ver";
            this.btnSiparisVer.UseVisualStyleBackColor = true;
            this.btnSiparisVer.Click += new System.EventHandler(this.btnSiparisVer_Click);
            // 
            // txtSepetToplam
            // 
            this.txtSepetToplam.Location = new System.Drawing.Point(591, 331);
            this.txtSepetToplam.Name = "txtSepetToplam";
            this.txtSepetToplam.ReadOnly = true;
            this.txtSepetToplam.Size = new System.Drawing.Size(193, 20);
            this.txtSepetToplam.TabIndex = 7;
            this.txtSepetToplam.Text = "0";
            // 
            // checkedListBoxSepet
            // 
            this.checkedListBoxSepet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.checkedListBoxSepet.FormattingEnabled = true;
            this.checkedListBoxSepet.Location = new System.Drawing.Point(591, 6);
            this.checkedListBoxSepet.Name = "checkedListBoxSepet";
            this.checkedListBoxSepet.Size = new System.Drawing.Size(193, 308);
            this.checkedListBoxSepet.TabIndex = 1;
            // 
            // dgvSiparisVer
            // 
            this.dgvSiparisVer.BackgroundColor = System.Drawing.Color.White;
            this.dgvSiparisVer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSiparisVer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3});
            this.dgvSiparisVer.Location = new System.Drawing.Point(7, 7);
            this.dgvSiparisVer.Name = "dgvSiparisVer";
            this.dgvSiparisVer.ReadOnly = true;
            this.dgvSiparisVer.Size = new System.Drawing.Size(355, 412);
            this.dgvSiparisVer.TabIndex = 0;
            this.dgvSiparisVer.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSiparisVer_CellClick);
            this.dgvSiparisVer.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSiparisVer_CellDoubleClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Ürün Kodu";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 85;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Ürün Adı";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 120;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Birim Fiyatı(kg)";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.tabPage2.Controls.Add(this.dgvSiparisler);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(792, 425);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Siparişleri Görüntüle";
            // 
            // dgvSiparisler
            // 
            this.dgvSiparisler.BackgroundColor = System.Drawing.Color.White;
            this.dgvSiparisler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSiparisler.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.Column4,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
            this.dgvSiparisler.Location = new System.Drawing.Point(7, 7);
            this.dgvSiparisler.Name = "dgvSiparisler";
            this.dgvSiparisler.ReadOnly = true;
            this.dgvSiparisler.Size = new System.Drawing.Size(779, 412);
            this.dgvSiparisler.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Ürün Kodu";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 85;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Kullanıcı Adı";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 150;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Ürün Adı";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 150;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Toplam Fiyat";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.btnGuncelle);
            this.tabPage3.Controls.Add(this.txtGuncelleSifre);
            this.tabPage3.Controls.Add(this.txtGuncelleKullaniciAdi);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.btnCikis);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(792, 425);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Kullanıcı Bilgilerini Düzenle / Çıkış";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.Location = new System.Drawing.Point(262, 109);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(218, 17);
            this.label11.TabIndex = 10;
            this.label11.Text = "Kullanıcı adı, şifre değiştirme";
            // 
            // btnGuncelle
            // 
            this.btnGuncelle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnGuncelle.Location = new System.Drawing.Point(344, 207);
            this.btnGuncelle.Name = "btnGuncelle";
            this.btnGuncelle.Size = new System.Drawing.Size(153, 36);
            this.btnGuncelle.TabIndex = 9;
            this.btnGuncelle.Text = "Güncelle";
            this.btnGuncelle.UseVisualStyleBackColor = true;
            this.btnGuncelle.Click += new System.EventHandler(this.btnGuncelle_Click);
            // 
            // txtGuncelleSifre
            // 
            this.txtGuncelleSifre.Location = new System.Drawing.Point(344, 181);
            this.txtGuncelleSifre.Name = "txtGuncelleSifre";
            this.txtGuncelleSifre.Size = new System.Drawing.Size(153, 20);
            this.txtGuncelleSifre.TabIndex = 8;
            // 
            // txtGuncelleKullaniciAdi
            // 
            this.txtGuncelleKullaniciAdi.Location = new System.Drawing.Point(344, 155);
            this.txtGuncelleKullaniciAdi.Name = "txtGuncelleKullaniciAdi";
            this.txtGuncelleKullaniciAdi.Size = new System.Drawing.Size(153, 20);
            this.txtGuncelleKullaniciAdi.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.Location = new System.Drawing.Point(239, 186);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 15);
            this.label9.TabIndex = 6;
            this.label9.Text = "Şifre : ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.Location = new System.Drawing.Point(239, 156);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(99, 15);
            this.label10.TabIndex = 5;
            this.label10.Text = "Kullanıcı Adı : ";
            // 
            // btnCikis
            // 
            this.btnCikis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnCikis.Location = new System.Drawing.Point(665, 370);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(119, 46);
            this.btnCikis.TabIndex = 0;
            this.btnCikis.Text = "ÇIKIŞ";
            this.btnCikis.UseVisualStyleBackColor = true;
            this.btnCikis.Click += new System.EventHandler(this.btnCikis_Click);
            // 
            // panelGiris
            // 
            this.panelGiris.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panelGiris.Controls.Add(this.groupBoxGirisKayit);
            this.panelGiris.Location = new System.Drawing.Point(0, 0);
            this.panelGiris.Name = "panelGiris";
            this.panelGiris.Size = new System.Drawing.Size(800, 451);
            this.panelGiris.TabIndex = 2;
            // 
            // groupBoxGirisKayit
            // 
            this.groupBoxGirisKayit.Controls.Add(this.linkLabelGirisKayit);
            this.groupBoxGirisKayit.Controls.Add(this.btnGirisKayit);
            this.groupBoxGirisKayit.Controls.Add(this.txtGirisKayitSifre);
            this.groupBoxGirisKayit.Controls.Add(this.txtGirisKayitKullaniciAdi);
            this.groupBoxGirisKayit.Controls.Add(this.label2);
            this.groupBoxGirisKayit.Controls.Add(this.label1);
            this.groupBoxGirisKayit.Location = new System.Drawing.Point(232, 79);
            this.groupBoxGirisKayit.Name = "groupBoxGirisKayit";
            this.groupBoxGirisKayit.Size = new System.Drawing.Size(326, 273);
            this.groupBoxGirisKayit.TabIndex = 0;
            this.groupBoxGirisKayit.TabStop = false;
            this.groupBoxGirisKayit.Text = "Giriş Yap";
            // 
            // linkLabelGirisKayit
            // 
            this.linkLabelGirisKayit.AutoSize = true;
            this.linkLabelGirisKayit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.linkLabelGirisKayit.Location = new System.Drawing.Point(183, 189);
            this.linkLabelGirisKayit.Name = "linkLabelGirisKayit";
            this.linkLabelGirisKayit.Size = new System.Drawing.Size(48, 15);
            this.linkLabelGirisKayit.TabIndex = 5;
            this.linkLabelGirisKayit.TabStop = true;
            this.linkLabelGirisKayit.Text = "Kayıt Ol";
            this.linkLabelGirisKayit.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelGirisKayit_LinkClicked);
            // 
            // btnGirisKayit
            // 
            this.btnGirisKayit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnGirisKayit.Location = new System.Drawing.Point(139, 150);
            this.btnGirisKayit.Name = "btnGirisKayit";
            this.btnGirisKayit.Size = new System.Drawing.Size(153, 36);
            this.btnGirisKayit.TabIndex = 4;
            this.btnGirisKayit.Text = "Giriş Yap";
            this.btnGirisKayit.UseVisualStyleBackColor = true;
            this.btnGirisKayit.Click += new System.EventHandler(this.btnGirisKayit_Click);
            // 
            // txtGirisKayitSifre
            // 
            this.txtGirisKayitSifre.Location = new System.Drawing.Point(139, 124);
            this.txtGirisKayitSifre.Name = "txtGirisKayitSifre";
            this.txtGirisKayitSifre.Size = new System.Drawing.Size(153, 20);
            this.txtGirisKayitSifre.TabIndex = 3;
            this.txtGirisKayitSifre.UseSystemPasswordChar = true;
            // 
            // txtGirisKayitKullaniciAdi
            // 
            this.txtGirisKayitKullaniciAdi.Location = new System.Drawing.Point(139, 98);
            this.txtGirisKayitKullaniciAdi.Name = "txtGirisKayitKullaniciAdi";
            this.txtGirisKayitKullaniciAdi.Size = new System.Drawing.Size(153, 20);
            this.txtGirisKayitKullaniciAdi.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(34, 129);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Şifre : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(34, 99);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Kullanıcı Adı : ";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ManavOtomasyonuTxt.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(75, 23);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(654, 350);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tabControlSiparisVerUrunEkle);
            this.Controls.Add(this.panelGiris);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.tabControlSiparisVerUrunEkle.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSiparisVer)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSiparisler)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.panelGiris.ResumeLayout(false);
            this.groupBoxGirisKayit.ResumeLayout(false);
            this.groupBoxGirisKayit.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TabControl tabControlSiparisVerUrunEkle;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panelGiris;
        private System.Windows.Forms.GroupBox groupBoxGirisKayit;
        private System.Windows.Forms.TextBox txtGirisKayitSifre;
        private System.Windows.Forms.TextBox txtGirisKayitKullaniciAdi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnGirisKayit;
        private System.Windows.Forms.LinkLabel linkLabelGirisKayit;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dgvSiparisVer;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.CheckedListBox checkedListBoxSepet;
        private System.Windows.Forms.Button btnUrunEkle;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtUrunEkleBirimFiyati;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtUrunEkleUrunAdi;
        private System.Windows.Forms.Button btnSepettenCikar;
        private System.Windows.Forms.Button btnSiparisVer;
        private System.Windows.Forms.TextBox txtSepetToplam;
        private System.Windows.Forms.DataGridView dgvSiparisler;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtUrunSilAdi;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtUrunSilFiyati;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnUrunSil;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtUrunGuncelleAdi;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtUrunGuncelleFiyati;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnUrunGuncelle;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.Button btnCikis;
        private System.Windows.Forms.Button btnGuncelle;
        private System.Windows.Forms.TextBox txtGuncelleSifre;
        private System.Windows.Forms.TextBox txtGuncelleKullaniciAdi;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

