﻿namespace MatbaaUygulaması
{
    partial class loginForm
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxKullaniciAdi = new System.Windows.Forms.TextBox();
            this.textBoxSifre = new System.Windows.Forms.TextBox();
            this.buttonGiris = new System.Windows.Forms.Button();
            this.panelGiris = new System.Windows.Forms.Panel();
            this.panelProgresBar = new System.Windows.Forms.Panel();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.buttonKayıtOl = new System.Windows.Forms.Button();
            this.panelUygulama = new System.Windows.Forms.Panel();
            this.buttonKullaniciBilgileriGuncelle = new System.Windows.Forms.Button();
            this.textBoxKullaniciSifreGuncelle = new System.Windows.Forms.TextBox();
            this.textBoxKullaniciAdiGuncelle = new System.Windows.Forms.TextBox();
            this.panelSepet = new System.Windows.Forms.Panel();
            this.label1ToplamTutar = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxSepetMusteri = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.buttonSiparisiOnayla = new System.Windows.Forms.Button();
            this.buttonSeciliUrunleriSil = new System.Windows.Forms.Button();
            this.checkedListBoxSepet = new System.Windows.Forms.CheckedListBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridViewUrunler = new System.Windows.Forms.DataGridView();
            this.urun = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.birimFiyat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.siparisEkle = new System.Windows.Forms.DataGridViewButtonColumn();
            this.urunGuncelle = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label6 = new System.Windows.Forms.Label();
            this.panelUrunEkle = new System.Windows.Forms.Panel();
            this.buttonUrunSil = new System.Windows.Forms.Button();
            this.checkedListBoxUrunSil = new System.Windows.Forms.CheckedListBox();
            this.buttonUrunEkle = new System.Windows.Forms.Button();
            this.numUrunBirimFiyat = new System.Windows.Forms.NumericUpDown();
            this.textBoxUrunEkleAd = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dataGridViewSiparisler = new System.Windows.Forms.DataGridView();
            this.siparisId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.musteriAdi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.urunAdi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.urunAdedi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.siparisTutari = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.siparisSil = new System.Windows.Forms.DataGridViewButtonColumn();
            this.labelHosgeldiniz = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelGiris.SuspendLayout();
            this.panelProgresBar.SuspendLayout();
            this.panelUygulama.SuspendLayout();
            this.panelSepet.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUrunler)).BeginInit();
            this.panelUrunEkle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUrunBirimFiyat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSiparisler)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(381, 192);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Kullanıcı Adı :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(447, 225);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Şifre :";
            // 
            // textBoxKullaniciAdi
            // 
            this.textBoxKullaniciAdi.Location = new System.Drawing.Point(510, 197);
            this.textBoxKullaniciAdi.Name = "textBoxKullaniciAdi";
            this.textBoxKullaniciAdi.Size = new System.Drawing.Size(100, 20);
            this.textBoxKullaniciAdi.TabIndex = 2;
            this.textBoxKullaniciAdi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxSifre
            // 
            this.textBoxSifre.Location = new System.Drawing.Point(510, 230);
            this.textBoxSifre.Name = "textBoxSifre";
            this.textBoxSifre.PasswordChar = '*';
            this.textBoxSifre.Size = new System.Drawing.Size(100, 20);
            this.textBoxSifre.TabIndex = 3;
            this.textBoxSifre.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttonGiris
            // 
            this.buttonGiris.Location = new System.Drawing.Point(461, 265);
            this.buttonGiris.Name = "buttonGiris";
            this.buttonGiris.Size = new System.Drawing.Size(92, 22);
            this.buttonGiris.TabIndex = 4;
            this.buttonGiris.Text = "Giriş";
            this.buttonGiris.UseVisualStyleBackColor = true;
            this.buttonGiris.Click += new System.EventHandler(this.buttonGiris_Click);
            // 
            // panelGiris
            // 
            this.panelGiris.Controls.Add(this.panelProgresBar);
            this.panelGiris.Controls.Add(this.buttonKayıtOl);
            this.panelGiris.Controls.Add(this.label1);
            this.panelGiris.Controls.Add(this.label2);
            this.panelGiris.Controls.Add(this.buttonGiris);
            this.panelGiris.Controls.Add(this.textBoxKullaniciAdi);
            this.panelGiris.Controls.Add(this.textBoxSifre);
            this.panelGiris.Location = new System.Drawing.Point(12, 3);
            this.panelGiris.Name = "panelGiris";
            this.panelGiris.Size = new System.Drawing.Size(971, 546);
            this.panelGiris.TabIndex = 6;
            // 
            // panelProgresBar
            // 
            this.panelProgresBar.Controls.Add(this.pictureBox1);
            this.panelProgresBar.Controls.Add(this.progressBar1);
            this.panelProgresBar.Location = new System.Drawing.Point(0, 8);
            this.panelProgresBar.Name = "panelProgresBar";
            this.panelProgresBar.Size = new System.Drawing.Size(960, 526);
            this.panelProgresBar.TabIndex = 7;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(11, 491);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(938, 23);
            this.progressBar1.TabIndex = 6;
            // 
            // buttonKayıtOl
            // 
            this.buttonKayıtOl.Location = new System.Drawing.Point(461, 293);
            this.buttonKayıtOl.Name = "buttonKayıtOl";
            this.buttonKayıtOl.Size = new System.Drawing.Size(92, 22);
            this.buttonKayıtOl.TabIndex = 5;
            this.buttonKayıtOl.Text = "Kayıt Ol";
            this.buttonKayıtOl.UseVisualStyleBackColor = true;
            this.buttonKayıtOl.Click += new System.EventHandler(this.buttonKayıtOl_Click);
            // 
            // panelUygulama
            // 
            this.panelUygulama.Controls.Add(this.buttonKullaniciBilgileriGuncelle);
            this.panelUygulama.Controls.Add(this.textBoxKullaniciSifreGuncelle);
            this.panelUygulama.Controls.Add(this.textBoxKullaniciAdiGuncelle);
            this.panelUygulama.Controls.Add(this.panelSepet);
            this.panelUygulama.Controls.Add(this.panel1);
            this.panelUygulama.Controls.Add(this.panelUrunEkle);
            this.panelUygulama.Controls.Add(this.dataGridViewSiparisler);
            this.panelUygulama.Controls.Add(this.labelHosgeldiniz);
            this.panelUygulama.Location = new System.Drawing.Point(0, 0);
            this.panelUygulama.Name = "panelUygulama";
            this.panelUygulama.Size = new System.Drawing.Size(972, 563);
            this.panelUygulama.TabIndex = 6;
            // 
            // buttonKullaniciBilgileriGuncelle
            // 
            this.buttonKullaniciBilgileriGuncelle.Location = new System.Drawing.Point(312, 9);
            this.buttonKullaniciBilgileriGuncelle.Name = "buttonKullaniciBilgileriGuncelle";
            this.buttonKullaniciBilgileriGuncelle.Size = new System.Drawing.Size(75, 23);
            this.buttonKullaniciBilgileriGuncelle.TabIndex = 13;
            this.buttonKullaniciBilgileriGuncelle.Text = "Güncelle";
            this.buttonKullaniciBilgileriGuncelle.UseVisualStyleBackColor = true;
            this.buttonKullaniciBilgileriGuncelle.Click += new System.EventHandler(this.buttonKullaniciBilgileriGuncelle_Click);
            // 
            // textBoxKullaniciSifreGuncelle
            // 
            this.textBoxKullaniciSifreGuncelle.Location = new System.Drawing.Point(227, 11);
            this.textBoxKullaniciSifreGuncelle.Name = "textBoxKullaniciSifreGuncelle";
            this.textBoxKullaniciSifreGuncelle.Size = new System.Drawing.Size(79, 20);
            this.textBoxKullaniciSifreGuncelle.TabIndex = 12;
            this.textBoxKullaniciSifreGuncelle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxKullaniciAdiGuncelle
            // 
            this.textBoxKullaniciAdiGuncelle.Location = new System.Drawing.Point(142, 11);
            this.textBoxKullaniciAdiGuncelle.Name = "textBoxKullaniciAdiGuncelle";
            this.textBoxKullaniciAdiGuncelle.Size = new System.Drawing.Size(79, 20);
            this.textBoxKullaniciAdiGuncelle.TabIndex = 11;
            this.textBoxKullaniciAdiGuncelle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panelSepet
            // 
            this.panelSepet.BackColor = System.Drawing.Color.Red;
            this.panelSepet.Controls.Add(this.label1ToplamTutar);
            this.panelSepet.Controls.Add(this.label9);
            this.panelSepet.Controls.Add(this.textBoxSepetMusteri);
            this.panelSepet.Controls.Add(this.label8);
            this.panelSepet.Controls.Add(this.buttonSiparisiOnayla);
            this.panelSepet.Controls.Add(this.buttonSeciliUrunleriSil);
            this.panelSepet.Controls.Add(this.checkedListBoxSepet);
            this.panelSepet.Controls.Add(this.label7);
            this.panelSepet.Location = new System.Drawing.Point(397, 21);
            this.panelSepet.Name = "panelSepet";
            this.panelSepet.Size = new System.Drawing.Size(361, 220);
            this.panelSepet.TabIndex = 5;
            // 
            // label1ToplamTutar
            // 
            this.label1ToplamTutar.AutoSize = true;
            this.label1ToplamTutar.ForeColor = System.Drawing.SystemColors.Control;
            this.label1ToplamTutar.Location = new System.Drawing.Point(280, 35);
            this.label1ToplamTutar.Name = "label1ToplamTutar";
            this.label1ToplamTutar.Size = new System.Drawing.Size(0, 13);
            this.label1ToplamTutar.TabIndex = 12;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.Control;
            this.label9.Location = new System.Drawing.Point(229, 35);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(45, 13);
            this.label9.TabIndex = 11;
            this.label9.Text = "Toplam:";
            // 
            // textBoxSepetMusteri
            // 
            this.textBoxSepetMusteri.Location = new System.Drawing.Point(78, 31);
            this.textBoxSepetMusteri.Name = "textBoxSepetMusteri";
            this.textBoxSepetMusteri.Size = new System.Drawing.Size(145, 20);
            this.textBoxSepetMusteri.TabIndex = 10;
            this.textBoxSepetMusteri.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.SystemColors.Control;
            this.label8.Location = new System.Drawing.Point(18, 34);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 13);
            this.label8.TabIndex = 9;
            this.label8.Text = "Müşteri Adı";
            // 
            // buttonSiparisiOnayla
            // 
            this.buttonSiparisiOnayla.Location = new System.Drawing.Point(16, 186);
            this.buttonSiparisiOnayla.Name = "buttonSiparisiOnayla";
            this.buttonSiparisiOnayla.Size = new System.Drawing.Size(330, 23);
            this.buttonSiparisiOnayla.TabIndex = 8;
            this.buttonSiparisiOnayla.Text = "Siparişi Onayla";
            this.buttonSiparisiOnayla.UseVisualStyleBackColor = true;
            this.buttonSiparisiOnayla.Click += new System.EventHandler(this.buttonSiparisiOnayla_Click);
            // 
            // buttonSeciliUrunleriSil
            // 
            this.buttonSeciliUrunleriSil.Location = new System.Drawing.Point(16, 157);
            this.buttonSeciliUrunleriSil.Name = "buttonSeciliUrunleriSil";
            this.buttonSeciliUrunleriSil.Size = new System.Drawing.Size(330, 23);
            this.buttonSeciliUrunleriSil.TabIndex = 7;
            this.buttonSeciliUrunleriSil.Text = "Şeçili Ürünleri Sil";
            this.buttonSeciliUrunleriSil.UseVisualStyleBackColor = true;
            this.buttonSeciliUrunleriSil.Click += new System.EventHandler(this.buttonSeciliUrunleriSil_Click);
            // 
            // checkedListBoxSepet
            // 
            this.checkedListBoxSepet.FormattingEnabled = true;
            this.checkedListBoxSepet.Location = new System.Drawing.Point(16, 57);
            this.checkedListBoxSepet.Name = "checkedListBoxSepet";
            this.checkedListBoxSepet.Size = new System.Drawing.Size(330, 94);
            this.checkedListBoxSepet.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.SystemColors.Control;
            this.label7.Location = new System.Drawing.Point(155, 12);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 16);
            this.label7.TabIndex = 3;
            this.label7.Text = "Sepet";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.GreenYellow;
            this.panel1.Controls.Add(this.dataGridViewUrunler);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Location = new System.Drawing.Point(12, 43);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(379, 198);
            this.panel1.TabIndex = 4;
            // 
            // dataGridViewUrunler
            // 
            this.dataGridViewUrunler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewUrunler.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.urun,
            this.birimFiyat,
            this.siparisEkle,
            this.urunGuncelle});
            this.dataGridViewUrunler.Location = new System.Drawing.Point(3, 35);
            this.dataGridViewUrunler.Name = "dataGridViewUrunler";
            this.dataGridViewUrunler.Size = new System.Drawing.Size(372, 157);
            this.dataGridViewUrunler.TabIndex = 8;
            this.dataGridViewUrunler.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewUrunler_CellContentClick);
            // 
            // urun
            // 
            this.urun.HeaderText = "Ürün Adı";
            this.urun.Name = "urun";
            this.urun.Width = 80;
            // 
            // birimFiyat
            // 
            this.birimFiyat.HeaderText = "Birim Fiyatı";
            this.birimFiyat.Name = "birimFiyat";
            this.birimFiyat.Width = 80;
            // 
            // siparisEkle
            // 
            this.siparisEkle.HeaderText = "Sepete Ekle";
            this.siparisEkle.Name = "siparisEkle";
            this.siparisEkle.Text = "Sepete Ekle";
            this.siparisEkle.ToolTipText = "Sepete Ekle";
            this.siparisEkle.UseColumnTextForButtonValue = true;
            this.siparisEkle.Width = 80;
            // 
            // urunGuncelle
            // 
            this.urunGuncelle.HeaderText = "Güncelle";
            this.urunGuncelle.Name = "urunGuncelle";
            this.urunGuncelle.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.urunGuncelle.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.urunGuncelle.Text = "Güncelle";
            this.urunGuncelle.ToolTipText = "Güncelle";
            this.urunGuncelle.UseColumnTextForButtonValue = true;
            this.urunGuncelle.Width = 70;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(114, 10);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(144, 16);
            this.label6.TabIndex = 7;
            this.label6.Text = "Yeni Sipariş Oluştur";
            // 
            // panelUrunEkle
            // 
            this.panelUrunEkle.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panelUrunEkle.Controls.Add(this.buttonUrunSil);
            this.panelUrunEkle.Controls.Add(this.checkedListBoxUrunSil);
            this.panelUrunEkle.Controls.Add(this.buttonUrunEkle);
            this.panelUrunEkle.Controls.Add(this.numUrunBirimFiyat);
            this.panelUrunEkle.Controls.Add(this.textBoxUrunEkleAd);
            this.panelUrunEkle.Controls.Add(this.label5);
            this.panelUrunEkle.Controls.Add(this.label4);
            this.panelUrunEkle.Controls.Add(this.label3);
            this.panelUrunEkle.Location = new System.Drawing.Point(766, 21);
            this.panelUrunEkle.Name = "panelUrunEkle";
            this.panelUrunEkle.Size = new System.Drawing.Size(206, 220);
            this.panelUrunEkle.TabIndex = 3;
            // 
            // buttonUrunSil
            // 
            this.buttonUrunSil.Location = new System.Drawing.Point(11, 186);
            this.buttonUrunSil.Name = "buttonUrunSil";
            this.buttonUrunSil.Size = new System.Drawing.Size(184, 23);
            this.buttonUrunSil.TabIndex = 8;
            this.buttonUrunSil.Text = "Ürün Sil";
            this.buttonUrunSil.UseVisualStyleBackColor = true;
            this.buttonUrunSil.Click += new System.EventHandler(this.buttonUrunSil_Click);
            // 
            // checkedListBoxUrunSil
            // 
            this.checkedListBoxUrunSil.FormattingEnabled = true;
            this.checkedListBoxUrunSil.Location = new System.Drawing.Point(11, 131);
            this.checkedListBoxUrunSil.Name = "checkedListBoxUrunSil";
            this.checkedListBoxUrunSil.Size = new System.Drawing.Size(184, 49);
            this.checkedListBoxUrunSil.TabIndex = 7;
            // 
            // buttonUrunEkle
            // 
            this.buttonUrunEkle.Location = new System.Drawing.Point(63, 102);
            this.buttonUrunEkle.Name = "buttonUrunEkle";
            this.buttonUrunEkle.Size = new System.Drawing.Size(75, 23);
            this.buttonUrunEkle.TabIndex = 6;
            this.buttonUrunEkle.Text = "Ürün Ekle";
            this.buttonUrunEkle.UseVisualStyleBackColor = true;
            this.buttonUrunEkle.Click += new System.EventHandler(this.buttonUrunEkle_Click);
            // 
            // numUrunBirimFiyat
            // 
            this.numUrunBirimFiyat.DecimalPlaces = 2;
            this.numUrunBirimFiyat.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numUrunBirimFiyat.Location = new System.Drawing.Point(95, 73);
            this.numUrunBirimFiyat.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numUrunBirimFiyat.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numUrunBirimFiyat.Name = "numUrunBirimFiyat";
            this.numUrunBirimFiyat.Size = new System.Drawing.Size(100, 20);
            this.numUrunBirimFiyat.TabIndex = 5;
            this.numUrunBirimFiyat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numUrunBirimFiyat.ThousandsSeparator = true;
            this.numUrunBirimFiyat.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // textBoxUrunEkleAd
            // 
            this.textBoxUrunEkleAd.Location = new System.Drawing.Point(95, 45);
            this.textBoxUrunEkleAd.Name = "textBoxUrunEkleAd";
            this.textBoxUrunEkleAd.Size = new System.Drawing.Size(100, 20);
            this.textBoxUrunEkleAd.TabIndex = 4;
            this.textBoxUrunEkleAd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.Control;
            this.label5.Location = new System.Drawing.Point(12, 75);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Ürün Birim Fiyatı";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.Control;
            this.label4.Location = new System.Drawing.Point(12, 48);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Ürün Adı";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.SystemColors.Control;
            this.label3.Location = new System.Drawing.Point(41, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Yeni Ürün Ekle";
            // 
            // dataGridViewSiparisler
            // 
            this.dataGridViewSiparisler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSiparisler.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.siparisId,
            this.musteriAdi,
            this.urunAdi,
            this.urunAdedi,
            this.siparisTutari,
            this.siparisSil});
            this.dataGridViewSiparisler.Location = new System.Drawing.Point(12, 256);
            this.dataGridViewSiparisler.Name = "dataGridViewSiparisler";
            this.dataGridViewSiparisler.Size = new System.Drawing.Size(960, 290);
            this.dataGridViewSiparisler.TabIndex = 1;
            this.dataGridViewSiparisler.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewSiparisler_CellContentClick);
            // 
            // siparisId
            // 
            this.siparisId.HeaderText = "Sipariş Id";
            this.siparisId.Name = "siparisId";
            this.siparisId.ReadOnly = true;
            // 
            // musteriAdi
            // 
            this.musteriAdi.HeaderText = "Müşteri Adı";
            this.musteriAdi.Name = "musteriAdi";
            // 
            // urunAdi
            // 
            this.urunAdi.HeaderText = "Ürünler";
            this.urunAdi.Name = "urunAdi";
            this.urunAdi.ReadOnly = true;
            this.urunAdi.Width = 300;
            // 
            // urunAdedi
            // 
            this.urunAdedi.HeaderText = "Ürün Adetleri";
            this.urunAdedi.Name = "urunAdedi";
            this.urunAdedi.Width = 200;
            // 
            // siparisTutari
            // 
            this.siparisTutari.HeaderText = "Sipariş Tutarı";
            this.siparisTutari.Name = "siparisTutari";
            this.siparisTutari.ReadOnly = true;
            // 
            // siparisSil
            // 
            this.siparisSil.HeaderText = "Sipariş Sil";
            this.siparisSil.Name = "siparisSil";
            this.siparisSil.Text = "Sipariş Sil";
            this.siparisSil.ToolTipText = "Sipariş Sil";
            this.siparisSil.UseColumnTextForButtonValue = true;
            // 
            // labelHosgeldiniz
            // 
            this.labelHosgeldiniz.AutoSize = true;
            this.labelHosgeldiniz.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelHosgeldiniz.Location = new System.Drawing.Point(20, 14);
            this.labelHosgeldiniz.Name = "labelHosgeldiniz";
            this.labelHosgeldiniz.Size = new System.Drawing.Size(0, 13);
            this.labelHosgeldiniz.TabIndex = 0;
            // 
            // timer1
            // 
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(11, 7);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(938, 478);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // loginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 561);
            this.Controls.Add(this.panelGiris);
            this.Controls.Add(this.panelUygulama);
            this.Name = "loginForm";
            this.Text = "Matbaa Uygulaması";
            this.Load += new System.EventHandler(this.loginForm_Load);
            this.panelGiris.ResumeLayout(false);
            this.panelGiris.PerformLayout();
            this.panelProgresBar.ResumeLayout(false);
            this.panelUygulama.ResumeLayout(false);
            this.panelUygulama.PerformLayout();
            this.panelSepet.ResumeLayout(false);
            this.panelSepet.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUrunler)).EndInit();
            this.panelUrunEkle.ResumeLayout(false);
            this.panelUrunEkle.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUrunBirimFiyat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSiparisler)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxKullaniciAdi;
        private System.Windows.Forms.TextBox textBoxSifre;
        private System.Windows.Forms.Button buttonGiris;
        private System.Windows.Forms.Panel panelGiris;
        private System.Windows.Forms.Panel panelUygulama;
        private System.Windows.Forms.Label labelHosgeldiniz;
        private System.Windows.Forms.Panel panelUrunEkle;
        private System.Windows.Forms.Button buttonUrunEkle;
        private System.Windows.Forms.NumericUpDown numUrunBirimFiyat;
        private System.Windows.Forms.TextBox textBoxUrunEkleAd;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dataGridViewSiparisler;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dataGridViewUrunler;
        private System.Windows.Forms.Panel panelSepet;
        private System.Windows.Forms.TextBox textBoxSepetMusteri;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button buttonSiparisiOnayla;
        private System.Windows.Forms.Button buttonSeciliUrunleriSil;
        private System.Windows.Forms.CheckedListBox checkedListBoxSepet;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label1ToplamTutar;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button buttonUrunSil;
        private System.Windows.Forms.CheckedListBox checkedListBoxUrunSil;
        private System.Windows.Forms.DataGridViewTextBoxColumn urun;
        private System.Windows.Forms.DataGridViewTextBoxColumn birimFiyat;
        private System.Windows.Forms.DataGridViewButtonColumn siparisEkle;
        private System.Windows.Forms.DataGridViewButtonColumn urunGuncelle;
        private System.Windows.Forms.Button buttonKayıtOl;
        private System.Windows.Forms.Panel panelProgresBar;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.DataGridViewTextBoxColumn siparisId;
        private System.Windows.Forms.DataGridViewTextBoxColumn musteriAdi;
        private System.Windows.Forms.DataGridViewTextBoxColumn urunAdi;
        private System.Windows.Forms.DataGridViewTextBoxColumn urunAdedi;
        private System.Windows.Forms.DataGridViewTextBoxColumn siparisTutari;
        private System.Windows.Forms.DataGridViewButtonColumn siparisSil;
        private System.Windows.Forms.Button buttonKullaniciBilgileriGuncelle;
        private System.Windows.Forms.TextBox textBoxKullaniciSifreGuncelle;
        private System.Windows.Forms.TextBox textBoxKullaniciAdiGuncelle;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

