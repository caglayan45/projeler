/**
* Hesap.hpp
* Bazı hesaplama fonksiyonlarının başlık dosyası.
* Yaz okulu 
* Vize ödevi
* 10/08/2020
* Yavuz KAYA
*/
#ifndef HESAP_HPP
#define HESAP_HPP

class Hesap{
	public:
		int obebBul(int,int);
		int HangisiBuyuk(int,int);
};

#endif