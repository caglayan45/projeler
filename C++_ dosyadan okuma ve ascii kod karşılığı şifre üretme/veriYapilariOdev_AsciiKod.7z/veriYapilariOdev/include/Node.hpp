/**
* Node.hpp
* Asıl fonksiyonların ve düğüm işlemlerinin başlık dosyası.
* Yaz okulu 
* Vize ödevi
* 10/08/2020
* Yavuz KAYA
*/
#ifndef NODE_HPP
#define NODE_HPP
#include <cstddef>
#include <iostream>
#include "Hesap.hpp"

using namespace std;

struct node{
	public:
        int data;
        node *next;
        node *prev;
};

class Node{
	public:
		void Ekle(int);
		void listeyiTemizle();
		void SifreyiYazdir();
};

#endif