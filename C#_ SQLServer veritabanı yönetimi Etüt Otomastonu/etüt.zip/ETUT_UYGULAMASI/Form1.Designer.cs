﻿namespace ETUT_UYGULAMASI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panelKullaniciGirisi = new System.Windows.Forms.Panel();
            this.linkLabelKayitOl = new System.Windows.Forms.LinkLabel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtKullaniciGirisSifre = new System.Windows.Forms.TextBox();
            this.txtKullaniciGirisKullaniciAdi = new System.Windows.Forms.TextBox();
            this.btnKullaniciGiris = new System.Windows.Forms.Button();
            this.panelKayitOl = new System.Windows.Forms.Panel();
            this.linkLabelKayitOlGeri = new System.Windows.Forms.LinkLabel();
            this.label5 = new System.Windows.Forms.Label();
            this.txtKayitOlSifreTekrar = new System.Windows.Forms.TextBox();
            this.txtKayitOlSifre = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtKayitOlKullaniciAdi = new System.Windows.Forms.TextBox();
            this.btnKayitOl = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelAnaSayfa = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblBaslangic = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.btnAnaSayfaCikis = new System.Windows.Forms.Button();
            this.labelSaatTarih = new System.Windows.Forms.Label();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.anaSayfaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.öğrenciİşlemleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.öğrenciKayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.öğrencToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.notGörüntülemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.etütİşlemleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yeniEtütToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.etütGörüntülemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.öğretmenİşlemleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dersİşlemleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tYTAYTDGSPuanHesaplamaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aYTPuanHesaplamaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dGSPuanHesaplamaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelDersIslemleri = new System.Windows.Forms.Panel();
            this.txtDersIslemleriDersAdi = new System.Windows.Forms.TextBox();
            this.dataGridViewDersIslemleri = new System.Windows.Forms.DataGridView();
            this.btnDersIslemleriEkleSil = new System.Windows.Forms.Button();
            this.txtDersIslemleriDersID = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.radioButtonDersIslemleriSilme = new System.Windows.Forms.RadioButton();
            this.radioButtonDersIslemleriEkleme = new System.Windows.Forms.RadioButton();
            this.panelNotIslemleri = new System.Windows.Forms.Panel();
            this.panelNotIslemleriAramaIslemi = new System.Windows.Forms.Panel();
            this.btnNotIslemleriArama = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.txtNotIslemleriAramaMax = new System.Windows.Forms.TextBox();
            this.txtNotIslemleriAramaMin = new System.Windows.Forms.TextBox();
            this.comboBoxNotIslemleriAramaDers = new System.Windows.Forms.ComboBox();
            this.comboBoxNotIslemleriAramaOgrenci = new System.Windows.Forms.ComboBox();
            this.radioButtonNotIslemleriAramaNot = new System.Windows.Forms.RadioButton();
            this.radioButtonNotIslemleriAramaDers = new System.Windows.Forms.RadioButton();
            this.radioButtonNotIslemleriAramaOgrenci = new System.Windows.Forms.RadioButton();
            this.btnNotIslemleriEkleKaydet = new System.Windows.Forms.Button();
            this.txtNotIslemleriNot = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.comboBoxNotIslemleriDers = new System.Windows.Forms.ComboBox();
            this.comboBoxNotIslemleriOgrenci = new System.Windows.Forms.ComboBox();
            this.radioButtonNotIslemleriAramaIslemi = new System.Windows.Forms.RadioButton();
            this.radioButtonNotIslemleriGuncellemeIslemi = new System.Windows.Forms.RadioButton();
            this.radioButtonNotIslemleriEklemeIslemi = new System.Windows.Forms.RadioButton();
            this.dataGridViewNotIslemleri = new System.Windows.Forms.DataGridView();
            this.panelOgrenciKayitIslemleri = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.dateTimePickerKayitIslemleri = new System.Windows.Forms.DateTimePicker();
            this.panel2 = new System.Windows.Forms.Panel();
            this.radioButtonOgrKayitIslemleriErkek = new System.Windows.Forms.RadioButton();
            this.radioButtonOgrKayitIslemleriKadin = new System.Windows.Forms.RadioButton();
            this.label21 = new System.Windows.Forms.Label();
            this.txtOgrKayitIslemleriAdres = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtOgrKayitIslemleriTelefon = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtOgrKayitIslemleriSoyisim = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtOgrKayitIslemleriIsim = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtOgrKayitIslemleriTC = new System.Windows.Forms.TextBox();
            this.radioButtonOgrKayitIslemleriGuncellemeIslemi = new System.Windows.Forms.RadioButton();
            this.radioButtonOgrKayitIslemleriEklemeIslemi = new System.Windows.Forms.RadioButton();
            this.dataGridViewOgrenciEkleCikar = new System.Windows.Forms.DataGridView();
            this.btnOgrKayitIslemleriEkle = new System.Windows.Forms.Button();
            this.btnOgrKayitIslemleriGuncelle = new System.Windows.Forms.Button();
            this.panelEtutleriGoruntule = new System.Windows.Forms.Panel();
            this.btnEtutGoruntuleAraSil = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.radioButtonEtutGoruntuleSilmeIslemi = new System.Windows.Forms.RadioButton();
            this.radioButtonEtutGoruntuleAramaIslemi = new System.Windows.Forms.RadioButton();
            this.dateTimePickerEtutGotunrule = new System.Windows.Forms.DateTimePicker();
            this.radioButtonEtutGoruntuleTarih = new System.Windows.Forms.RadioButton();
            this.comboBoxEtutGoruntuleDers = new System.Windows.Forms.ComboBox();
            this.comboBoxEtutGoruntuleOgretmen = new System.Windows.Forms.ComboBox();
            this.radioButtonEtutGoruntuleDers = new System.Windows.Forms.RadioButton();
            this.radioButtonEtutGoruntuleOgretmen = new System.Windows.Forms.RadioButton();
            this.comboBoxEtutGoruntuleOgrenci = new System.Windows.Forms.ComboBox();
            this.radioButtonEtutGoruntuleOgrenci = new System.Windows.Forms.RadioButton();
            this.dataGridViewEtutGoruntule = new System.Windows.Forms.DataGridView();
            this.panelYeniEtüt = new System.Windows.Forms.Panel();
            this.label147 = new System.Windows.Forms.Label();
            this.comboBoxEtutDers = new System.Windows.Forms.ComboBox();
            this.txtEtutUcret = new System.Windows.Forms.TextBox();
            this.label95 = new System.Windows.Forms.Label();
            this.btnEtutEkle = new System.Windows.Forms.Button();
            this.dataGridViewEtutEkleme = new System.Windows.Forms.DataGridView();
            this.btnEtut22 = new System.Windows.Forms.Button();
            this.btnEtut21 = new System.Windows.Forms.Button();
            this.btnEtut20 = new System.Windows.Forms.Button();
            this.btnEtut19 = new System.Windows.Forms.Button();
            this.btnEtut18 = new System.Windows.Forms.Button();
            this.btnEtut17 = new System.Windows.Forms.Button();
            this.btnEtut16 = new System.Windows.Forms.Button();
            this.btnEtut15 = new System.Windows.Forms.Button();
            this.btnEtut14 = new System.Windows.Forms.Button();
            this.btnEtut13 = new System.Windows.Forms.Button();
            this.btnEtut12 = new System.Windows.Forms.Button();
            this.btnEtut11 = new System.Windows.Forms.Button();
            this.btnEtut10 = new System.Windows.Forms.Button();
            this.btnEtut09 = new System.Windows.Forms.Button();
            this.btnEtut08 = new System.Windows.Forms.Button();
            this.dateTimePickerEtutTarih = new System.Windows.Forms.DateTimePicker();
            this.label96 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.comboBoxEtutOgretmen = new System.Windows.Forms.ComboBox();
            this.comboBoxEtutOgrenci = new System.Windows.Forms.ComboBox();
            this.panelOgretmenIslemleri = new System.Windows.Forms.Panel();
            this.txtOgretmenIslemleriSoyadi = new System.Windows.Forms.TextBox();
            this.txtOgretmenIslemleriAdi = new System.Windows.Forms.TextBox();
            this.dataGridViewOgretmenIslemleri = new System.Windows.Forms.DataGridView();
            this.btnOgretmenIslemleriEkleSil = new System.Windows.Forms.Button();
            this.txtOgretmenIslemleriTC = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.radioButtonOgretmenIslemleriSilme = new System.Windows.Forms.RadioButton();
            this.radioButtonOgretmenIslemleriEkleme = new System.Windows.Forms.RadioButton();
            this.panelOgrencileriGoruntuleme = new System.Windows.Forms.Panel();
            this.btnOgrenciGorntulemeSIL = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.btnOgrFiltreAra = new System.Windows.Forms.Button();
            this.panelOgrFiltreCinsiyet = new System.Windows.Forms.Panel();
            this.radioButtonOgrFiltreErkek = new System.Windows.Forms.RadioButton();
            this.radioButtonOgrFiltreKadin = new System.Windows.Forms.RadioButton();
            this.txtOgrFiltreSoyisim = new System.Windows.Forms.TextBox();
            this.txtOgrFiltreIsim = new System.Windows.Forms.TextBox();
            this.txtOgrFiltreTC = new System.Windows.Forms.TextBox();
            this.radioButtonOgrFiltreSoyisim = new System.Windows.Forms.RadioButton();
            this.radioButtonOgrFiltreCinsiyet = new System.Windows.Forms.RadioButton();
            this.radioButtonOgrFiltreIsim = new System.Windows.Forms.RadioButton();
            this.radioButtonOgrFiltreTC = new System.Windows.Forms.RadioButton();
            this.dataGridViewOgrencileriGoruntule = new System.Windows.Forms.DataGridView();
            this.panelDGSHesap = new System.Windows.Forms.Panel();
            this.lblEsitAgirlikPuani = new System.Windows.Forms.Label();
            this.lblSozelPuani = new System.Windows.Forms.Label();
            this.lblSayisalPuan = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.btnDGSTemizle = new System.Windows.Forms.Button();
            this.btnDGSHesapla = new System.Windows.Forms.Button();
            this.checkBoxDGS = new System.Windows.Forms.CheckBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.txtDGSonlisansPuani = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.txtDGSSozelYanlis = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.txtDGSSozelDogru = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.txtDGSSayisalYanlis = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtDGSSayisalDogru = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panelAYTHesap = new System.Windows.Forms.Panel();
            this.radioButtonAYTEsitAgirlik = new System.Windows.Forms.RadioButton();
            this.radioButtonAYTSayisal = new System.Windows.Forms.RadioButton();
            this.radioButtonAYTSozel = new System.Windows.Forms.RadioButton();
            this.btnAYTTemizle = new System.Windows.Forms.Button();
            this.lblAYTpuani = new System.Windows.Forms.Label();
            this.lblAYTpuanTuru = new System.Windows.Forms.Label();
            this.btnAYTHesapla = new System.Windows.Forms.Button();
            this.label63 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.txtAYTobp = new System.Windows.Forms.TextBox();
            this.panelAYTSozel = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.txtAYTSozelFelsefeYanlis = new System.Windows.Forms.TextBox();
            this.label146 = new System.Windows.Forms.Label();
            this.txtAYTSozelFelsefeDogru = new System.Windows.Forms.TextBox();
            this.label100 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.txtAYTSozelDKABYanlis = new System.Windows.Forms.TextBox();
            this.label104 = new System.Windows.Forms.Label();
            this.txtAYTSozelDKABDogru = new System.Windows.Forms.TextBox();
            this.label105 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.txtAYTSozelCografya2Yanlis = new System.Windows.Forms.TextBox();
            this.label108 = new System.Windows.Forms.Label();
            this.txtAYTSozelCografya2Dogru = new System.Windows.Forms.TextBox();
            this.label109 = new System.Windows.Forms.Label();
            this.txtAYTSozelTarih2Yanlis = new System.Windows.Forms.TextBox();
            this.label110 = new System.Windows.Forms.Label();
            this.txtAYTSozelTarih2Dogru = new System.Windows.Forms.TextBox();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.txtAYTSozelCografya1Yanlis = new System.Windows.Forms.TextBox();
            this.label90 = new System.Windows.Forms.Label();
            this.txtAYTSozelCografya1Dogru = new System.Windows.Forms.TextBox();
            this.label91 = new System.Windows.Forms.Label();
            this.txtAYTSozelTarih1Yanlis = new System.Windows.Forms.TextBox();
            this.label92 = new System.Windows.Forms.Label();
            this.txtAYTSozelTarih1Dogru = new System.Windows.Forms.TextBox();
            this.label94 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.txtAYTSozelEdebiyatYanlis = new System.Windows.Forms.TextBox();
            this.label98 = new System.Windows.Forms.Label();
            this.txtAYTSozelEdebiyatDogru = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.txtAYTSozelFenYanlis = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.txtAYTSozelFenDogru = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.txtAYTSozelTemelMatYanlis = new System.Windows.Forms.TextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.txtAYTSozelTemelMatDogru = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.txtAYTSozelSosyalYanlis = new System.Windows.Forms.TextBox();
            this.label82 = new System.Windows.Forms.Label();
            this.txtAYTSozelSosyalDogru = new System.Windows.Forms.TextBox();
            this.label83 = new System.Windows.Forms.Label();
            this.txtAYTSozelTurkceYanlis = new System.Windows.Forms.TextBox();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.txtAYTSozelTurkceDogru = new System.Windows.Forms.TextBox();
            this.label86 = new System.Windows.Forms.Label();
            this.panelAYTEsitAgirlik = new System.Windows.Forms.Panel();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.txtEsitAgirlikCografya1Yanlis = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.txtEsitAgirlikCografya1Dogru = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.txtEsitAgirlikTarih1Yanlis = new System.Windows.Forms.TextBox();
            this.label99 = new System.Windows.Forms.Label();
            this.txtEsitAgirlikTarih1Dogru = new System.Windows.Forms.TextBox();
            this.label101 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.txtEsitAgirlikEdebiyatYanlis = new System.Windows.Forms.TextBox();
            this.label112 = new System.Windows.Forms.Label();
            this.txtEsitAgirlikEdebiyatDogru = new System.Windows.Forms.TextBox();
            this.label113 = new System.Windows.Forms.Label();
            this.txtEsitAgirlikMatematikYanlis = new System.Windows.Forms.TextBox();
            this.label114 = new System.Windows.Forms.Label();
            this.txtEsitAgirlikMatematikDogru = new System.Windows.Forms.TextBox();
            this.label115 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.txtEsitAgirlikFenYanlis = new System.Windows.Forms.TextBox();
            this.label118 = new System.Windows.Forms.Label();
            this.txtEsitAgirlikFenDogru = new System.Windows.Forms.TextBox();
            this.label119 = new System.Windows.Forms.Label();
            this.txtEsitAgirlikTemelMatYanlis = new System.Windows.Forms.TextBox();
            this.label120 = new System.Windows.Forms.Label();
            this.txtEsitAgirlikTemelMatDogru = new System.Windows.Forms.TextBox();
            this.label121 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.txtEsitAgirlikSosyalYanlis = new System.Windows.Forms.TextBox();
            this.label124 = new System.Windows.Forms.Label();
            this.txtEsitAgirlikSosyalDogru = new System.Windows.Forms.TextBox();
            this.label125 = new System.Windows.Forms.Label();
            this.txtEsitAgirlikTurkceYanlis = new System.Windows.Forms.TextBox();
            this.label126 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.txtEsitAgirlikTurkceDogru = new System.Windows.Forms.TextBox();
            this.label128 = new System.Windows.Forms.Label();
            this.panelAYTSayisal = new System.Windows.Forms.Panel();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.txtAYTSayisalBiyolojiYanlis = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.txtATYSayisalBiyolojiDogru = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.txtAYTSayisalKimyaYanlis = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.txtATYSayisalKimyaDogru = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.txtAYTSayisalFizikYanlis = new System.Windows.Forms.TextBox();
            this.label129 = new System.Windows.Forms.Label();
            this.txtATYSayisalFizikDogru = new System.Windows.Forms.TextBox();
            this.label130 = new System.Windows.Forms.Label();
            this.txtAYTSayisalMatematikYanlis = new System.Windows.Forms.TextBox();
            this.label131 = new System.Windows.Forms.Label();
            this.txtATYSayisalMatematikDogru = new System.Windows.Forms.TextBox();
            this.label132 = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.label134 = new System.Windows.Forms.Label();
            this.txtAYTSayisalFenYanlis = new System.Windows.Forms.TextBox();
            this.label135 = new System.Windows.Forms.Label();
            this.txtATYSayisalFenDogru = new System.Windows.Forms.TextBox();
            this.label136 = new System.Windows.Forms.Label();
            this.txtAYTSayisalTemelMatYanlis = new System.Windows.Forms.TextBox();
            this.label137 = new System.Windows.Forms.Label();
            this.txtATYSayisalTemelMatDogru = new System.Windows.Forms.TextBox();
            this.label138 = new System.Windows.Forms.Label();
            this.label139 = new System.Windows.Forms.Label();
            this.label140 = new System.Windows.Forms.Label();
            this.txtAYTSayisalSosyalYanlis = new System.Windows.Forms.TextBox();
            this.label141 = new System.Windows.Forms.Label();
            this.txtATYSayisalSosyalDogru = new System.Windows.Forms.TextBox();
            this.label142 = new System.Windows.Forms.Label();
            this.txtAYTSayisalTurkceYanlis = new System.Windows.Forms.TextBox();
            this.label143 = new System.Windows.Forms.Label();
            this.label144 = new System.Windows.Forms.Label();
            this.txtATYSayisalTurkceDogru = new System.Windows.Forms.TextBox();
            this.label145 = new System.Windows.Forms.Label();
            this.panelTYTHesap = new System.Windows.Forms.Panel();
            this.btnTYTTemizle = new System.Windows.Forms.Button();
            this.lblTYT = new System.Windows.Forms.Label();
            this.lblTYTpuan = new System.Windows.Forms.Label();
            this.btnTYTHesapla = new System.Windows.Forms.Button();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.txtTYTFenYanlis = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.txtTYTFenDogru = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.txtTYTMatematikYanlis = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.txtTYTMatematikDogru = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.txtTYTobp = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.txtTYTSosyalYanlis = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.txtTYTSosyalDogru = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.txtTYTTurkceYanlis = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.txtTYTTurkceDogru = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panelKullaniciGirisi.SuspendLayout();
            this.panelKayitOl.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelAnaSayfa.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip.SuspendLayout();
            this.panelDersIslemleri.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDersIslemleri)).BeginInit();
            this.panelNotIslemleri.SuspendLayout();
            this.panelNotIslemleriAramaIslemi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewNotIslemleri)).BeginInit();
            this.panelOgrenciKayitIslemleri.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOgrenciEkleCikar)).BeginInit();
            this.panelEtutleriGoruntule.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEtutGoruntule)).BeginInit();
            this.panelYeniEtüt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEtutEkleme)).BeginInit();
            this.panelOgretmenIslemleri.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOgretmenIslemleri)).BeginInit();
            this.panelOgrencileriGoruntuleme.SuspendLayout();
            this.panelOgrFiltreCinsiyet.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOgrencileriGoruntule)).BeginInit();
            this.panelDGSHesap.SuspendLayout();
            this.panelAYTHesap.SuspendLayout();
            this.panelAYTSozel.SuspendLayout();
            this.panelAYTEsitAgirlik.SuspendLayout();
            this.panelAYTSayisal.SuspendLayout();
            this.panelTYTHesap.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelKullaniciGirisi
            // 
            this.panelKullaniciGirisi.BackColor = System.Drawing.Color.White;
            this.panelKullaniciGirisi.Controls.Add(this.linkLabelKayitOl);
            this.panelKullaniciGirisi.Controls.Add(this.label2);
            this.panelKullaniciGirisi.Controls.Add(this.label1);
            this.panelKullaniciGirisi.Controls.Add(this.txtKullaniciGirisSifre);
            this.panelKullaniciGirisi.Controls.Add(this.txtKullaniciGirisKullaniciAdi);
            this.panelKullaniciGirisi.Controls.Add(this.btnKullaniciGiris);
            this.panelKullaniciGirisi.Location = new System.Drawing.Point(0, 0);
            this.panelKullaniciGirisi.Name = "panelKullaniciGirisi";
            this.panelKullaniciGirisi.Size = new System.Drawing.Size(1024, 570);
            this.panelKullaniciGirisi.TabIndex = 1;
            // 
            // linkLabelKayitOl
            // 
            this.linkLabelKayitOl.AutoSize = true;
            this.linkLabelKayitOl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.linkLabelKayitOl.Location = new System.Drawing.Point(483, 348);
            this.linkLabelKayitOl.Name = "linkLabelKayitOl";
            this.linkLabelKayitOl.Size = new System.Drawing.Size(66, 15);
            this.linkLabelKayitOl.TabIndex = 5;
            this.linkLabelKayitOl.TabStop = true;
            this.linkLabelKayitOl.Text = "KAYIT OL";
            this.linkLabelKayitOl.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelKayitOl_LinkClicked);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(301, 247);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "ŞİFRE : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(301, 212);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "KULLANICI ADI : ";
            // 
            // txtKullaniciGirisSifre
            // 
            this.txtKullaniciGirisSifre.Location = new System.Drawing.Point(422, 246);
            this.txtKullaniciGirisSifre.Name = "txtKullaniciGirisSifre";
            this.txtKullaniciGirisSifre.Size = new System.Drawing.Size(183, 20);
            this.txtKullaniciGirisSifre.TabIndex = 2;
            this.txtKullaniciGirisSifre.UseSystemPasswordChar = true;
            // 
            // txtKullaniciGirisKullaniciAdi
            // 
            this.txtKullaniciGirisKullaniciAdi.Location = new System.Drawing.Point(422, 211);
            this.txtKullaniciGirisKullaniciAdi.Name = "txtKullaniciGirisKullaniciAdi";
            this.txtKullaniciGirisKullaniciAdi.Size = new System.Drawing.Size(183, 20);
            this.txtKullaniciGirisKullaniciAdi.TabIndex = 1;
            // 
            // btnKullaniciGiris
            // 
            this.btnKullaniciGiris.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKullaniciGiris.Location = new System.Drawing.Point(451, 289);
            this.btnKullaniciGiris.Name = "btnKullaniciGiris";
            this.btnKullaniciGiris.Size = new System.Drawing.Size(122, 56);
            this.btnKullaniciGiris.TabIndex = 0;
            this.btnKullaniciGiris.Text = "GİRİŞ YAP";
            this.btnKullaniciGiris.UseVisualStyleBackColor = true;
            this.btnKullaniciGiris.Click += new System.EventHandler(this.btnKullaniciGiris_Click);
            // 
            // panelKayitOl
            // 
            this.panelKayitOl.BackColor = System.Drawing.Color.White;
            this.panelKayitOl.Controls.Add(this.linkLabelKayitOlGeri);
            this.panelKayitOl.Controls.Add(this.label5);
            this.panelKayitOl.Controls.Add(this.txtKayitOlSifreTekrar);
            this.panelKayitOl.Controls.Add(this.txtKayitOlSifre);
            this.panelKayitOl.Controls.Add(this.label3);
            this.panelKayitOl.Controls.Add(this.label4);
            this.panelKayitOl.Controls.Add(this.txtKayitOlKullaniciAdi);
            this.panelKayitOl.Controls.Add(this.btnKayitOl);
            this.panelKayitOl.Location = new System.Drawing.Point(0, 0);
            this.panelKayitOl.Name = "panelKayitOl";
            this.panelKayitOl.Size = new System.Drawing.Size(1024, 570);
            this.panelKayitOl.TabIndex = 7;
            // 
            // linkLabelKayitOlGeri
            // 
            this.linkLabelKayitOlGeri.AutoSize = true;
            this.linkLabelKayitOlGeri.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.linkLabelKayitOlGeri.Location = new System.Drawing.Point(492, 353);
            this.linkLabelKayitOlGeri.Name = "linkLabelKayitOlGeri";
            this.linkLabelKayitOlGeri.Size = new System.Drawing.Size(40, 15);
            this.linkLabelKayitOlGeri.TabIndex = 9;
            this.linkLabelKayitOlGeri.TabStop = true;
            this.linkLabelKayitOlGeri.Text = "GERİ";
            this.linkLabelKayitOlGeri.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelKayitOlGeri_LinkClicked);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(301, 251);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 15);
            this.label5.TabIndex = 8;
            this.label5.Text = "ŞİFRE(tekrar) : ";
            // 
            // txtKayitOlSifreTekrar
            // 
            this.txtKayitOlSifreTekrar.Location = new System.Drawing.Point(422, 250);
            this.txtKayitOlSifreTekrar.Name = "txtKayitOlSifreTekrar";
            this.txtKayitOlSifreTekrar.Size = new System.Drawing.Size(183, 20);
            this.txtKayitOlSifreTekrar.TabIndex = 6;
            // 
            // txtKayitOlSifre
            // 
            this.txtKayitOlSifre.Location = new System.Drawing.Point(422, 215);
            this.txtKayitOlSifre.Name = "txtKayitOlSifre";
            this.txtKayitOlSifre.Size = new System.Drawing.Size(183, 20);
            this.txtKayitOlSifre.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(301, 217);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "ŞİFRE : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(301, 182);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "KULLANICI ADI : ";
            // 
            // txtKayitOlKullaniciAdi
            // 
            this.txtKayitOlKullaniciAdi.Location = new System.Drawing.Point(422, 181);
            this.txtKayitOlKullaniciAdi.Name = "txtKayitOlKullaniciAdi";
            this.txtKayitOlKullaniciAdi.Size = new System.Drawing.Size(183, 20);
            this.txtKayitOlKullaniciAdi.TabIndex = 1;
            // 
            // btnKayitOl
            // 
            this.btnKayitOl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKayitOl.Location = new System.Drawing.Point(451, 291);
            this.btnKayitOl.Name = "btnKayitOl";
            this.btnKayitOl.Size = new System.Drawing.Size(122, 56);
            this.btnKayitOl.TabIndex = 0;
            this.btnKayitOl.Text = "KAYIT OL";
            this.btnKayitOl.UseVisualStyleBackColor = true;
            this.btnKayitOl.Click += new System.EventHandler(this.btnKayitOl_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panelAnaSayfa);
            this.panel1.Controls.Add(this.labelSaatTarih);
            this.panel1.Controls.Add(this.menuStrip);
            this.panel1.Controls.Add(this.panelDersIslemleri);
            this.panel1.Controls.Add(this.panelNotIslemleri);
            this.panel1.Controls.Add(this.panelOgrenciKayitIslemleri);
            this.panel1.Controls.Add(this.panelEtutleriGoruntule);
            this.panel1.Controls.Add(this.panelYeniEtüt);
            this.panel1.Controls.Add(this.panelOgretmenIslemleri);
            this.panel1.Controls.Add(this.panelOgrencileriGoruntuleme);
            this.panel1.Controls.Add(this.panelDGSHesap);
            this.panel1.Controls.Add(this.panelAYTHesap);
            this.panel1.Controls.Add(this.panelTYTHesap);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1024, 570);
            this.panel1.TabIndex = 8;
            // 
            // panelAnaSayfa
            // 
            this.panelAnaSayfa.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panelAnaSayfa.Controls.Add(this.pictureBox1);
            this.panelAnaSayfa.Controls.Add(this.lblBaslangic);
            this.panelAnaSayfa.Controls.Add(this.label10);
            this.panelAnaSayfa.Controls.Add(this.btnAnaSayfaCikis);
            this.panelAnaSayfa.Location = new System.Drawing.Point(3, 27);
            this.panelAnaSayfa.Name = "panelAnaSayfa";
            this.panelAnaSayfa.Size = new System.Drawing.Size(1018, 543);
            this.panelAnaSayfa.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(10, 326);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(999, 182);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // lblBaslangic
            // 
            this.lblBaslangic.AutoSize = true;
            this.lblBaslangic.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBaslangic.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblBaslangic.Location = new System.Drawing.Point(222, 214);
            this.lblBaslangic.Name = "lblBaslangic";
            this.lblBaslangic.Size = new System.Drawing.Size(0, 76);
            this.lblBaslangic.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label10.Location = new System.Drawing.Point(217, 87);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(574, 76);
            this.label10.TabIndex = 3;
            this.label10.Text = "ETÜT Uygulaması";
            // 
            // btnAnaSayfaCikis
            // 
            this.btnAnaSayfaCikis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAnaSayfaCikis.Location = new System.Drawing.Point(891, 8);
            this.btnAnaSayfaCikis.Name = "btnAnaSayfaCikis";
            this.btnAnaSayfaCikis.Size = new System.Drawing.Size(118, 47);
            this.btnAnaSayfaCikis.TabIndex = 2;
            this.btnAnaSayfaCikis.Text = "ÇIKIŞ";
            this.btnAnaSayfaCikis.UseVisualStyleBackColor = true;
            this.btnAnaSayfaCikis.Click += new System.EventHandler(this.btnAnaSayfaCikis_Click);
            // 
            // labelSaatTarih
            // 
            this.labelSaatTarih.AutoSize = true;
            this.labelSaatTarih.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.labelSaatTarih.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelSaatTarih.ForeColor = System.Drawing.Color.Black;
            this.labelSaatTarih.Location = new System.Drawing.Point(880, 545);
            this.labelSaatTarih.Name = "labelSaatTarih";
            this.labelSaatTarih.Size = new System.Drawing.Size(47, 15);
            this.labelSaatTarih.TabIndex = 1;
            this.labelSaatTarih.Text = "label6";
            // 
            // menuStrip
            // 
            this.menuStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.anaSayfaToolStripMenuItem,
            this.öğrenciİşlemleriToolStripMenuItem,
            this.etütİşlemleriToolStripMenuItem,
            this.öğretmenİşlemleriToolStripMenuItem,
            this.dersİşlemleriToolStripMenuItem,
            this.tYTAYTDGSPuanHesaplamaToolStripMenuItem,
            this.aYTPuanHesaplamaToolStripMenuItem,
            this.dGSPuanHesaplamaToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip.Size = new System.Drawing.Size(1024, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "menuStrip1";
            // 
            // anaSayfaToolStripMenuItem
            // 
            this.anaSayfaToolStripMenuItem.Name = "anaSayfaToolStripMenuItem";
            this.anaSayfaToolStripMenuItem.ShortcutKeyDisplayString = "";
            this.anaSayfaToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.anaSayfaToolStripMenuItem.Text = "Ana Sayfa";
            this.anaSayfaToolStripMenuItem.Click += new System.EventHandler(this.anaSayfaToolStripMenuItem_Click);
            // 
            // öğrenciİşlemleriToolStripMenuItem
            // 
            this.öğrenciİşlemleriToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.öğrenciKayToolStripMenuItem,
            this.öğrencToolStripMenuItem,
            this.notGörüntülemeToolStripMenuItem});
            this.öğrenciİşlemleriToolStripMenuItem.Name = "öğrenciİşlemleriToolStripMenuItem";
            this.öğrenciİşlemleriToolStripMenuItem.Size = new System.Drawing.Size(108, 20);
            this.öğrenciİşlemleriToolStripMenuItem.Text = "Öğrenci İşlemleri";
            // 
            // öğrenciKayToolStripMenuItem
            // 
            this.öğrenciKayToolStripMenuItem.Name = "öğrenciKayToolStripMenuItem";
            this.öğrenciKayToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.öğrenciKayToolStripMenuItem.Text = "Öğrenci Kayıt İşlemleri";
            this.öğrenciKayToolStripMenuItem.Click += new System.EventHandler(this.öğrenciKayToolStripMenuItem_Click);
            // 
            // öğrencToolStripMenuItem
            // 
            this.öğrencToolStripMenuItem.Name = "öğrencToolStripMenuItem";
            this.öğrencToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.öğrencToolStripMenuItem.Text = "Öğrencileri Görüntüleme";
            this.öğrencToolStripMenuItem.Click += new System.EventHandler(this.öğrencToolStripMenuItem_Click);
            // 
            // notGörüntülemeToolStripMenuItem
            // 
            this.notGörüntülemeToolStripMenuItem.Name = "notGörüntülemeToolStripMenuItem";
            this.notGörüntülemeToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.notGörüntülemeToolStripMenuItem.Text = "Not İşlemleri";
            this.notGörüntülemeToolStripMenuItem.Click += new System.EventHandler(this.notGörüntülemeToolStripMenuItem_Click);
            // 
            // etütİşlemleriToolStripMenuItem
            // 
            this.etütİşlemleriToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yeniEtütToolStripMenuItem,
            this.etütGörüntülemeToolStripMenuItem});
            this.etütİşlemleriToolStripMenuItem.Name = "etütİşlemleriToolStripMenuItem";
            this.etütİşlemleriToolStripMenuItem.Size = new System.Drawing.Size(107, 20);
            this.etütİşlemleriToolStripMenuItem.Text = "1-1 Etüt İşlemleri";
            // 
            // yeniEtütToolStripMenuItem
            // 
            this.yeniEtütToolStripMenuItem.Name = "yeniEtütToolStripMenuItem";
            this.yeniEtütToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.yeniEtütToolStripMenuItem.Text = "Yeni Etüt";
            this.yeniEtütToolStripMenuItem.Click += new System.EventHandler(this.yeniEtütToolStripMenuItem_Click);
            // 
            // etütGörüntülemeToolStripMenuItem
            // 
            this.etütGörüntülemeToolStripMenuItem.Name = "etütGörüntülemeToolStripMenuItem";
            this.etütGörüntülemeToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.etütGörüntülemeToolStripMenuItem.Text = "Etüt Görüntüleme";
            this.etütGörüntülemeToolStripMenuItem.Click += new System.EventHandler(this.etütGörüntülemeToolStripMenuItem_Click);
            // 
            // öğretmenİşlemleriToolStripMenuItem
            // 
            this.öğretmenİşlemleriToolStripMenuItem.Name = "öğretmenİşlemleriToolStripMenuItem";
            this.öğretmenİşlemleriToolStripMenuItem.Size = new System.Drawing.Size(120, 20);
            this.öğretmenİşlemleriToolStripMenuItem.Text = "Öğretmen İşlemleri";
            this.öğretmenİşlemleriToolStripMenuItem.Click += new System.EventHandler(this.öğretmenİşlemleriToolStripMenuItem_Click);
            // 
            // dersİşlemleriToolStripMenuItem
            // 
            this.dersİşlemleriToolStripMenuItem.BackColor = System.Drawing.Color.Transparent;
            this.dersİşlemleriToolStripMenuItem.Name = "dersİşlemleriToolStripMenuItem";
            this.dersİşlemleriToolStripMenuItem.Size = new System.Drawing.Size(89, 20);
            this.dersİşlemleriToolStripMenuItem.Text = "Ders İşlemleri";
            this.dersİşlemleriToolStripMenuItem.Click += new System.EventHandler(this.dersİşlemleriToolStripMenuItem_Click);
            // 
            // tYTAYTDGSPuanHesaplamaToolStripMenuItem
            // 
            this.tYTAYTDGSPuanHesaplamaToolStripMenuItem.Name = "tYTAYTDGSPuanHesaplamaToolStripMenuItem";
            this.tYTAYTDGSPuanHesaplamaToolStripMenuItem.Size = new System.Drawing.Size(130, 20);
            this.tYTAYTDGSPuanHesaplamaToolStripMenuItem.Text = "TYT Puan Hesaplama";
            this.tYTAYTDGSPuanHesaplamaToolStripMenuItem.Click += new System.EventHandler(this.tYTAYTDGSPuanHesaplamaToolStripMenuItem_Click);
            // 
            // aYTPuanHesaplamaToolStripMenuItem
            // 
            this.aYTPuanHesaplamaToolStripMenuItem.Name = "aYTPuanHesaplamaToolStripMenuItem";
            this.aYTPuanHesaplamaToolStripMenuItem.Size = new System.Drawing.Size(134, 20);
            this.aYTPuanHesaplamaToolStripMenuItem.Text = " AYT Puan Hesaplama";
            this.aYTPuanHesaplamaToolStripMenuItem.Click += new System.EventHandler(this.aYTPuanHesaplamaToolStripMenuItem_Click);
            // 
            // dGSPuanHesaplamaToolStripMenuItem
            // 
            this.dGSPuanHesaplamaToolStripMenuItem.Name = "dGSPuanHesaplamaToolStripMenuItem";
            this.dGSPuanHesaplamaToolStripMenuItem.Size = new System.Drawing.Size(136, 20);
            this.dGSPuanHesaplamaToolStripMenuItem.Text = " DGS Puan Hesaplama";
            this.dGSPuanHesaplamaToolStripMenuItem.Click += new System.EventHandler(this.dGSPuanHesaplamaToolStripMenuItem_Click);
            // 
            // panelDersIslemleri
            // 
            this.panelDersIslemleri.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panelDersIslemleri.Controls.Add(this.txtDersIslemleriDersAdi);
            this.panelDersIslemleri.Controls.Add(this.dataGridViewDersIslemleri);
            this.panelDersIslemleri.Controls.Add(this.btnDersIslemleriEkleSil);
            this.panelDersIslemleri.Controls.Add(this.txtDersIslemleriDersID);
            this.panelDersIslemleri.Controls.Add(this.label17);
            this.panelDersIslemleri.Controls.Add(this.label28);
            this.panelDersIslemleri.Controls.Add(this.radioButtonDersIslemleriSilme);
            this.panelDersIslemleri.Controls.Add(this.radioButtonDersIslemleriEkleme);
            this.panelDersIslemleri.Location = new System.Drawing.Point(3, 27);
            this.panelDersIslemleri.Name = "panelDersIslemleri";
            this.panelDersIslemleri.Size = new System.Drawing.Size(1018, 543);
            this.panelDersIslemleri.TabIndex = 11;
            // 
            // txtDersIslemleriDersAdi
            // 
            this.txtDersIslemleriDersAdi.Location = new System.Drawing.Point(93, 341);
            this.txtDersIslemleriDersAdi.Name = "txtDersIslemleriDersAdi";
            this.txtDersIslemleriDersAdi.Size = new System.Drawing.Size(149, 20);
            this.txtDersIslemleriDersAdi.TabIndex = 40;
            this.txtDersIslemleriDersAdi.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDersIslemleriDersAdi_KeyPress);
            // 
            // dataGridViewDersIslemleri
            // 
            this.dataGridViewDersIslemleri.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewDersIslemleri.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDersIslemleri.Location = new System.Drawing.Point(9, 13);
            this.dataGridViewDersIslemleri.Name = "dataGridViewDersIslemleri";
            this.dataGridViewDersIslemleri.ReadOnly = true;
            this.dataGridViewDersIslemleri.Size = new System.Drawing.Size(1000, 249);
            this.dataGridViewDersIslemleri.TabIndex = 39;
            this.dataGridViewDersIslemleri.SelectionChanged += new System.EventHandler(this.dataGridViewDersIslemleri_SelectionChanged);
            // 
            // btnDersIslemleriEkleSil
            // 
            this.btnDersIslemleriEkleSil.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnDersIslemleriEkleSil.Location = new System.Drawing.Point(65, 376);
            this.btnDersIslemleriEkleSil.Name = "btnDersIslemleriEkleSil";
            this.btnDersIslemleriEkleSil.Size = new System.Drawing.Size(125, 35);
            this.btnDersIslemleriEkleSil.TabIndex = 38;
            this.btnDersIslemleriEkleSil.Text = "EKLE / SİL";
            this.btnDersIslemleriEkleSil.UseVisualStyleBackColor = true;
            this.btnDersIslemleriEkleSil.Click += new System.EventHandler(this.btnDersIslemleriEkleSil_Click);
            // 
            // txtDersIslemleriDersID
            // 
            this.txtDersIslemleriDersID.Location = new System.Drawing.Point(93, 306);
            this.txtDersIslemleriDersID.Name = "txtDersIslemleriDersID";
            this.txtDersIslemleriDersID.Size = new System.Drawing.Size(149, 20);
            this.txtDersIslemleriDersID.TabIndex = 37;
            this.txtDersIslemleriDersID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDersIslemleriDersID_KeyPress);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 343);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(56, 13);
            this.label17.TabIndex = 35;
            this.label17.Text = "Ders Adı : ";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(6, 309);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(52, 13);
            this.label28.TabIndex = 34;
            this.label28.Text = "Ders ID : ";
            // 
            // radioButtonDersIslemleriSilme
            // 
            this.radioButtonDersIslemleriSilme.AutoSize = true;
            this.radioButtonDersIslemleriSilme.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonDersIslemleriSilme.ForeColor = System.Drawing.Color.Black;
            this.radioButtonDersIslemleriSilme.Location = new System.Drawing.Point(138, 274);
            this.radioButtonDersIslemleriSilme.Name = "radioButtonDersIslemleriSilme";
            this.radioButtonDersIslemleriSilme.Size = new System.Drawing.Size(107, 17);
            this.radioButtonDersIslemleriSilme.TabIndex = 33;
            this.radioButtonDersIslemleriSilme.Text = "SİLME İŞLEMİ";
            this.radioButtonDersIslemleriSilme.UseVisualStyleBackColor = true;
            // 
            // radioButtonDersIslemleriEkleme
            // 
            this.radioButtonDersIslemleriEkleme.AutoSize = true;
            this.radioButtonDersIslemleriEkleme.Checked = true;
            this.radioButtonDersIslemleriEkleme.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonDersIslemleriEkleme.ForeColor = System.Drawing.Color.Black;
            this.radioButtonDersIslemleriEkleme.Location = new System.Drawing.Point(9, 274);
            this.radioButtonDersIslemleriEkleme.Name = "radioButtonDersIslemleriEkleme";
            this.radioButtonDersIslemleriEkleme.Size = new System.Drawing.Size(119, 17);
            this.radioButtonDersIslemleriEkleme.TabIndex = 32;
            this.radioButtonDersIslemleriEkleme.TabStop = true;
            this.radioButtonDersIslemleriEkleme.Text = "EKLEME İŞLEMİ";
            this.radioButtonDersIslemleriEkleme.UseVisualStyleBackColor = true;
            this.radioButtonDersIslemleriEkleme.CheckedChanged += new System.EventHandler(this.radioButtonDersIslemleriEkleme_CheckedChanged);
            // 
            // panelNotIslemleri
            // 
            this.panelNotIslemleri.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panelNotIslemleri.Controls.Add(this.panelNotIslemleriAramaIslemi);
            this.panelNotIslemleri.Controls.Add(this.btnNotIslemleriEkleKaydet);
            this.panelNotIslemleri.Controls.Add(this.txtNotIslemleriNot);
            this.panelNotIslemleri.Controls.Add(this.label24);
            this.panelNotIslemleri.Controls.Add(this.label13);
            this.panelNotIslemleri.Controls.Add(this.label12);
            this.panelNotIslemleri.Controls.Add(this.comboBoxNotIslemleriDers);
            this.panelNotIslemleri.Controls.Add(this.comboBoxNotIslemleriOgrenci);
            this.panelNotIslemleri.Controls.Add(this.radioButtonNotIslemleriAramaIslemi);
            this.panelNotIslemleri.Controls.Add(this.radioButtonNotIslemleriGuncellemeIslemi);
            this.panelNotIslemleri.Controls.Add(this.radioButtonNotIslemleriEklemeIslemi);
            this.panelNotIslemleri.Controls.Add(this.dataGridViewNotIslemleri);
            this.panelNotIslemleri.Location = new System.Drawing.Point(3, 27);
            this.panelNotIslemleri.Name = "panelNotIslemleri";
            this.panelNotIslemleri.Size = new System.Drawing.Size(1018, 543);
            this.panelNotIslemleri.TabIndex = 4;
            // 
            // panelNotIslemleriAramaIslemi
            // 
            this.panelNotIslemleriAramaIslemi.Controls.Add(this.btnNotIslemleriArama);
            this.panelNotIslemleriAramaIslemi.Controls.Add(this.label27);
            this.panelNotIslemleriAramaIslemi.Controls.Add(this.label26);
            this.panelNotIslemleriAramaIslemi.Controls.Add(this.label25);
            this.panelNotIslemleriAramaIslemi.Controls.Add(this.txtNotIslemleriAramaMax);
            this.panelNotIslemleriAramaIslemi.Controls.Add(this.txtNotIslemleriAramaMin);
            this.panelNotIslemleriAramaIslemi.Controls.Add(this.comboBoxNotIslemleriAramaDers);
            this.panelNotIslemleriAramaIslemi.Controls.Add(this.comboBoxNotIslemleriAramaOgrenci);
            this.panelNotIslemleriAramaIslemi.Controls.Add(this.radioButtonNotIslemleriAramaNot);
            this.panelNotIslemleriAramaIslemi.Controls.Add(this.radioButtonNotIslemleriAramaDers);
            this.panelNotIslemleriAramaIslemi.Controls.Add(this.radioButtonNotIslemleriAramaOgrenci);
            this.panelNotIslemleriAramaIslemi.Location = new System.Drawing.Point(9, 297);
            this.panelNotIslemleriAramaIslemi.Name = "panelNotIslemleriAramaIslemi";
            this.panelNotIslemleriAramaIslemi.Size = new System.Drawing.Size(1000, 235);
            this.panelNotIslemleriAramaIslemi.TabIndex = 17;
            this.panelNotIslemleriAramaIslemi.Visible = false;
            // 
            // btnNotIslemleriArama
            // 
            this.btnNotIslemleriArama.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnNotIslemleriArama.Location = new System.Drawing.Point(163, 110);
            this.btnNotIslemleriArama.Name = "btnNotIslemleriArama";
            this.btnNotIslemleriArama.Size = new System.Drawing.Size(125, 35);
            this.btnNotIslemleriArama.TabIndex = 18;
            this.btnNotIslemleriArama.Text = "ARA";
            this.btnNotIslemleriArama.UseVisualStyleBackColor = true;
            this.btnNotIslemleriArama.Click += new System.EventHandler(this.btnNotIslemleriArama_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(318, 83);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(33, 13);
            this.label27.TabIndex = 17;
            this.label27.Text = ": Max";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(107, 82);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(33, 13);
            this.label26.TabIndex = 16;
            this.label26.Text = "Min : ";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(221, 83);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(10, 13);
            this.label25.TabIndex = 15;
            this.label25.Text = "-";
            // 
            // txtNotIslemleriAramaMax
            // 
            this.txtNotIslemleriAramaMax.Enabled = false;
            this.txtNotIslemleriAramaMax.Location = new System.Drawing.Point(237, 79);
            this.txtNotIslemleriAramaMax.Name = "txtNotIslemleriAramaMax";
            this.txtNotIslemleriAramaMax.Size = new System.Drawing.Size(75, 20);
            this.txtNotIslemleriAramaMax.TabIndex = 14;
            this.txtNotIslemleriAramaMax.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNotIslemleriAramaMax_KeyPress);
            // 
            // txtNotIslemleriAramaMin
            // 
            this.txtNotIslemleriAramaMin.Enabled = false;
            this.txtNotIslemleriAramaMin.ForeColor = System.Drawing.Color.Black;
            this.txtNotIslemleriAramaMin.Location = new System.Drawing.Point(140, 79);
            this.txtNotIslemleriAramaMin.Name = "txtNotIslemleriAramaMin";
            this.txtNotIslemleriAramaMin.Size = new System.Drawing.Size(75, 20);
            this.txtNotIslemleriAramaMin.TabIndex = 13;
            this.txtNotIslemleriAramaMin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNotIslemleriAramaMin_KeyPress);
            // 
            // comboBoxNotIslemleriAramaDers
            // 
            this.comboBoxNotIslemleriAramaDers.Enabled = false;
            this.comboBoxNotIslemleriAramaDers.FormattingEnabled = true;
            this.comboBoxNotIslemleriAramaDers.Location = new System.Drawing.Point(106, 43);
            this.comboBoxNotIslemleriAramaDers.Name = "comboBoxNotIslemleriAramaDers";
            this.comboBoxNotIslemleriAramaDers.Size = new System.Drawing.Size(245, 21);
            this.comboBoxNotIslemleriAramaDers.TabIndex = 12;
            // 
            // comboBoxNotIslemleriAramaOgrenci
            // 
            this.comboBoxNotIslemleriAramaOgrenci.FormattingEnabled = true;
            this.comboBoxNotIslemleriAramaOgrenci.Location = new System.Drawing.Point(106, 9);
            this.comboBoxNotIslemleriAramaOgrenci.Name = "comboBoxNotIslemleriAramaOgrenci";
            this.comboBoxNotIslemleriAramaOgrenci.Size = new System.Drawing.Size(289, 21);
            this.comboBoxNotIslemleriAramaOgrenci.TabIndex = 11;
            // 
            // radioButtonNotIslemleriAramaNot
            // 
            this.radioButtonNotIslemleriAramaNot.AutoSize = true;
            this.radioButtonNotIslemleriAramaNot.Location = new System.Drawing.Point(4, 80);
            this.radioButtonNotIslemleriAramaNot.Name = "radioButtonNotIslemleriAramaNot";
            this.radioButtonNotIslemleriAramaNot.Size = new System.Drawing.Size(83, 17);
            this.radioButtonNotIslemleriAramaNot.TabIndex = 3;
            this.radioButtonNotIslemleriAramaNot.Text = "Nota Göre : ";
            this.radioButtonNotIslemleriAramaNot.UseVisualStyleBackColor = true;
            this.radioButtonNotIslemleriAramaNot.CheckedChanged += new System.EventHandler(this.radioButtonNotIslemleriAramaNot_CheckedChanged);
            // 
            // radioButtonNotIslemleriAramaDers
            // 
            this.radioButtonNotIslemleriAramaDers.AutoSize = true;
            this.radioButtonNotIslemleriAramaDers.Location = new System.Drawing.Point(4, 45);
            this.radioButtonNotIslemleriAramaDers.Name = "radioButtonNotIslemleriAramaDers";
            this.radioButtonNotIslemleriAramaDers.Size = new System.Drawing.Size(88, 17);
            this.radioButtonNotIslemleriAramaDers.TabIndex = 2;
            this.radioButtonNotIslemleriAramaDers.Text = "Derse Göre : ";
            this.radioButtonNotIslemleriAramaDers.UseVisualStyleBackColor = true;
            this.radioButtonNotIslemleriAramaDers.CheckedChanged += new System.EventHandler(this.radioButtonNotIslemleriAramaDers_CheckedChanged);
            // 
            // radioButtonNotIslemleriAramaOgrenci
            // 
            this.radioButtonNotIslemleriAramaOgrenci.AutoSize = true;
            this.radioButtonNotIslemleriAramaOgrenci.Checked = true;
            this.radioButtonNotIslemleriAramaOgrenci.Location = new System.Drawing.Point(4, 10);
            this.radioButtonNotIslemleriAramaOgrenci.Name = "radioButtonNotIslemleriAramaOgrenci";
            this.radioButtonNotIslemleriAramaOgrenci.Size = new System.Drawing.Size(108, 17);
            this.radioButtonNotIslemleriAramaOgrenci.TabIndex = 1;
            this.radioButtonNotIslemleriAramaOgrenci.TabStop = true;
            this.radioButtonNotIslemleriAramaOgrenci.Text = "Öğrenciye Göre : ";
            this.radioButtonNotIslemleriAramaOgrenci.UseVisualStyleBackColor = true;
            this.radioButtonNotIslemleriAramaOgrenci.CheckedChanged += new System.EventHandler(this.radioButtonNotIslemleriAramaOgrenci_CheckedChanged);
            // 
            // btnNotIslemleriEkleKaydet
            // 
            this.btnNotIslemleriEkleKaydet.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnNotIslemleriEkleKaydet.Location = new System.Drawing.Point(65, 403);
            this.btnNotIslemleriEkleKaydet.Name = "btnNotIslemleriEkleKaydet";
            this.btnNotIslemleriEkleKaydet.Size = new System.Drawing.Size(125, 35);
            this.btnNotIslemleriEkleKaydet.TabIndex = 16;
            this.btnNotIslemleriEkleKaydet.Text = "EKLE / KAYDET";
            this.btnNotIslemleriEkleKaydet.UseVisualStyleBackColor = true;
            this.btnNotIslemleriEkleKaydet.Click += new System.EventHandler(this.btnNotIslemleriEkleKaydet_Click);
            // 
            // txtNotIslemleriNot
            // 
            this.txtNotIslemleriNot.Location = new System.Drawing.Point(65, 372);
            this.txtNotIslemleriNot.Name = "txtNotIslemleriNot";
            this.txtNotIslemleriNot.Size = new System.Drawing.Size(125, 20);
            this.txtNotIslemleriNot.TabIndex = 15;
            this.txtNotIslemleriNot.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNotIslemleriNot_KeyPress);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(6, 375);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(33, 13);
            this.label24.TabIndex = 14;
            this.label24.Text = "Not : ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 341);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(38, 13);
            this.label13.TabIndex = 13;
            this.label13.Text = "Ders : ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 307);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 13);
            this.label12.TabIndex = 12;
            this.label12.Text = "Öğrenci : ";
            // 
            // comboBoxNotIslemleriDers
            // 
            this.comboBoxNotIslemleriDers.FormattingEnabled = true;
            this.comboBoxNotIslemleriDers.Location = new System.Drawing.Point(65, 338);
            this.comboBoxNotIslemleriDers.Name = "comboBoxNotIslemleriDers";
            this.comboBoxNotIslemleriDers.Size = new System.Drawing.Size(282, 21);
            this.comboBoxNotIslemleriDers.TabIndex = 11;
            // 
            // comboBoxNotIslemleriOgrenci
            // 
            this.comboBoxNotIslemleriOgrenci.FormattingEnabled = true;
            this.comboBoxNotIslemleriOgrenci.Location = new System.Drawing.Point(65, 304);
            this.comboBoxNotIslemleriOgrenci.Name = "comboBoxNotIslemleriOgrenci";
            this.comboBoxNotIslemleriOgrenci.Size = new System.Drawing.Size(347, 21);
            this.comboBoxNotIslemleriOgrenci.TabIndex = 10;
            // 
            // radioButtonNotIslemleriAramaIslemi
            // 
            this.radioButtonNotIslemleriAramaIslemi.AutoSize = true;
            this.radioButtonNotIslemleriAramaIslemi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonNotIslemleriAramaIslemi.ForeColor = System.Drawing.Color.Black;
            this.radioButtonNotIslemleriAramaIslemi.Location = new System.Drawing.Point(301, 272);
            this.radioButtonNotIslemleriAramaIslemi.Name = "radioButtonNotIslemleriAramaIslemi";
            this.radioButtonNotIslemleriAramaIslemi.Size = new System.Drawing.Size(113, 17);
            this.radioButtonNotIslemleriAramaIslemi.TabIndex = 9;
            this.radioButtonNotIslemleriAramaIslemi.Text = "ARAMA İŞLEMİ";
            this.radioButtonNotIslemleriAramaIslemi.UseVisualStyleBackColor = true;
            this.radioButtonNotIslemleriAramaIslemi.CheckedChanged += new System.EventHandler(this.radioButtonNotIslemleriAramaIslemi_CheckedChanged);
            // 
            // radioButtonNotIslemleriGuncellemeIslemi
            // 
            this.radioButtonNotIslemleriGuncellemeIslemi.AutoSize = true;
            this.radioButtonNotIslemleriGuncellemeIslemi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonNotIslemleriGuncellemeIslemi.ForeColor = System.Drawing.Color.Black;
            this.radioButtonNotIslemleriGuncellemeIslemi.Location = new System.Drawing.Point(138, 272);
            this.radioButtonNotIslemleriGuncellemeIslemi.Name = "radioButtonNotIslemleriGuncellemeIslemi";
            this.radioButtonNotIslemleriGuncellemeIslemi.Size = new System.Drawing.Size(153, 17);
            this.radioButtonNotIslemleriGuncellemeIslemi.TabIndex = 8;
            this.radioButtonNotIslemleriGuncellemeIslemi.Text = "GÜNCELLEME İŞLEMİ";
            this.radioButtonNotIslemleriGuncellemeIslemi.UseVisualStyleBackColor = true;
            this.radioButtonNotIslemleriGuncellemeIslemi.CheckedChanged += new System.EventHandler(this.radioButtonNotIslemleriGuncellemeIslemi_CheckedChanged);
            // 
            // radioButtonNotIslemleriEklemeIslemi
            // 
            this.radioButtonNotIslemleriEklemeIslemi.AutoSize = true;
            this.radioButtonNotIslemleriEklemeIslemi.Checked = true;
            this.radioButtonNotIslemleriEklemeIslemi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonNotIslemleriEklemeIslemi.ForeColor = System.Drawing.Color.Black;
            this.radioButtonNotIslemleriEklemeIslemi.Location = new System.Drawing.Point(9, 272);
            this.radioButtonNotIslemleriEklemeIslemi.Name = "radioButtonNotIslemleriEklemeIslemi";
            this.radioButtonNotIslemleriEklemeIslemi.Size = new System.Drawing.Size(119, 17);
            this.radioButtonNotIslemleriEklemeIslemi.TabIndex = 7;
            this.radioButtonNotIslemleriEklemeIslemi.TabStop = true;
            this.radioButtonNotIslemleriEklemeIslemi.Text = "EKLEME İŞLEMİ";
            this.radioButtonNotIslemleriEklemeIslemi.UseVisualStyleBackColor = true;
            this.radioButtonNotIslemleriEklemeIslemi.CheckedChanged += new System.EventHandler(this.radioButtonNotIslemleriEklemeIslemi_CheckedChanged);
            // 
            // dataGridViewNotIslemleri
            // 
            this.dataGridViewNotIslemleri.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewNotIslemleri.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewNotIslemleri.Location = new System.Drawing.Point(9, 13);
            this.dataGridViewNotIslemleri.Name = "dataGridViewNotIslemleri";
            this.dataGridViewNotIslemleri.ReadOnly = true;
            this.dataGridViewNotIslemleri.Size = new System.Drawing.Size(1000, 249);
            this.dataGridViewNotIslemleri.TabIndex = 6;
            this.dataGridViewNotIslemleri.SelectionChanged += new System.EventHandler(this.dataGridViewNotIslemleri_SelectionChanged);
            // 
            // panelOgrenciKayitIslemleri
            // 
            this.panelOgrenciKayitIslemleri.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panelOgrenciKayitIslemleri.Controls.Add(this.label23);
            this.panelOgrenciKayitIslemleri.Controls.Add(this.label22);
            this.panelOgrenciKayitIslemleri.Controls.Add(this.dateTimePickerKayitIslemleri);
            this.panelOgrenciKayitIslemleri.Controls.Add(this.panel2);
            this.panelOgrenciKayitIslemleri.Controls.Add(this.label21);
            this.panelOgrenciKayitIslemleri.Controls.Add(this.txtOgrKayitIslemleriAdres);
            this.panelOgrenciKayitIslemleri.Controls.Add(this.label20);
            this.panelOgrenciKayitIslemleri.Controls.Add(this.txtOgrKayitIslemleriTelefon);
            this.panelOgrenciKayitIslemleri.Controls.Add(this.label19);
            this.panelOgrenciKayitIslemleri.Controls.Add(this.txtOgrKayitIslemleriSoyisim);
            this.panelOgrenciKayitIslemleri.Controls.Add(this.label16);
            this.panelOgrenciKayitIslemleri.Controls.Add(this.txtOgrKayitIslemleriIsim);
            this.panelOgrenciKayitIslemleri.Controls.Add(this.label14);
            this.panelOgrenciKayitIslemleri.Controls.Add(this.txtOgrKayitIslemleriTC);
            this.panelOgrenciKayitIslemleri.Controls.Add(this.radioButtonOgrKayitIslemleriGuncellemeIslemi);
            this.panelOgrenciKayitIslemleri.Controls.Add(this.radioButtonOgrKayitIslemleriEklemeIslemi);
            this.panelOgrenciKayitIslemleri.Controls.Add(this.dataGridViewOgrenciEkleCikar);
            this.panelOgrenciKayitIslemleri.Controls.Add(this.btnOgrKayitIslemleriEkle);
            this.panelOgrenciKayitIslemleri.Controls.Add(this.btnOgrKayitIslemleriGuncelle);
            this.panelOgrenciKayitIslemleri.Location = new System.Drawing.Point(3, 27);
            this.panelOgrenciKayitIslemleri.Name = "panelOgrenciKayitIslemleri";
            this.panelOgrenciKayitIslemleri.Size = new System.Drawing.Size(1018, 543);
            this.panelOgrenciKayitIslemleri.TabIndex = 3;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(6, 460);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(79, 13);
            this.label23.TabIndex = 20;
            this.label23.Text = "Doğum Tarihi : ";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(6, 411);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(52, 13);
            this.label22.TabIndex = 19;
            this.label22.Text = "Cinsiyet : ";
            // 
            // dateTimePickerKayitIslemleri
            // 
            this.dateTimePickerKayitIslemleri.Location = new System.Drawing.Point(115, 458);
            this.dateTimePickerKayitIslemleri.MaxDate = new System.DateTime(2099, 12, 31, 0, 0, 0, 0);
            this.dateTimePickerKayitIslemleri.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.dateTimePickerKayitIslemleri.Name = "dateTimePickerKayitIslemleri";
            this.dateTimePickerKayitIslemleri.Size = new System.Drawing.Size(200, 20);
            this.dateTimePickerKayitIslemleri.TabIndex = 18;
            this.dateTimePickerKayitIslemleri.Value = new System.DateTime(2020, 12, 7, 0, 0, 0, 0);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.radioButtonOgrKayitIslemleriErkek);
            this.panel2.Controls.Add(this.radioButtonOgrKayitIslemleriKadin);
            this.panel2.Location = new System.Drawing.Point(115, 406);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(176, 20);
            this.panel2.TabIndex = 16;
            // 
            // radioButtonOgrKayitIslemleriErkek
            // 
            this.radioButtonOgrKayitIslemleriErkek.AutoSize = true;
            this.radioButtonOgrKayitIslemleriErkek.Checked = true;
            this.radioButtonOgrKayitIslemleriErkek.Location = new System.Drawing.Point(3, 3);
            this.radioButtonOgrKayitIslemleriErkek.Name = "radioButtonOgrKayitIslemleriErkek";
            this.radioButtonOgrKayitIslemleriErkek.Size = new System.Drawing.Size(53, 17);
            this.radioButtonOgrKayitIslemleriErkek.TabIndex = 10;
            this.radioButtonOgrKayitIslemleriErkek.TabStop = true;
            this.radioButtonOgrKayitIslemleriErkek.Text = "Erkek";
            this.radioButtonOgrKayitIslemleriErkek.UseVisualStyleBackColor = true;
            // 
            // radioButtonOgrKayitIslemleriKadin
            // 
            this.radioButtonOgrKayitIslemleriKadin.AutoSize = true;
            this.radioButtonOgrKayitIslemleriKadin.Location = new System.Drawing.Point(79, 3);
            this.radioButtonOgrKayitIslemleriKadin.Name = "radioButtonOgrKayitIslemleriKadin";
            this.radioButtonOgrKayitIslemleriKadin.Size = new System.Drawing.Size(52, 17);
            this.radioButtonOgrKayitIslemleriKadin.TabIndex = 11;
            this.radioButtonOgrKayitIslemleriKadin.Text = "Kadın";
            this.radioButtonOgrKayitIslemleriKadin.UseVisualStyleBackColor = true;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(6, 435);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(43, 13);
            this.label21.TabIndex = 15;
            this.label21.Text = "Adres : ";
            // 
            // txtOgrKayitIslemleriAdres
            // 
            this.txtOgrKayitIslemleriAdres.Location = new System.Drawing.Point(115, 432);
            this.txtOgrKayitIslemleriAdres.Name = "txtOgrKayitIslemleriAdres";
            this.txtOgrKayitIslemleriAdres.Size = new System.Drawing.Size(176, 20);
            this.txtOgrKayitIslemleriAdres.TabIndex = 14;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(6, 383);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(52, 13);
            this.label20.TabIndex = 13;
            this.label20.Text = "Telefon : ";
            // 
            // txtOgrKayitIslemleriTelefon
            // 
            this.txtOgrKayitIslemleriTelefon.Location = new System.Drawing.Point(115, 378);
            this.txtOgrKayitIslemleriTelefon.MaxLength = 10;
            this.txtOgrKayitIslemleriTelefon.Name = "txtOgrKayitIslemleriTelefon";
            this.txtOgrKayitIslemleriTelefon.Size = new System.Drawing.Size(176, 20);
            this.txtOgrKayitIslemleriTelefon.TabIndex = 12;
            this.txtOgrKayitIslemleriTelefon.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOgrKayitIslemleriTelefon_KeyPress);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(6, 355);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(51, 13);
            this.label19.TabIndex = 11;
            this.label19.Text = "Soyisim : ";
            // 
            // txtOgrKayitIslemleriSoyisim
            // 
            this.txtOgrKayitIslemleriSoyisim.Location = new System.Drawing.Point(115, 352);
            this.txtOgrKayitIslemleriSoyisim.Name = "txtOgrKayitIslemleriSoyisim";
            this.txtOgrKayitIslemleriSoyisim.Size = new System.Drawing.Size(176, 20);
            this.txtOgrKayitIslemleriSoyisim.TabIndex = 10;
            this.txtOgrKayitIslemleriSoyisim.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOgrKayitIslemleriSoyisim_KeyPress);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 329);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(34, 13);
            this.label16.TabIndex = 9;
            this.label16.Text = "İsim : ";
            // 
            // txtOgrKayitIslemleriIsim
            // 
            this.txtOgrKayitIslemleriIsim.Location = new System.Drawing.Point(115, 326);
            this.txtOgrKayitIslemleriIsim.Name = "txtOgrKayitIslemleriIsim";
            this.txtOgrKayitIslemleriIsim.Size = new System.Drawing.Size(176, 20);
            this.txtOgrKayitIslemleriIsim.TabIndex = 8;
            this.txtOgrKayitIslemleriIsim.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOgrKayitIslemleriIsim_KeyPress);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 301);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(57, 13);
            this.label14.TabIndex = 7;
            this.label14.Text = "TC Kimlik :";
            // 
            // txtOgrKayitIslemleriTC
            // 
            this.txtOgrKayitIslemleriTC.Location = new System.Drawing.Point(115, 300);
            this.txtOgrKayitIslemleriTC.MaxLength = 11;
            this.txtOgrKayitIslemleriTC.Name = "txtOgrKayitIslemleriTC";
            this.txtOgrKayitIslemleriTC.Size = new System.Drawing.Size(176, 20);
            this.txtOgrKayitIslemleriTC.TabIndex = 6;
            this.txtOgrKayitIslemleriTC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOgrKayitIslemleriTC_KeyPress);
            // 
            // radioButtonOgrKayitIslemleriGuncellemeIslemi
            // 
            this.radioButtonOgrKayitIslemleriGuncellemeIslemi.AutoSize = true;
            this.radioButtonOgrKayitIslemleriGuncellemeIslemi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonOgrKayitIslemleriGuncellemeIslemi.ForeColor = System.Drawing.Color.Black;
            this.radioButtonOgrKayitIslemleriGuncellemeIslemi.Location = new System.Drawing.Point(138, 274);
            this.radioButtonOgrKayitIslemleriGuncellemeIslemi.Name = "radioButtonOgrKayitIslemleriGuncellemeIslemi";
            this.radioButtonOgrKayitIslemleriGuncellemeIslemi.Size = new System.Drawing.Size(153, 17);
            this.radioButtonOgrKayitIslemleriGuncellemeIslemi.TabIndex = 5;
            this.radioButtonOgrKayitIslemleriGuncellemeIslemi.Text = "GÜNCELLEME İŞLEMİ";
            this.radioButtonOgrKayitIslemleriGuncellemeIslemi.UseVisualStyleBackColor = true;
            this.radioButtonOgrKayitIslemleriGuncellemeIslemi.CheckedChanged += new System.EventHandler(this.radioButtonOgrKayitIslemleriGuncellemeIslemi_CheckedChanged);
            // 
            // radioButtonOgrKayitIslemleriEklemeIslemi
            // 
            this.radioButtonOgrKayitIslemleriEklemeIslemi.AutoSize = true;
            this.radioButtonOgrKayitIslemleriEklemeIslemi.Checked = true;
            this.radioButtonOgrKayitIslemleriEklemeIslemi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonOgrKayitIslemleriEklemeIslemi.ForeColor = System.Drawing.Color.Black;
            this.radioButtonOgrKayitIslemleriEklemeIslemi.Location = new System.Drawing.Point(9, 274);
            this.radioButtonOgrKayitIslemleriEklemeIslemi.Name = "radioButtonOgrKayitIslemleriEklemeIslemi";
            this.radioButtonOgrKayitIslemleriEklemeIslemi.Size = new System.Drawing.Size(119, 17);
            this.radioButtonOgrKayitIslemleriEklemeIslemi.TabIndex = 4;
            this.radioButtonOgrKayitIslemleriEklemeIslemi.TabStop = true;
            this.radioButtonOgrKayitIslemleriEklemeIslemi.Text = "EKLEME İŞLEMİ";
            this.radioButtonOgrKayitIslemleriEklemeIslemi.UseVisualStyleBackColor = true;
            this.radioButtonOgrKayitIslemleriEklemeIslemi.CheckedChanged += new System.EventHandler(this.radioButtonOgrKayitIslemleriEklemeIslemi_CheckedChanged);
            // 
            // dataGridViewOgrenciEkleCikar
            // 
            this.dataGridViewOgrenciEkleCikar.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewOgrenciEkleCikar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewOgrenciEkleCikar.Location = new System.Drawing.Point(9, 13);
            this.dataGridViewOgrenciEkleCikar.Name = "dataGridViewOgrenciEkleCikar";
            this.dataGridViewOgrenciEkleCikar.ReadOnly = true;
            this.dataGridViewOgrenciEkleCikar.Size = new System.Drawing.Size(1000, 249);
            this.dataGridViewOgrenciEkleCikar.TabIndex = 3;
            this.dataGridViewOgrenciEkleCikar.SelectionChanged += new System.EventHandler(this.dataGridViewOgrenciEkleCikar_SelectionChanged);
            // 
            // btnOgrKayitIslemleriEkle
            // 
            this.btnOgrKayitIslemleriEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnOgrKayitIslemleriEkle.Location = new System.Drawing.Point(115, 486);
            this.btnOgrKayitIslemleriEkle.Name = "btnOgrKayitIslemleriEkle";
            this.btnOgrKayitIslemleriEkle.Size = new System.Drawing.Size(176, 36);
            this.btnOgrKayitIslemleriEkle.TabIndex = 21;
            this.btnOgrKayitIslemleriEkle.Text = "EKLE";
            this.btnOgrKayitIslemleriEkle.UseVisualStyleBackColor = true;
            this.btnOgrKayitIslemleriEkle.Click += new System.EventHandler(this.btnOgrKayitIslemleriEkle_Click);
            // 
            // btnOgrKayitIslemleriGuncelle
            // 
            this.btnOgrKayitIslemleriGuncelle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnOgrKayitIslemleriGuncelle.Location = new System.Drawing.Point(115, 486);
            this.btnOgrKayitIslemleriGuncelle.Name = "btnOgrKayitIslemleriGuncelle";
            this.btnOgrKayitIslemleriGuncelle.Size = new System.Drawing.Size(176, 36);
            this.btnOgrKayitIslemleriGuncelle.TabIndex = 22;
            this.btnOgrKayitIslemleriGuncelle.Text = "GÜNCELLE";
            this.btnOgrKayitIslemleriGuncelle.UseVisualStyleBackColor = true;
            this.btnOgrKayitIslemleriGuncelle.Click += new System.EventHandler(this.btnOgrKayitIslemleriGuncelle_Click);
            // 
            // panelEtutleriGoruntule
            // 
            this.panelEtutleriGoruntule.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panelEtutleriGoruntule.Controls.Add(this.btnEtutGoruntuleAraSil);
            this.panelEtutleriGoruntule.Controls.Add(this.panel3);
            this.panelEtutleriGoruntule.Controls.Add(this.dateTimePickerEtutGotunrule);
            this.panelEtutleriGoruntule.Controls.Add(this.radioButtonEtutGoruntuleTarih);
            this.panelEtutleriGoruntule.Controls.Add(this.comboBoxEtutGoruntuleDers);
            this.panelEtutleriGoruntule.Controls.Add(this.comboBoxEtutGoruntuleOgretmen);
            this.panelEtutleriGoruntule.Controls.Add(this.radioButtonEtutGoruntuleDers);
            this.panelEtutleriGoruntule.Controls.Add(this.radioButtonEtutGoruntuleOgretmen);
            this.panelEtutleriGoruntule.Controls.Add(this.comboBoxEtutGoruntuleOgrenci);
            this.panelEtutleriGoruntule.Controls.Add(this.radioButtonEtutGoruntuleOgrenci);
            this.panelEtutleriGoruntule.Controls.Add(this.dataGridViewEtutGoruntule);
            this.panelEtutleriGoruntule.Location = new System.Drawing.Point(3, 27);
            this.panelEtutleriGoruntule.Name = "panelEtutleriGoruntule";
            this.panelEtutleriGoruntule.Size = new System.Drawing.Size(1018, 543);
            this.panelEtutleriGoruntule.TabIndex = 6;
            // 
            // btnEtutGoruntuleAraSil
            // 
            this.btnEtutGoruntuleAraSil.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnEtutGoruntuleAraSil.Location = new System.Drawing.Point(160, 178);
            this.btnEtutGoruntuleAraSil.Name = "btnEtutGoruntuleAraSil";
            this.btnEtutGoruntuleAraSil.Size = new System.Drawing.Size(118, 39);
            this.btnEtutGoruntuleAraSil.TabIndex = 43;
            this.btnEtutGoruntuleAraSil.Text = "ARA / SİL";
            this.btnEtutGoruntuleAraSil.UseVisualStyleBackColor = true;
            this.btnEtutGoruntuleAraSil.Click += new System.EventHandler(this.btnEtutGoruntuleAraSil_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.radioButtonEtutGoruntuleSilmeIslemi);
            this.panel3.Controls.Add(this.radioButtonEtutGoruntuleAramaIslemi);
            this.panel3.Location = new System.Drawing.Point(7, 5);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(244, 30);
            this.panel3.TabIndex = 42;
            // 
            // radioButtonEtutGoruntuleSilmeIslemi
            // 
            this.radioButtonEtutGoruntuleSilmeIslemi.AutoSize = true;
            this.radioButtonEtutGoruntuleSilmeIslemi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonEtutGoruntuleSilmeIslemi.Location = new System.Drawing.Point(127, 4);
            this.radioButtonEtutGoruntuleSilmeIslemi.Name = "radioButtonEtutGoruntuleSilmeIslemi";
            this.radioButtonEtutGoruntuleSilmeIslemi.Size = new System.Drawing.Size(111, 21);
            this.radioButtonEtutGoruntuleSilmeIslemi.TabIndex = 37;
            this.radioButtonEtutGoruntuleSilmeIslemi.Text = "Silme İşlemi";
            this.radioButtonEtutGoruntuleSilmeIslemi.UseVisualStyleBackColor = true;
            // 
            // radioButtonEtutGoruntuleAramaIslemi
            // 
            this.radioButtonEtutGoruntuleAramaIslemi.AutoSize = true;
            this.radioButtonEtutGoruntuleAramaIslemi.Checked = true;
            this.radioButtonEtutGoruntuleAramaIslemi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonEtutGoruntuleAramaIslemi.Location = new System.Drawing.Point(3, 4);
            this.radioButtonEtutGoruntuleAramaIslemi.Name = "radioButtonEtutGoruntuleAramaIslemi";
            this.radioButtonEtutGoruntuleAramaIslemi.Size = new System.Drawing.Size(118, 21);
            this.radioButtonEtutGoruntuleAramaIslemi.TabIndex = 33;
            this.radioButtonEtutGoruntuleAramaIslemi.TabStop = true;
            this.radioButtonEtutGoruntuleAramaIslemi.Text = "Arama İşlemi";
            this.radioButtonEtutGoruntuleAramaIslemi.UseVisualStyleBackColor = true;
            // 
            // dateTimePickerEtutGotunrule
            // 
            this.dateTimePickerEtutGotunrule.Enabled = false;
            this.dateTimePickerEtutGotunrule.Location = new System.Drawing.Point(160, 143);
            this.dateTimePickerEtutGotunrule.Name = "dateTimePickerEtutGotunrule";
            this.dateTimePickerEtutGotunrule.Size = new System.Drawing.Size(200, 20);
            this.dateTimePickerEtutGotunrule.TabIndex = 41;
            // 
            // radioButtonEtutGoruntuleTarih
            // 
            this.radioButtonEtutGoruntuleTarih.AutoSize = true;
            this.radioButtonEtutGoruntuleTarih.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonEtutGoruntuleTarih.Location = new System.Drawing.Point(9, 143);
            this.radioButtonEtutGoruntuleTarih.Name = "radioButtonEtutGoruntuleTarih";
            this.radioButtonEtutGoruntuleTarih.Size = new System.Drawing.Size(115, 21);
            this.radioButtonEtutGoruntuleTarih.TabIndex = 40;
            this.radioButtonEtutGoruntuleTarih.Text = "Tarihe Göre : ";
            this.radioButtonEtutGoruntuleTarih.UseVisualStyleBackColor = true;
            this.radioButtonEtutGoruntuleTarih.CheckedChanged += new System.EventHandler(this.radioButtonEtutGoruntuleTarih_CheckedChanged);
            // 
            // comboBoxEtutGoruntuleDers
            // 
            this.comboBoxEtutGoruntuleDers.Enabled = false;
            this.comboBoxEtutGoruntuleDers.FormattingEnabled = true;
            this.comboBoxEtutGoruntuleDers.Location = new System.Drawing.Point(160, 109);
            this.comboBoxEtutGoruntuleDers.Name = "comboBoxEtutGoruntuleDers";
            this.comboBoxEtutGoruntuleDers.Size = new System.Drawing.Size(245, 21);
            this.comboBoxEtutGoruntuleDers.TabIndex = 39;
            // 
            // comboBoxEtutGoruntuleOgretmen
            // 
            this.comboBoxEtutGoruntuleOgretmen.Enabled = false;
            this.comboBoxEtutGoruntuleOgretmen.FormattingEnabled = true;
            this.comboBoxEtutGoruntuleOgretmen.Location = new System.Drawing.Point(160, 75);
            this.comboBoxEtutGoruntuleOgretmen.Name = "comboBoxEtutGoruntuleOgretmen";
            this.comboBoxEtutGoruntuleOgretmen.Size = new System.Drawing.Size(289, 21);
            this.comboBoxEtutGoruntuleOgretmen.TabIndex = 38;
            // 
            // radioButtonEtutGoruntuleDers
            // 
            this.radioButtonEtutGoruntuleDers.AutoSize = true;
            this.radioButtonEtutGoruntuleDers.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonEtutGoruntuleDers.Location = new System.Drawing.Point(9, 109);
            this.radioButtonEtutGoruntuleDers.Name = "radioButtonEtutGoruntuleDers";
            this.radioButtonEtutGoruntuleDers.Size = new System.Drawing.Size(112, 21);
            this.radioButtonEtutGoruntuleDers.TabIndex = 37;
            this.radioButtonEtutGoruntuleDers.Text = "Derse Göre : ";
            this.radioButtonEtutGoruntuleDers.UseVisualStyleBackColor = true;
            this.radioButtonEtutGoruntuleDers.CheckedChanged += new System.EventHandler(this.radioButtonEtutGoruntuleDers_CheckedChanged);
            // 
            // radioButtonEtutGoruntuleOgretmen
            // 
            this.radioButtonEtutGoruntuleOgretmen.AutoSize = true;
            this.radioButtonEtutGoruntuleOgretmen.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonEtutGoruntuleOgretmen.Location = new System.Drawing.Point(9, 74);
            this.radioButtonEtutGoruntuleOgretmen.Name = "radioButtonEtutGoruntuleOgretmen";
            this.radioButtonEtutGoruntuleOgretmen.Size = new System.Drawing.Size(145, 21);
            this.radioButtonEtutGoruntuleOgretmen.TabIndex = 36;
            this.radioButtonEtutGoruntuleOgretmen.Text = "Öğretmene Göre : ";
            this.radioButtonEtutGoruntuleOgretmen.UseVisualStyleBackColor = true;
            this.radioButtonEtutGoruntuleOgretmen.CheckedChanged += new System.EventHandler(this.radioButtonEtutGoruntuleOgretmen_CheckedChanged);
            // 
            // comboBoxEtutGoruntuleOgrenci
            // 
            this.comboBoxEtutGoruntuleOgrenci.FormattingEnabled = true;
            this.comboBoxEtutGoruntuleOgrenci.Location = new System.Drawing.Point(160, 41);
            this.comboBoxEtutGoruntuleOgrenci.Name = "comboBoxEtutGoruntuleOgrenci";
            this.comboBoxEtutGoruntuleOgrenci.Size = new System.Drawing.Size(289, 21);
            this.comboBoxEtutGoruntuleOgrenci.TabIndex = 34;
            // 
            // radioButtonEtutGoruntuleOgrenci
            // 
            this.radioButtonEtutGoruntuleOgrenci.AutoSize = true;
            this.radioButtonEtutGoruntuleOgrenci.Checked = true;
            this.radioButtonEtutGoruntuleOgrenci.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonEtutGoruntuleOgrenci.Location = new System.Drawing.Point(9, 40);
            this.radioButtonEtutGoruntuleOgrenci.Name = "radioButtonEtutGoruntuleOgrenci";
            this.radioButtonEtutGoruntuleOgrenci.Size = new System.Drawing.Size(139, 21);
            this.radioButtonEtutGoruntuleOgrenci.TabIndex = 32;
            this.radioButtonEtutGoruntuleOgrenci.TabStop = true;
            this.radioButtonEtutGoruntuleOgrenci.Text = "Öğrenciye Göre : ";
            this.radioButtonEtutGoruntuleOgrenci.UseVisualStyleBackColor = true;
            this.radioButtonEtutGoruntuleOgrenci.CheckedChanged += new System.EventHandler(this.radioButtonEtutGoruntuleOgrenci_CheckedChanged);
            // 
            // dataGridViewEtutGoruntule
            // 
            this.dataGridViewEtutGoruntule.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewEtutGoruntule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewEtutGoruntule.Location = new System.Drawing.Point(9, 267);
            this.dataGridViewEtutGoruntule.Name = "dataGridViewEtutGoruntule";
            this.dataGridViewEtutGoruntule.ReadOnly = true;
            this.dataGridViewEtutGoruntule.Size = new System.Drawing.Size(1000, 249);
            this.dataGridViewEtutGoruntule.TabIndex = 31;
            // 
            // panelYeniEtüt
            // 
            this.panelYeniEtüt.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panelYeniEtüt.Controls.Add(this.label147);
            this.panelYeniEtüt.Controls.Add(this.comboBoxEtutDers);
            this.panelYeniEtüt.Controls.Add(this.txtEtutUcret);
            this.panelYeniEtüt.Controls.Add(this.label95);
            this.panelYeniEtüt.Controls.Add(this.btnEtutEkle);
            this.panelYeniEtüt.Controls.Add(this.dataGridViewEtutEkleme);
            this.panelYeniEtüt.Controls.Add(this.btnEtut22);
            this.panelYeniEtüt.Controls.Add(this.btnEtut21);
            this.panelYeniEtüt.Controls.Add(this.btnEtut20);
            this.panelYeniEtüt.Controls.Add(this.btnEtut19);
            this.panelYeniEtüt.Controls.Add(this.btnEtut18);
            this.panelYeniEtüt.Controls.Add(this.btnEtut17);
            this.panelYeniEtüt.Controls.Add(this.btnEtut16);
            this.panelYeniEtüt.Controls.Add(this.btnEtut15);
            this.panelYeniEtüt.Controls.Add(this.btnEtut14);
            this.panelYeniEtüt.Controls.Add(this.btnEtut13);
            this.panelYeniEtüt.Controls.Add(this.btnEtut12);
            this.panelYeniEtüt.Controls.Add(this.btnEtut11);
            this.panelYeniEtüt.Controls.Add(this.btnEtut10);
            this.panelYeniEtüt.Controls.Add(this.btnEtut09);
            this.panelYeniEtüt.Controls.Add(this.btnEtut08);
            this.panelYeniEtüt.Controls.Add(this.dateTimePickerEtutTarih);
            this.panelYeniEtüt.Controls.Add(this.label96);
            this.panelYeniEtüt.Controls.Add(this.label93);
            this.panelYeniEtüt.Controls.Add(this.label11);
            this.panelYeniEtüt.Controls.Add(this.comboBoxEtutOgretmen);
            this.panelYeniEtüt.Controls.Add(this.comboBoxEtutOgrenci);
            this.panelYeniEtüt.Location = new System.Drawing.Point(3, 27);
            this.panelYeniEtüt.Name = "panelYeniEtüt";
            this.panelYeniEtüt.Size = new System.Drawing.Size(1018, 543);
            this.panelYeniEtüt.TabIndex = 5;
            // 
            // label147
            // 
            this.label147.AutoSize = true;
            this.label147.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label147.Location = new System.Drawing.Point(10, 88);
            this.label147.Name = "label147";
            this.label147.Size = new System.Drawing.Size(50, 17);
            this.label147.TabIndex = 36;
            this.label147.Text = "Ders : ";
            // 
            // comboBoxEtutDers
            // 
            this.comboBoxEtutDers.FormattingEnabled = true;
            this.comboBoxEtutDers.Location = new System.Drawing.Point(108, 87);
            this.comboBoxEtutDers.Name = "comboBoxEtutDers";
            this.comboBoxEtutDers.Size = new System.Drawing.Size(272, 21);
            this.comboBoxEtutDers.TabIndex = 35;
            // 
            // txtEtutUcret
            // 
            this.txtEtutUcret.Location = new System.Drawing.Point(108, 170);
            this.txtEtutUcret.Name = "txtEtutUcret";
            this.txtEtutUcret.Size = new System.Drawing.Size(272, 20);
            this.txtEtutUcret.TabIndex = 34;
            this.txtEtutUcret.Text = "0";
            this.txtEtutUcret.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEtutUcret_KeyPress);
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label95.Location = new System.Drawing.Point(9, 171);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(54, 17);
            this.label95.TabIndex = 33;
            this.label95.Text = "Ücret : ";
            // 
            // btnEtutEkle
            // 
            this.btnEtutEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnEtutEkle.Location = new System.Drawing.Point(179, 207);
            this.btnEtutEkle.Name = "btnEtutEkle";
            this.btnEtutEkle.Size = new System.Drawing.Size(119, 41);
            this.btnEtutEkle.TabIndex = 31;
            this.btnEtutEkle.Text = "EKLE";
            this.btnEtutEkle.UseVisualStyleBackColor = true;
            this.btnEtutEkle.Click += new System.EventHandler(this.btnEtutEkle_Click);
            // 
            // dataGridViewEtutEkleme
            // 
            this.dataGridViewEtutEkleme.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewEtutEkleme.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewEtutEkleme.Location = new System.Drawing.Point(9, 267);
            this.dataGridViewEtutEkleme.Name = "dataGridViewEtutEkleme";
            this.dataGridViewEtutEkleme.ReadOnly = true;
            this.dataGridViewEtutEkleme.Size = new System.Drawing.Size(1000, 249);
            this.dataGridViewEtutEkleme.TabIndex = 30;
            // 
            // btnEtut22
            // 
            this.btnEtut22.BackColor = System.Drawing.Color.LimeGreen;
            this.btnEtut22.Location = new System.Drawing.Point(644, 102);
            this.btnEtut22.Name = "btnEtut22";
            this.btnEtut22.Size = new System.Drawing.Size(54, 40);
            this.btnEtut22.TabIndex = 22;
            this.btnEtut22.Text = "22:00";
            this.btnEtut22.UseVisualStyleBackColor = false;
            this.btnEtut22.Click += new System.EventHandler(this.btnEtut22_Click);
            // 
            // btnEtut21
            // 
            this.btnEtut21.BackColor = System.Drawing.Color.LimeGreen;
            this.btnEtut21.Location = new System.Drawing.Point(585, 102);
            this.btnEtut21.Name = "btnEtut21";
            this.btnEtut21.Size = new System.Drawing.Size(54, 40);
            this.btnEtut21.TabIndex = 21;
            this.btnEtut21.Text = "21:00";
            this.btnEtut21.UseVisualStyleBackColor = false;
            this.btnEtut21.Click += new System.EventHandler(this.btnEtut22_Click);
            // 
            // btnEtut20
            // 
            this.btnEtut20.BackColor = System.Drawing.Color.LimeGreen;
            this.btnEtut20.Location = new System.Drawing.Point(527, 102);
            this.btnEtut20.Name = "btnEtut20";
            this.btnEtut20.Size = new System.Drawing.Size(54, 40);
            this.btnEtut20.TabIndex = 20;
            this.btnEtut20.Text = "20:00";
            this.btnEtut20.UseVisualStyleBackColor = false;
            this.btnEtut20.Click += new System.EventHandler(this.btnEtut22_Click);
            // 
            // btnEtut19
            // 
            this.btnEtut19.BackColor = System.Drawing.Color.LimeGreen;
            this.btnEtut19.Location = new System.Drawing.Point(469, 102);
            this.btnEtut19.Name = "btnEtut19";
            this.btnEtut19.Size = new System.Drawing.Size(54, 40);
            this.btnEtut19.TabIndex = 19;
            this.btnEtut19.Text = "19:00";
            this.btnEtut19.UseVisualStyleBackColor = false;
            this.btnEtut19.Click += new System.EventHandler(this.btnEtut22_Click);
            // 
            // btnEtut18
            // 
            this.btnEtut18.BackColor = System.Drawing.Color.LimeGreen;
            this.btnEtut18.Location = new System.Drawing.Point(411, 102);
            this.btnEtut18.Name = "btnEtut18";
            this.btnEtut18.Size = new System.Drawing.Size(54, 40);
            this.btnEtut18.TabIndex = 18;
            this.btnEtut18.Text = "18:00";
            this.btnEtut18.UseVisualStyleBackColor = false;
            this.btnEtut18.Click += new System.EventHandler(this.btnEtut22_Click);
            // 
            // btnEtut17
            // 
            this.btnEtut17.BackColor = System.Drawing.Color.LimeGreen;
            this.btnEtut17.Location = new System.Drawing.Point(644, 58);
            this.btnEtut17.Name = "btnEtut17";
            this.btnEtut17.Size = new System.Drawing.Size(54, 40);
            this.btnEtut17.TabIndex = 17;
            this.btnEtut17.Text = "17:00";
            this.btnEtut17.UseVisualStyleBackColor = false;
            this.btnEtut17.Click += new System.EventHandler(this.btnEtut22_Click);
            // 
            // btnEtut16
            // 
            this.btnEtut16.BackColor = System.Drawing.Color.LimeGreen;
            this.btnEtut16.Location = new System.Drawing.Point(585, 58);
            this.btnEtut16.Name = "btnEtut16";
            this.btnEtut16.Size = new System.Drawing.Size(54, 40);
            this.btnEtut16.TabIndex = 16;
            this.btnEtut16.Text = "16:00";
            this.btnEtut16.UseVisualStyleBackColor = false;
            this.btnEtut16.Click += new System.EventHandler(this.btnEtut22_Click);
            // 
            // btnEtut15
            // 
            this.btnEtut15.BackColor = System.Drawing.Color.LimeGreen;
            this.btnEtut15.Location = new System.Drawing.Point(527, 58);
            this.btnEtut15.Name = "btnEtut15";
            this.btnEtut15.Size = new System.Drawing.Size(54, 40);
            this.btnEtut15.TabIndex = 15;
            this.btnEtut15.Text = "15:00";
            this.btnEtut15.UseVisualStyleBackColor = false;
            this.btnEtut15.Click += new System.EventHandler(this.btnEtut22_Click);
            // 
            // btnEtut14
            // 
            this.btnEtut14.BackColor = System.Drawing.Color.LimeGreen;
            this.btnEtut14.Location = new System.Drawing.Point(469, 58);
            this.btnEtut14.Name = "btnEtut14";
            this.btnEtut14.Size = new System.Drawing.Size(54, 40);
            this.btnEtut14.TabIndex = 14;
            this.btnEtut14.Text = "14:00";
            this.btnEtut14.UseVisualStyleBackColor = false;
            this.btnEtut14.Click += new System.EventHandler(this.btnEtut22_Click);
            // 
            // btnEtut13
            // 
            this.btnEtut13.BackColor = System.Drawing.Color.LimeGreen;
            this.btnEtut13.Location = new System.Drawing.Point(411, 58);
            this.btnEtut13.Name = "btnEtut13";
            this.btnEtut13.Size = new System.Drawing.Size(54, 40);
            this.btnEtut13.TabIndex = 13;
            this.btnEtut13.Text = "13:00";
            this.btnEtut13.UseVisualStyleBackColor = false;
            this.btnEtut13.Click += new System.EventHandler(this.btnEtut22_Click);
            // 
            // btnEtut12
            // 
            this.btnEtut12.BackColor = System.Drawing.Color.LimeGreen;
            this.btnEtut12.Location = new System.Drawing.Point(644, 15);
            this.btnEtut12.Name = "btnEtut12";
            this.btnEtut12.Size = new System.Drawing.Size(54, 40);
            this.btnEtut12.TabIndex = 12;
            this.btnEtut12.Text = "12:00";
            this.btnEtut12.UseVisualStyleBackColor = false;
            this.btnEtut12.Click += new System.EventHandler(this.btnEtut22_Click);
            // 
            // btnEtut11
            // 
            this.btnEtut11.BackColor = System.Drawing.Color.LimeGreen;
            this.btnEtut11.Location = new System.Drawing.Point(585, 15);
            this.btnEtut11.Name = "btnEtut11";
            this.btnEtut11.Size = new System.Drawing.Size(54, 40);
            this.btnEtut11.TabIndex = 11;
            this.btnEtut11.Text = "11:00";
            this.btnEtut11.UseVisualStyleBackColor = false;
            this.btnEtut11.Click += new System.EventHandler(this.btnEtut22_Click);
            // 
            // btnEtut10
            // 
            this.btnEtut10.BackColor = System.Drawing.Color.LimeGreen;
            this.btnEtut10.Location = new System.Drawing.Point(527, 15);
            this.btnEtut10.Name = "btnEtut10";
            this.btnEtut10.Size = new System.Drawing.Size(54, 40);
            this.btnEtut10.TabIndex = 10;
            this.btnEtut10.Text = "10:00";
            this.btnEtut10.UseVisualStyleBackColor = false;
            this.btnEtut10.Click += new System.EventHandler(this.btnEtut22_Click);
            // 
            // btnEtut09
            // 
            this.btnEtut09.BackColor = System.Drawing.Color.LimeGreen;
            this.btnEtut09.Location = new System.Drawing.Point(469, 15);
            this.btnEtut09.Name = "btnEtut09";
            this.btnEtut09.Size = new System.Drawing.Size(54, 40);
            this.btnEtut09.TabIndex = 9;
            this.btnEtut09.Text = "09:00";
            this.btnEtut09.UseVisualStyleBackColor = false;
            this.btnEtut09.Click += new System.EventHandler(this.btnEtut22_Click);
            // 
            // btnEtut08
            // 
            this.btnEtut08.BackColor = System.Drawing.Color.LimeGreen;
            this.btnEtut08.Location = new System.Drawing.Point(411, 15);
            this.btnEtut08.Name = "btnEtut08";
            this.btnEtut08.Size = new System.Drawing.Size(54, 40);
            this.btnEtut08.TabIndex = 8;
            this.btnEtut08.Text = "08:00";
            this.btnEtut08.UseVisualStyleBackColor = false;
            this.btnEtut08.Click += new System.EventHandler(this.btnEtut22_Click);
            // 
            // dateTimePickerEtutTarih
            // 
            this.dateTimePickerEtutTarih.Location = new System.Drawing.Point(108, 127);
            this.dateTimePickerEtutTarih.MaxDate = new System.DateTime(2100, 12, 31, 0, 0, 0, 0);
            this.dateTimePickerEtutTarih.MinDate = new System.DateTime(2020, 12, 10, 0, 0, 0, 0);
            this.dateTimePickerEtutTarih.Name = "dateTimePickerEtutTarih";
            this.dateTimePickerEtutTarih.Size = new System.Drawing.Size(272, 20);
            this.dateTimePickerEtutTarih.TabIndex = 7;
            this.dateTimePickerEtutTarih.ValueChanged += new System.EventHandler(this.dateTimePickerEtutTarih_ValueChanged);
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label96.Location = new System.Drawing.Point(9, 131);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(53, 17);
            this.label96.TabIndex = 6;
            this.label96.Text = "Tarih : ";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label93.Location = new System.Drawing.Point(10, 53);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(83, 17);
            this.label93.TabIndex = 3;
            this.label93.Text = "Öğretmen : ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.Location = new System.Drawing.Point(10, 17);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(70, 17);
            this.label11.TabIndex = 2;
            this.label11.Text = "Öğrenci : ";
            // 
            // comboBoxEtutOgretmen
            // 
            this.comboBoxEtutOgretmen.FormattingEnabled = true;
            this.comboBoxEtutOgretmen.Location = new System.Drawing.Point(108, 51);
            this.comboBoxEtutOgretmen.Name = "comboBoxEtutOgretmen";
            this.comboBoxEtutOgretmen.Size = new System.Drawing.Size(272, 21);
            this.comboBoxEtutOgretmen.TabIndex = 1;
            // 
            // comboBoxEtutOgrenci
            // 
            this.comboBoxEtutOgrenci.FormattingEnabled = true;
            this.comboBoxEtutOgrenci.Location = new System.Drawing.Point(108, 15);
            this.comboBoxEtutOgrenci.Name = "comboBoxEtutOgrenci";
            this.comboBoxEtutOgrenci.Size = new System.Drawing.Size(272, 21);
            this.comboBoxEtutOgrenci.TabIndex = 0;
            // 
            // panelOgretmenIslemleri
            // 
            this.panelOgretmenIslemleri.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panelOgretmenIslemleri.Controls.Add(this.txtOgretmenIslemleriSoyadi);
            this.panelOgretmenIslemleri.Controls.Add(this.txtOgretmenIslemleriAdi);
            this.panelOgretmenIslemleri.Controls.Add(this.dataGridViewOgretmenIslemleri);
            this.panelOgretmenIslemleri.Controls.Add(this.btnOgretmenIslemleriEkleSil);
            this.panelOgretmenIslemleri.Controls.Add(this.txtOgretmenIslemleriTC);
            this.panelOgretmenIslemleri.Controls.Add(this.label30);
            this.panelOgretmenIslemleri.Controls.Add(this.label31);
            this.panelOgretmenIslemleri.Controls.Add(this.label32);
            this.panelOgretmenIslemleri.Controls.Add(this.radioButtonOgretmenIslemleriSilme);
            this.panelOgretmenIslemleri.Controls.Add(this.radioButtonOgretmenIslemleriEkleme);
            this.panelOgretmenIslemleri.Location = new System.Drawing.Point(3, 27);
            this.panelOgretmenIslemleri.Name = "panelOgretmenIslemleri";
            this.panelOgretmenIslemleri.Size = new System.Drawing.Size(1018, 543);
            this.panelOgretmenIslemleri.TabIndex = 7;
            // 
            // txtOgretmenIslemleriSoyadi
            // 
            this.txtOgretmenIslemleriSoyadi.Location = new System.Drawing.Point(91, 374);
            this.txtOgretmenIslemleriSoyadi.Name = "txtOgretmenIslemleriSoyadi";
            this.txtOgretmenIslemleriSoyadi.Size = new System.Drawing.Size(149, 20);
            this.txtOgretmenIslemleriSoyadi.TabIndex = 31;
            this.txtOgretmenIslemleriSoyadi.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOgretmenIslemleriSoyadi_KeyPress);
            // 
            // txtOgretmenIslemleriAdi
            // 
            this.txtOgretmenIslemleriAdi.Location = new System.Drawing.Point(92, 341);
            this.txtOgretmenIslemleriAdi.Name = "txtOgretmenIslemleriAdi";
            this.txtOgretmenIslemleriAdi.Size = new System.Drawing.Size(149, 20);
            this.txtOgretmenIslemleriAdi.TabIndex = 30;
            this.txtOgretmenIslemleriAdi.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOgretmenIslemleriAdi_KeyPress);
            // 
            // dataGridViewOgretmenIslemleri
            // 
            this.dataGridViewOgretmenIslemleri.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewOgretmenIslemleri.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewOgretmenIslemleri.Location = new System.Drawing.Point(9, 13);
            this.dataGridViewOgretmenIslemleri.Name = "dataGridViewOgretmenIslemleri";
            this.dataGridViewOgretmenIslemleri.ReadOnly = true;
            this.dataGridViewOgretmenIslemleri.Size = new System.Drawing.Size(1000, 249);
            this.dataGridViewOgretmenIslemleri.TabIndex = 29;
            this.dataGridViewOgretmenIslemleri.SelectionChanged += new System.EventHandler(this.dataGridViewOgretmenIslemleri_SelectionChanged);
            // 
            // btnOgretmenIslemleriEkleSil
            // 
            this.btnOgretmenIslemleriEkleSil.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnOgretmenIslemleriEkleSil.Location = new System.Drawing.Point(65, 405);
            this.btnOgretmenIslemleriEkleSil.Name = "btnOgretmenIslemleriEkleSil";
            this.btnOgretmenIslemleriEkleSil.Size = new System.Drawing.Size(125, 35);
            this.btnOgretmenIslemleriEkleSil.TabIndex = 27;
            this.btnOgretmenIslemleriEkleSil.Text = "EKLE / SİL";
            this.btnOgretmenIslemleriEkleSil.UseVisualStyleBackColor = true;
            this.btnOgretmenIslemleriEkleSil.Click += new System.EventHandler(this.btnOgretmenIslemleriEkleSil_Click);
            // 
            // txtOgretmenIslemleriTC
            // 
            this.txtOgretmenIslemleriTC.Location = new System.Drawing.Point(93, 306);
            this.txtOgretmenIslemleriTC.Name = "txtOgretmenIslemleriTC";
            this.txtOgretmenIslemleriTC.Size = new System.Drawing.Size(149, 20);
            this.txtOgretmenIslemleriTC.TabIndex = 26;
            this.txtOgretmenIslemleriTC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOgretmenIslemleriTC_KeyPress);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(6, 377);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(48, 13);
            this.label30.TabIndex = 25;
            this.label30.Text = "Soyadı : ";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(6, 343);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(31, 13);
            this.label31.TabIndex = 24;
            this.label31.Text = "Adı : ";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(6, 309);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(79, 13);
            this.label32.TabIndex = 23;
            this.label32.Text = "Öğretmen TC : ";
            // 
            // radioButtonOgretmenIslemleriSilme
            // 
            this.radioButtonOgretmenIslemleriSilme.AutoSize = true;
            this.radioButtonOgretmenIslemleriSilme.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonOgretmenIslemleriSilme.ForeColor = System.Drawing.Color.Black;
            this.radioButtonOgretmenIslemleriSilme.Location = new System.Drawing.Point(138, 274);
            this.radioButtonOgretmenIslemleriSilme.Name = "radioButtonOgretmenIslemleriSilme";
            this.radioButtonOgretmenIslemleriSilme.Size = new System.Drawing.Size(107, 17);
            this.radioButtonOgretmenIslemleriSilme.TabIndex = 19;
            this.radioButtonOgretmenIslemleriSilme.Text = "SİLME İŞLEMİ";
            this.radioButtonOgretmenIslemleriSilme.UseVisualStyleBackColor = true;
            // 
            // radioButtonOgretmenIslemleriEkleme
            // 
            this.radioButtonOgretmenIslemleriEkleme.AutoSize = true;
            this.radioButtonOgretmenIslemleriEkleme.Checked = true;
            this.radioButtonOgretmenIslemleriEkleme.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonOgretmenIslemleriEkleme.ForeColor = System.Drawing.Color.Black;
            this.radioButtonOgretmenIslemleriEkleme.Location = new System.Drawing.Point(9, 274);
            this.radioButtonOgretmenIslemleriEkleme.Name = "radioButtonOgretmenIslemleriEkleme";
            this.radioButtonOgretmenIslemleriEkleme.Size = new System.Drawing.Size(119, 17);
            this.radioButtonOgretmenIslemleriEkleme.TabIndex = 18;
            this.radioButtonOgretmenIslemleriEkleme.TabStop = true;
            this.radioButtonOgretmenIslemleriEkleme.Text = "EKLEME İŞLEMİ";
            this.radioButtonOgretmenIslemleriEkleme.UseVisualStyleBackColor = true;
            this.radioButtonOgretmenIslemleriEkleme.CheckedChanged += new System.EventHandler(this.radioButtonOgretmenIslemleriEkleme_CheckedChanged);
            // 
            // panelOgrencileriGoruntuleme
            // 
            this.panelOgrencileriGoruntuleme.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panelOgrencileriGoruntuleme.Controls.Add(this.btnOgrenciGorntulemeSIL);
            this.panelOgrencileriGoruntuleme.Controls.Add(this.label18);
            this.panelOgrencileriGoruntuleme.Controls.Add(this.btnOgrFiltreAra);
            this.panelOgrencileriGoruntuleme.Controls.Add(this.panelOgrFiltreCinsiyet);
            this.panelOgrencileriGoruntuleme.Controls.Add(this.txtOgrFiltreSoyisim);
            this.panelOgrencileriGoruntuleme.Controls.Add(this.txtOgrFiltreIsim);
            this.panelOgrencileriGoruntuleme.Controls.Add(this.txtOgrFiltreTC);
            this.panelOgrencileriGoruntuleme.Controls.Add(this.radioButtonOgrFiltreSoyisim);
            this.panelOgrencileriGoruntuleme.Controls.Add(this.radioButtonOgrFiltreCinsiyet);
            this.panelOgrencileriGoruntuleme.Controls.Add(this.radioButtonOgrFiltreIsim);
            this.panelOgrencileriGoruntuleme.Controls.Add(this.radioButtonOgrFiltreTC);
            this.panelOgrencileriGoruntuleme.Controls.Add(this.dataGridViewOgrencileriGoruntule);
            this.panelOgrencileriGoruntuleme.Location = new System.Drawing.Point(3, 27);
            this.panelOgrencileriGoruntuleme.Name = "panelOgrencileriGoruntuleme";
            this.panelOgrencileriGoruntuleme.Size = new System.Drawing.Size(1018, 543);
            this.panelOgrencileriGoruntuleme.TabIndex = 4;
            // 
            // btnOgrenciGorntulemeSIL
            // 
            this.btnOgrenciGorntulemeSIL.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnOgrenciGorntulemeSIL.Location = new System.Drawing.Point(93, 486);
            this.btnOgrenciGorntulemeSIL.Name = "btnOgrenciGorntulemeSIL";
            this.btnOgrenciGorntulemeSIL.Size = new System.Drawing.Size(176, 36);
            this.btnOgrenciGorntulemeSIL.TabIndex = 15;
            this.btnOgrenciGorntulemeSIL.Text = "ÖĞRENCİYİ SİL";
            this.btnOgrenciGorntulemeSIL.UseVisualStyleBackColor = true;
            this.btnOgrenciGorntulemeSIL.Click += new System.EventHandler(this.btnOgrenciGorntulemeSIL_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label18.Location = new System.Drawing.Point(6, 274);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(92, 15);
            this.label18.TabIndex = 14;
            this.label18.Text = "FİLTRELEME";
            // 
            // btnOgrFiltreAra
            // 
            this.btnOgrFiltreAra.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnOgrFiltreAra.Location = new System.Drawing.Point(93, 444);
            this.btnOgrFiltreAra.Name = "btnOgrFiltreAra";
            this.btnOgrFiltreAra.Size = new System.Drawing.Size(176, 36);
            this.btnOgrFiltreAra.TabIndex = 13;
            this.btnOgrFiltreAra.Text = "ARA";
            this.btnOgrFiltreAra.UseVisualStyleBackColor = true;
            this.btnOgrFiltreAra.Click += new System.EventHandler(this.btnOgrFiltreAra_Click);
            // 
            // panelOgrFiltreCinsiyet
            // 
            this.panelOgrFiltreCinsiyet.Controls.Add(this.radioButtonOgrFiltreErkek);
            this.panelOgrFiltreCinsiyet.Controls.Add(this.radioButtonOgrFiltreKadin);
            this.panelOgrFiltreCinsiyet.Enabled = false;
            this.panelOgrFiltreCinsiyet.Location = new System.Drawing.Point(93, 418);
            this.panelOgrFiltreCinsiyet.Name = "panelOgrFiltreCinsiyet";
            this.panelOgrFiltreCinsiyet.Size = new System.Drawing.Size(176, 20);
            this.panelOgrFiltreCinsiyet.TabIndex = 12;
            // 
            // radioButtonOgrFiltreErkek
            // 
            this.radioButtonOgrFiltreErkek.AutoSize = true;
            this.radioButtonOgrFiltreErkek.Checked = true;
            this.radioButtonOgrFiltreErkek.Location = new System.Drawing.Point(3, 3);
            this.radioButtonOgrFiltreErkek.Name = "radioButtonOgrFiltreErkek";
            this.radioButtonOgrFiltreErkek.Size = new System.Drawing.Size(53, 17);
            this.radioButtonOgrFiltreErkek.TabIndex = 10;
            this.radioButtonOgrFiltreErkek.TabStop = true;
            this.radioButtonOgrFiltreErkek.Text = "Erkek";
            this.radioButtonOgrFiltreErkek.UseVisualStyleBackColor = true;
            // 
            // radioButtonOgrFiltreKadin
            // 
            this.radioButtonOgrFiltreKadin.AutoSize = true;
            this.radioButtonOgrFiltreKadin.Location = new System.Drawing.Point(79, 3);
            this.radioButtonOgrFiltreKadin.Name = "radioButtonOgrFiltreKadin";
            this.radioButtonOgrFiltreKadin.Size = new System.Drawing.Size(52, 17);
            this.radioButtonOgrFiltreKadin.TabIndex = 11;
            this.radioButtonOgrFiltreKadin.Text = "Kadın";
            this.radioButtonOgrFiltreKadin.UseVisualStyleBackColor = true;
            // 
            // txtOgrFiltreSoyisim
            // 
            this.txtOgrFiltreSoyisim.Enabled = false;
            this.txtOgrFiltreSoyisim.Location = new System.Drawing.Point(93, 380);
            this.txtOgrFiltreSoyisim.Name = "txtOgrFiltreSoyisim";
            this.txtOgrFiltreSoyisim.Size = new System.Drawing.Size(176, 20);
            this.txtOgrFiltreSoyisim.TabIndex = 9;
            this.txtOgrFiltreSoyisim.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOgrFiltreSoyisim_KeyPress);
            // 
            // txtOgrFiltreIsim
            // 
            this.txtOgrFiltreIsim.Enabled = false;
            this.txtOgrFiltreIsim.Location = new System.Drawing.Point(93, 340);
            this.txtOgrFiltreIsim.Name = "txtOgrFiltreIsim";
            this.txtOgrFiltreIsim.Size = new System.Drawing.Size(176, 20);
            this.txtOgrFiltreIsim.TabIndex = 8;
            this.txtOgrFiltreIsim.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOgrFiltreIsim_KeyPress);
            // 
            // txtOgrFiltreTC
            // 
            this.txtOgrFiltreTC.Location = new System.Drawing.Point(93, 300);
            this.txtOgrFiltreTC.MaxLength = 11;
            this.txtOgrFiltreTC.Name = "txtOgrFiltreTC";
            this.txtOgrFiltreTC.Size = new System.Drawing.Size(176, 20);
            this.txtOgrFiltreTC.TabIndex = 7;
            this.txtOgrFiltreTC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOgrFiltreTC_KeyPress);
            // 
            // radioButtonOgrFiltreSoyisim
            // 
            this.radioButtonOgrFiltreSoyisim.AutoSize = true;
            this.radioButtonOgrFiltreSoyisim.Location = new System.Drawing.Point(8, 381);
            this.radioButtonOgrFiltreSoyisim.Name = "radioButtonOgrFiltreSoyisim";
            this.radioButtonOgrFiltreSoyisim.Size = new System.Drawing.Size(69, 17);
            this.radioButtonOgrFiltreSoyisim.TabIndex = 6;
            this.radioButtonOgrFiltreSoyisim.Text = "Soyisim : ";
            this.radioButtonOgrFiltreSoyisim.UseVisualStyleBackColor = true;
            this.radioButtonOgrFiltreSoyisim.CheckedChanged += new System.EventHandler(this.radioButtonOgrFiltreSoyisim_CheckedChanged);
            // 
            // radioButtonOgrFiltreCinsiyet
            // 
            this.radioButtonOgrFiltreCinsiyet.AutoSize = true;
            this.radioButtonOgrFiltreCinsiyet.Location = new System.Drawing.Point(8, 421);
            this.radioButtonOgrFiltreCinsiyet.Name = "radioButtonOgrFiltreCinsiyet";
            this.radioButtonOgrFiltreCinsiyet.Size = new System.Drawing.Size(70, 17);
            this.radioButtonOgrFiltreCinsiyet.TabIndex = 5;
            this.radioButtonOgrFiltreCinsiyet.Text = "Cinsiyet : ";
            this.radioButtonOgrFiltreCinsiyet.UseVisualStyleBackColor = true;
            this.radioButtonOgrFiltreCinsiyet.CheckedChanged += new System.EventHandler(this.radioButtonOgrFiltreCinsiyet_CheckedChanged);
            // 
            // radioButtonOgrFiltreIsim
            // 
            this.radioButtonOgrFiltreIsim.AutoSize = true;
            this.radioButtonOgrFiltreIsim.Location = new System.Drawing.Point(8, 341);
            this.radioButtonOgrFiltreIsim.Name = "radioButtonOgrFiltreIsim";
            this.radioButtonOgrFiltreIsim.Size = new System.Drawing.Size(52, 17);
            this.radioButtonOgrFiltreIsim.TabIndex = 4;
            this.radioButtonOgrFiltreIsim.Text = "İsim : ";
            this.radioButtonOgrFiltreIsim.UseVisualStyleBackColor = true;
            this.radioButtonOgrFiltreIsim.CheckedChanged += new System.EventHandler(this.radioButtonOgrFiltreIsim_CheckedChanged);
            // 
            // radioButtonOgrFiltreTC
            // 
            this.radioButtonOgrFiltreTC.AutoSize = true;
            this.radioButtonOgrFiltreTC.Checked = true;
            this.radioButtonOgrFiltreTC.Location = new System.Drawing.Point(9, 301);
            this.radioButtonOgrFiltreTC.Name = "radioButtonOgrFiltreTC";
            this.radioButtonOgrFiltreTC.Size = new System.Drawing.Size(78, 17);
            this.radioButtonOgrFiltreTC.TabIndex = 3;
            this.radioButtonOgrFiltreTC.TabStop = true;
            this.radioButtonOgrFiltreTC.Text = "TC Kimlik : ";
            this.radioButtonOgrFiltreTC.UseVisualStyleBackColor = true;
            this.radioButtonOgrFiltreTC.CheckedChanged += new System.EventHandler(this.radioButtonOgrFiltreTC_CheckedChanged);
            // 
            // dataGridViewOgrencileriGoruntule
            // 
            this.dataGridViewOgrencileriGoruntule.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewOgrencileriGoruntule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewOgrencileriGoruntule.Location = new System.Drawing.Point(9, 13);
            this.dataGridViewOgrencileriGoruntule.Name = "dataGridViewOgrencileriGoruntule";
            this.dataGridViewOgrencileriGoruntule.ReadOnly = true;
            this.dataGridViewOgrencileriGoruntule.Size = new System.Drawing.Size(1000, 249);
            this.dataGridViewOgrencileriGoruntule.TabIndex = 2;
            this.dataGridViewOgrencileriGoruntule.SelectionChanged += new System.EventHandler(this.dataGridViewOgrencileriGoruntule_SelectionChanged);
            // 
            // panelDGSHesap
            // 
            this.panelDGSHesap.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panelDGSHesap.Controls.Add(this.lblEsitAgirlikPuani);
            this.panelDGSHesap.Controls.Add(this.lblSozelPuani);
            this.panelDGSHesap.Controls.Add(this.lblSayisalPuan);
            this.panelDGSHesap.Controls.Add(this.lbl3);
            this.panelDGSHesap.Controls.Add(this.lbl2);
            this.panelDGSHesap.Controls.Add(this.lbl1);
            this.panelDGSHesap.Controls.Add(this.btnDGSTemizle);
            this.panelDGSHesap.Controls.Add(this.btnDGSHesapla);
            this.panelDGSHesap.Controls.Add(this.checkBoxDGS);
            this.panelDGSHesap.Controls.Add(this.label40);
            this.panelDGSHesap.Controls.Add(this.label39);
            this.panelDGSHesap.Controls.Add(this.label38);
            this.panelDGSHesap.Controls.Add(this.label37);
            this.panelDGSHesap.Controls.Add(this.label36);
            this.panelDGSHesap.Controls.Add(this.txtDGSonlisansPuani);
            this.panelDGSHesap.Controls.Add(this.label34);
            this.panelDGSHesap.Controls.Add(this.txtDGSSozelYanlis);
            this.panelDGSHesap.Controls.Add(this.label35);
            this.panelDGSHesap.Controls.Add(this.txtDGSSozelDogru);
            this.panelDGSHesap.Controls.Add(this.label33);
            this.panelDGSHesap.Controls.Add(this.txtDGSSayisalYanlis);
            this.panelDGSHesap.Controls.Add(this.label29);
            this.panelDGSHesap.Controls.Add(this.label9);
            this.panelDGSHesap.Controls.Add(this.txtDGSSayisalDogru);
            this.panelDGSHesap.Controls.Add(this.label6);
            this.panelDGSHesap.Location = new System.Drawing.Point(3, 27);
            this.panelDGSHesap.Name = "panelDGSHesap";
            this.panelDGSHesap.Size = new System.Drawing.Size(1018, 543);
            this.panelDGSHesap.TabIndex = 10;
            // 
            // lblEsitAgirlikPuani
            // 
            this.lblEsitAgirlikPuani.AutoSize = true;
            this.lblEsitAgirlikPuani.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblEsitAgirlikPuani.Location = new System.Drawing.Point(357, 408);
            this.lblEsitAgirlikPuani.Name = "lblEsitAgirlikPuani";
            this.lblEsitAgirlikPuani.Size = new System.Drawing.Size(0, 17);
            this.lblEsitAgirlikPuani.TabIndex = 27;
            this.lblEsitAgirlikPuani.Visible = false;
            // 
            // lblSozelPuani
            // 
            this.lblSozelPuani.AutoSize = true;
            this.lblSozelPuani.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSozelPuani.Location = new System.Drawing.Point(357, 376);
            this.lblSozelPuani.Name = "lblSozelPuani";
            this.lblSozelPuani.Size = new System.Drawing.Size(0, 17);
            this.lblSozelPuani.TabIndex = 26;
            this.lblSozelPuani.Visible = false;
            // 
            // lblSayisalPuan
            // 
            this.lblSayisalPuan.AutoSize = true;
            this.lblSayisalPuan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSayisalPuan.Location = new System.Drawing.Point(357, 343);
            this.lblSayisalPuan.Name = "lblSayisalPuan";
            this.lblSayisalPuan.Size = new System.Drawing.Size(0, 17);
            this.lblSayisalPuan.TabIndex = 25;
            this.lblSayisalPuan.Visible = false;
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl3.Location = new System.Drawing.Point(191, 408);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(125, 17);
            this.lbl3.TabIndex = 24;
            this.lbl3.Text = "Eşit Ağırlık Puanı : ";
            this.lbl3.Visible = false;
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl2.Location = new System.Drawing.Point(191, 376);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(95, 17);
            this.lbl2.TabIndex = 22;
            this.lbl2.Text = "Sözel Puanı : ";
            this.lbl2.Visible = false;
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl1.Location = new System.Drawing.Point(191, 343);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(105, 17);
            this.lbl1.TabIndex = 21;
            this.lbl1.Text = "Sayısal Puanı : ";
            this.lbl1.Visible = false;
            // 
            // btnDGSTemizle
            // 
            this.btnDGSTemizle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnDGSTemizle.Location = new System.Drawing.Point(462, 272);
            this.btnDGSTemizle.Name = "btnDGSTemizle";
            this.btnDGSTemizle.Size = new System.Drawing.Size(98, 46);
            this.btnDGSTemizle.TabIndex = 18;
            this.btnDGSTemizle.Text = "TEMİZLE";
            this.btnDGSTemizle.UseVisualStyleBackColor = true;
            this.btnDGSTemizle.Click += new System.EventHandler(this.btnDGSTemizle_Click);
            // 
            // btnDGSHesapla
            // 
            this.btnDGSHesapla.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnDGSHesapla.Location = new System.Drawing.Point(358, 272);
            this.btnDGSHesapla.Name = "btnDGSHesapla";
            this.btnDGSHesapla.Size = new System.Drawing.Size(98, 46);
            this.btnDGSHesapla.TabIndex = 17;
            this.btnDGSHesapla.Text = "HESAPLA";
            this.btnDGSHesapla.UseVisualStyleBackColor = true;
            this.btnDGSHesapla.Click += new System.EventHandler(this.btnDGSHesapla_Click);
            // 
            // checkBoxDGS
            // 
            this.checkBoxDGS.AutoSize = true;
            this.checkBoxDGS.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.checkBoxDGS.Location = new System.Drawing.Point(358, 232);
            this.checkBoxDGS.Name = "checkBoxDGS";
            this.checkBoxDGS.Size = new System.Drawing.Size(464, 21);
            this.checkBoxDGS.TabIndex = 16;
            this.checkBoxDGS.Text = "Önceki DGS\'de bir programa yerleştirildiyseniz kutucuğu işaretleyiniz.";
            this.checkBoxDGS.UseVisualStyleBackColor = true;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label40.Location = new System.Drawing.Point(191, 233);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(150, 17);
            this.label40.TabIndex = 15;
            this.label40.Text = "Önceki DGS Sonucu : ";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label39.Location = new System.Drawing.Point(422, 200);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(134, 17);
            this.label39.TabIndex = 14;
            this.label39.Text = "En az 40, en çok 80";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label38.Location = new System.Drawing.Point(506, 167);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(58, 17);
            this.label38.TabIndex = 13;
            this.label38.Text = "60 Soru";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label37.Location = new System.Drawing.Point(506, 134);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(58, 17);
            this.label37.TabIndex = 12;
            this.label37.Text = "60 Soru";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label36.Location = new System.Drawing.Point(191, 200);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(159, 17);
            this.label36.TabIndex = 11;
            this.label36.Text = "Önlisans Başarı Puanı : ";
            // 
            // txtDGSonlisansPuani
            // 
            this.txtDGSonlisansPuani.Location = new System.Drawing.Point(357, 199);
            this.txtDGSonlisansPuani.Name = "txtDGSonlisansPuani";
            this.txtDGSonlisansPuani.Size = new System.Drawing.Size(59, 20);
            this.txtDGSonlisansPuani.TabIndex = 10;
            this.txtDGSonlisansPuani.Text = "40";
            this.txtDGSonlisansPuani.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDGSonlisansPuani_KeyPress);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label34.Location = new System.Drawing.Point(191, 167);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(90, 17);
            this.label34.TabIndex = 9;
            this.label34.Text = "Sözel Testi : ";
            // 
            // txtDGSSozelYanlis
            // 
            this.txtDGSSozelYanlis.Location = new System.Drawing.Point(441, 166);
            this.txtDGSSozelYanlis.Name = "txtDGSSozelYanlis";
            this.txtDGSSozelYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtDGSSozelYanlis.TabIndex = 8;
            this.txtDGSSozelYanlis.Text = "0";
            this.txtDGSSozelYanlis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDGSSozelYanlis_KeyPress);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label35.Location = new System.Drawing.Point(422, 167);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(13, 17);
            this.label35.TabIndex = 7;
            this.label35.Text = "/";
            // 
            // txtDGSSozelDogru
            // 
            this.txtDGSSozelDogru.Location = new System.Drawing.Point(357, 166);
            this.txtDGSSozelDogru.Name = "txtDGSSozelDogru";
            this.txtDGSSozelDogru.Size = new System.Drawing.Size(59, 20);
            this.txtDGSSozelDogru.TabIndex = 6;
            this.txtDGSSozelDogru.Text = "0";
            this.txtDGSSozelDogru.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDGSSozelDogru_KeyPress);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label33.Location = new System.Drawing.Point(191, 134);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(100, 17);
            this.label33.TabIndex = 5;
            this.label33.Text = "Sayısal Testi : ";
            // 
            // txtDGSSayisalYanlis
            // 
            this.txtDGSSayisalYanlis.Location = new System.Drawing.Point(441, 133);
            this.txtDGSSayisalYanlis.Name = "txtDGSSayisalYanlis";
            this.txtDGSSayisalYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtDGSSayisalYanlis.TabIndex = 4;
            this.txtDGSSayisalYanlis.Text = "0";
            this.txtDGSSayisalYanlis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDGSSayisalYanlis_KeyPress);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label29.Location = new System.Drawing.Point(441, 104);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(62, 17);
            this.label29.TabIndex = 3;
            this.label29.Text = "YANLIŞ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.Location = new System.Drawing.Point(422, 134);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(13, 17);
            this.label9.TabIndex = 2;
            this.label9.Text = "/";
            // 
            // txtDGSSayisalDogru
            // 
            this.txtDGSSayisalDogru.Location = new System.Drawing.Point(357, 133);
            this.txtDGSSayisalDogru.Name = "txtDGSSayisalDogru";
            this.txtDGSSayisalDogru.Size = new System.Drawing.Size(59, 20);
            this.txtDGSSayisalDogru.TabIndex = 1;
            this.txtDGSSayisalDogru.Text = "0";
            this.txtDGSSayisalDogru.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDGSSayisalDogru_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(355, 104);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 17);
            this.label6.TabIndex = 0;
            this.label6.Text = "DOĞRU";
            // 
            // panelAYTHesap
            // 
            this.panelAYTHesap.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panelAYTHesap.Controls.Add(this.radioButtonAYTEsitAgirlik);
            this.panelAYTHesap.Controls.Add(this.radioButtonAYTSayisal);
            this.panelAYTHesap.Controls.Add(this.radioButtonAYTSozel);
            this.panelAYTHesap.Controls.Add(this.btnAYTTemizle);
            this.panelAYTHesap.Controls.Add(this.lblAYTpuani);
            this.panelAYTHesap.Controls.Add(this.lblAYTpuanTuru);
            this.panelAYTHesap.Controls.Add(this.btnAYTHesapla);
            this.panelAYTHesap.Controls.Add(this.label63);
            this.panelAYTHesap.Controls.Add(this.label66);
            this.panelAYTHesap.Controls.Add(this.txtAYTobp);
            this.panelAYTHesap.Controls.Add(this.panelAYTSozel);
            this.panelAYTHesap.Controls.Add(this.panelAYTEsitAgirlik);
            this.panelAYTHesap.Controls.Add(this.panelAYTSayisal);
            this.panelAYTHesap.Location = new System.Drawing.Point(3, 27);
            this.panelAYTHesap.Name = "panelAYTHesap";
            this.panelAYTHesap.Size = new System.Drawing.Size(1018, 543);
            this.panelAYTHesap.TabIndex = 9;
            // 
            // radioButtonAYTEsitAgirlik
            // 
            this.radioButtonAYTEsitAgirlik.AutoSize = true;
            this.radioButtonAYTEsitAgirlik.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonAYTEsitAgirlik.Location = new System.Drawing.Point(478, 9);
            this.radioButtonAYTEsitAgirlik.Name = "radioButtonAYTEsitAgirlik";
            this.radioButtonAYTEsitAgirlik.Size = new System.Drawing.Size(149, 21);
            this.radioButtonAYTEsitAgirlik.TabIndex = 78;
            this.radioButtonAYTEsitAgirlik.Text = "Eşit Ağırlık Puanı";
            this.radioButtonAYTEsitAgirlik.UseVisualStyleBackColor = true;
            this.radioButtonAYTEsitAgirlik.CheckedChanged += new System.EventHandler(this.radioButtonAYTEsitAgirlik_CheckedChanged);
            // 
            // radioButtonAYTSayisal
            // 
            this.radioButtonAYTSayisal.AutoSize = true;
            this.radioButtonAYTSayisal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonAYTSayisal.Location = new System.Drawing.Point(348, 9);
            this.radioButtonAYTSayisal.Name = "radioButtonAYTSayisal";
            this.radioButtonAYTSayisal.Size = new System.Drawing.Size(124, 21);
            this.radioButtonAYTSayisal.TabIndex = 77;
            this.radioButtonAYTSayisal.Text = "Sayısal Puanı";
            this.radioButtonAYTSayisal.UseVisualStyleBackColor = true;
            this.radioButtonAYTSayisal.CheckedChanged += new System.EventHandler(this.radioButtonAYTSayisal_CheckedChanged);
            // 
            // radioButtonAYTSozel
            // 
            this.radioButtonAYTSozel.AutoSize = true;
            this.radioButtonAYTSozel.Checked = true;
            this.radioButtonAYTSozel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonAYTSozel.Location = new System.Drawing.Point(230, 9);
            this.radioButtonAYTSozel.Name = "radioButtonAYTSozel";
            this.radioButtonAYTSozel.Size = new System.Drawing.Size(112, 21);
            this.radioButtonAYTSozel.TabIndex = 76;
            this.radioButtonAYTSozel.TabStop = true;
            this.radioButtonAYTSozel.Text = "Sözel Puanı";
            this.radioButtonAYTSozel.UseVisualStyleBackColor = true;
            this.radioButtonAYTSozel.CheckedChanged += new System.EventHandler(this.radioButtonAYTSozel_CheckedChanged);
            // 
            // btnAYTTemizle
            // 
            this.btnAYTTemizle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAYTTemizle.Location = new System.Drawing.Point(509, 468);
            this.btnAYTTemizle.Name = "btnAYTTemizle";
            this.btnAYTTemizle.Size = new System.Drawing.Size(98, 46);
            this.btnAYTTemizle.TabIndex = 72;
            this.btnAYTTemizle.Text = "TEMİZLE";
            this.btnAYTTemizle.UseVisualStyleBackColor = true;
            this.btnAYTTemizle.Click += new System.EventHandler(this.btnAYTTemizle_Click);
            // 
            // lblAYTpuani
            // 
            this.lblAYTpuani.AutoSize = true;
            this.lblAYTpuani.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblAYTpuani.Location = new System.Drawing.Point(408, 520);
            this.lblAYTpuani.Name = "lblAYTpuani";
            this.lblAYTpuani.Size = new System.Drawing.Size(0, 17);
            this.lblAYTpuani.TabIndex = 71;
            this.lblAYTpuani.Visible = false;
            // 
            // lblAYTpuanTuru
            // 
            this.lblAYTpuanTuru.AutoSize = true;
            this.lblAYTpuanTuru.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblAYTpuanTuru.Location = new System.Drawing.Point(238, 520);
            this.lblAYTpuanTuru.Name = "lblAYTpuanTuru";
            this.lblAYTpuanTuru.Size = new System.Drawing.Size(0, 17);
            this.lblAYTpuanTuru.TabIndex = 70;
            this.lblAYTpuanTuru.Visible = false;
            // 
            // btnAYTHesapla
            // 
            this.btnAYTHesapla.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAYTHesapla.Location = new System.Drawing.Point(401, 468);
            this.btnAYTHesapla.Name = "btnAYTHesapla";
            this.btnAYTHesapla.Size = new System.Drawing.Size(98, 46);
            this.btnAYTHesapla.TabIndex = 69;
            this.btnAYTHesapla.Text = "HESAPLA";
            this.btnAYTHesapla.UseVisualStyleBackColor = true;
            this.btnAYTHesapla.Click += new System.EventHandler(this.btnAYTHesapla_Click);
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label63.Location = new System.Drawing.Point(465, 434);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(150, 17);
            this.label63.TabIndex = 58;
            this.label63.Text = "En az 250, en çok 500";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label66.Location = new System.Drawing.Point(234, 434);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(158, 17);
            this.label66.TabIndex = 55;
            this.label66.Text = "O. Başarı Puanı(OBP) : ";
            // 
            // txtAYTobp
            // 
            this.txtAYTobp.Location = new System.Drawing.Point(400, 433);
            this.txtAYTobp.Name = "txtAYTobp";
            this.txtAYTobp.Size = new System.Drawing.Size(59, 20);
            this.txtAYTobp.TabIndex = 54;
            this.txtAYTobp.Text = "250";
            // 
            // panelAYTSozel
            // 
            this.panelAYTSozel.Controls.Add(this.label7);
            this.panelAYTSozel.Controls.Add(this.label56);
            this.panelAYTSozel.Controls.Add(this.txtAYTSozelFelsefeYanlis);
            this.panelAYTSozel.Controls.Add(this.label146);
            this.panelAYTSozel.Controls.Add(this.txtAYTSozelFelsefeDogru);
            this.panelAYTSozel.Controls.Add(this.label100);
            this.panelAYTSozel.Controls.Add(this.label103);
            this.panelAYTSozel.Controls.Add(this.txtAYTSozelDKABYanlis);
            this.panelAYTSozel.Controls.Add(this.label104);
            this.panelAYTSozel.Controls.Add(this.txtAYTSozelDKABDogru);
            this.panelAYTSozel.Controls.Add(this.label105);
            this.panelAYTSozel.Controls.Add(this.label106);
            this.panelAYTSozel.Controls.Add(this.label107);
            this.panelAYTSozel.Controls.Add(this.txtAYTSozelCografya2Yanlis);
            this.panelAYTSozel.Controls.Add(this.label108);
            this.panelAYTSozel.Controls.Add(this.txtAYTSozelCografya2Dogru);
            this.panelAYTSozel.Controls.Add(this.label109);
            this.panelAYTSozel.Controls.Add(this.txtAYTSozelTarih2Yanlis);
            this.panelAYTSozel.Controls.Add(this.label110);
            this.panelAYTSozel.Controls.Add(this.txtAYTSozelTarih2Dogru);
            this.panelAYTSozel.Controls.Add(this.label87);
            this.panelAYTSozel.Controls.Add(this.label88);
            this.panelAYTSozel.Controls.Add(this.label89);
            this.panelAYTSozel.Controls.Add(this.txtAYTSozelCografya1Yanlis);
            this.panelAYTSozel.Controls.Add(this.label90);
            this.panelAYTSozel.Controls.Add(this.txtAYTSozelCografya1Dogru);
            this.panelAYTSozel.Controls.Add(this.label91);
            this.panelAYTSozel.Controls.Add(this.txtAYTSozelTarih1Yanlis);
            this.panelAYTSozel.Controls.Add(this.label92);
            this.panelAYTSozel.Controls.Add(this.txtAYTSozelTarih1Dogru);
            this.panelAYTSozel.Controls.Add(this.label94);
            this.panelAYTSozel.Controls.Add(this.label97);
            this.panelAYTSozel.Controls.Add(this.txtAYTSozelEdebiyatYanlis);
            this.panelAYTSozel.Controls.Add(this.label98);
            this.panelAYTSozel.Controls.Add(this.txtAYTSozelEdebiyatDogru);
            this.panelAYTSozel.Controls.Add(this.label73);
            this.panelAYTSozel.Controls.Add(this.label74);
            this.panelAYTSozel.Controls.Add(this.label75);
            this.panelAYTSozel.Controls.Add(this.txtAYTSozelFenYanlis);
            this.panelAYTSozel.Controls.Add(this.label76);
            this.panelAYTSozel.Controls.Add(this.txtAYTSozelFenDogru);
            this.panelAYTSozel.Controls.Add(this.label77);
            this.panelAYTSozel.Controls.Add(this.txtAYTSozelTemelMatYanlis);
            this.panelAYTSozel.Controls.Add(this.label78);
            this.panelAYTSozel.Controls.Add(this.txtAYTSozelTemelMatDogru);
            this.panelAYTSozel.Controls.Add(this.label79);
            this.panelAYTSozel.Controls.Add(this.label80);
            this.panelAYTSozel.Controls.Add(this.label81);
            this.panelAYTSozel.Controls.Add(this.txtAYTSozelSosyalYanlis);
            this.panelAYTSozel.Controls.Add(this.label82);
            this.panelAYTSozel.Controls.Add(this.txtAYTSozelSosyalDogru);
            this.panelAYTSozel.Controls.Add(this.label83);
            this.panelAYTSozel.Controls.Add(this.txtAYTSozelTurkceYanlis);
            this.panelAYTSozel.Controls.Add(this.label84);
            this.panelAYTSozel.Controls.Add(this.label85);
            this.panelAYTSozel.Controls.Add(this.txtAYTSozelTurkceDogru);
            this.panelAYTSozel.Controls.Add(this.label86);
            this.panelAYTSozel.Location = new System.Drawing.Point(231, 36);
            this.panelAYTSozel.Name = "panelAYTSozel";
            this.panelAYTSozel.Size = new System.Drawing.Size(384, 389);
            this.panelAYTSozel.TabIndex = 73;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(318, 364);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 17);
            this.label7.TabIndex = 134;
            this.label7.Text = "12 Soru";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label56.Location = new System.Drawing.Point(3, 364);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(101, 17);
            this.label56.TabIndex = 133;
            this.label56.Text = "Felsefe Testi : ";
            // 
            // txtAYTSozelFelsefeYanlis
            // 
            this.txtAYTSozelFelsefeYanlis.Location = new System.Drawing.Point(253, 363);
            this.txtAYTSozelFelsefeYanlis.Name = "txtAYTSozelFelsefeYanlis";
            this.txtAYTSozelFelsefeYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSozelFelsefeYanlis.TabIndex = 132;
            this.txtAYTSozelFelsefeYanlis.Text = "0";
            // 
            // label146
            // 
            this.label146.AutoSize = true;
            this.label146.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label146.Location = new System.Drawing.Point(234, 364);
            this.label146.Name = "label146";
            this.label146.Size = new System.Drawing.Size(13, 17);
            this.label146.TabIndex = 131;
            this.label146.Text = "/";
            // 
            // txtAYTSozelFelsefeDogru
            // 
            this.txtAYTSozelFelsefeDogru.Location = new System.Drawing.Point(169, 363);
            this.txtAYTSozelFelsefeDogru.Name = "txtAYTSozelFelsefeDogru";
            this.txtAYTSozelFelsefeDogru.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSozelFelsefeDogru.TabIndex = 130;
            this.txtAYTSozelFelsefeDogru.Text = "0";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label100.Location = new System.Drawing.Point(318, 333);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(58, 17);
            this.label100.TabIndex = 129;
            this.label100.Text = "06 Soru";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label103.Location = new System.Drawing.Point(3, 333);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(92, 17);
            this.label103.TabIndex = 124;
            this.label103.Text = "DKAB Testi : ";
            // 
            // txtAYTSozelDKABYanlis
            // 
            this.txtAYTSozelDKABYanlis.Location = new System.Drawing.Point(253, 332);
            this.txtAYTSozelDKABYanlis.Name = "txtAYTSozelDKABYanlis";
            this.txtAYTSozelDKABYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSozelDKABYanlis.TabIndex = 123;
            this.txtAYTSozelDKABYanlis.Text = "0";
            this.txtAYTSozelDKABYanlis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAYTSozelTurkceYanlis_KeyPress);
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label104.Location = new System.Drawing.Point(234, 333);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(13, 17);
            this.label104.TabIndex = 122;
            this.label104.Text = "/";
            // 
            // txtAYTSozelDKABDogru
            // 
            this.txtAYTSozelDKABDogru.Location = new System.Drawing.Point(169, 332);
            this.txtAYTSozelDKABDogru.Name = "txtAYTSozelDKABDogru";
            this.txtAYTSozelDKABDogru.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSozelDKABDogru.TabIndex = 121;
            this.txtAYTSozelDKABDogru.Text = "0";
            this.txtAYTSozelDKABDogru.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAYTSozelTurkceYanlis_KeyPress);
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label105.Location = new System.Drawing.Point(318, 300);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(58, 17);
            this.label105.TabIndex = 120;
            this.label105.Text = "11 Soru";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label106.Location = new System.Drawing.Point(318, 267);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(58, 17);
            this.label106.TabIndex = 119;
            this.label106.Text = "11 Soru";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label107.Location = new System.Drawing.Point(3, 300);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(125, 17);
            this.label107.TabIndex = 118;
            this.label107.Text = "Coğrafya-2 Testi : ";
            // 
            // txtAYTSozelCografya2Yanlis
            // 
            this.txtAYTSozelCografya2Yanlis.Location = new System.Drawing.Point(253, 299);
            this.txtAYTSozelCografya2Yanlis.Name = "txtAYTSozelCografya2Yanlis";
            this.txtAYTSozelCografya2Yanlis.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSozelCografya2Yanlis.TabIndex = 117;
            this.txtAYTSozelCografya2Yanlis.Text = "0";
            this.txtAYTSozelCografya2Yanlis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAYTSozelTurkceYanlis_KeyPress);
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label108.Location = new System.Drawing.Point(234, 300);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(13, 17);
            this.label108.TabIndex = 116;
            this.label108.Text = "/";
            // 
            // txtAYTSozelCografya2Dogru
            // 
            this.txtAYTSozelCografya2Dogru.Location = new System.Drawing.Point(169, 299);
            this.txtAYTSozelCografya2Dogru.Name = "txtAYTSozelCografya2Dogru";
            this.txtAYTSozelCografya2Dogru.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSozelCografya2Dogru.TabIndex = 115;
            this.txtAYTSozelCografya2Dogru.Text = "0";
            this.txtAYTSozelCografya2Dogru.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAYTSozelTurkceYanlis_KeyPress);
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label109.Location = new System.Drawing.Point(3, 267);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(101, 17);
            this.label109.TabIndex = 114;
            this.label109.Text = "Tarih-2 Testi : ";
            // 
            // txtAYTSozelTarih2Yanlis
            // 
            this.txtAYTSozelTarih2Yanlis.Location = new System.Drawing.Point(253, 266);
            this.txtAYTSozelTarih2Yanlis.Name = "txtAYTSozelTarih2Yanlis";
            this.txtAYTSozelTarih2Yanlis.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSozelTarih2Yanlis.TabIndex = 113;
            this.txtAYTSozelTarih2Yanlis.Text = "0";
            this.txtAYTSozelTarih2Yanlis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAYTSozelTurkceYanlis_KeyPress);
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label110.Location = new System.Drawing.Point(234, 267);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(13, 17);
            this.label110.TabIndex = 112;
            this.label110.Text = "/";
            // 
            // txtAYTSozelTarih2Dogru
            // 
            this.txtAYTSozelTarih2Dogru.Location = new System.Drawing.Point(169, 266);
            this.txtAYTSozelTarih2Dogru.Name = "txtAYTSozelTarih2Dogru";
            this.txtAYTSozelTarih2Dogru.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSozelTarih2Dogru.TabIndex = 111;
            this.txtAYTSozelTarih2Dogru.Text = "0";
            this.txtAYTSozelTarih2Dogru.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAYTSozelTurkceYanlis_KeyPress);
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label87.Location = new System.Drawing.Point(318, 237);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(58, 17);
            this.label87.TabIndex = 110;
            this.label87.Text = "06 Soru";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label88.Location = new System.Drawing.Point(318, 204);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(58, 17);
            this.label88.TabIndex = 109;
            this.label88.Text = "10 Soru";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label89.Location = new System.Drawing.Point(3, 237);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(125, 17);
            this.label89.TabIndex = 108;
            this.label89.Text = "Coğrafya-1 Testi : ";
            // 
            // txtAYTSozelCografya1Yanlis
            // 
            this.txtAYTSozelCografya1Yanlis.Location = new System.Drawing.Point(253, 236);
            this.txtAYTSozelCografya1Yanlis.Name = "txtAYTSozelCografya1Yanlis";
            this.txtAYTSozelCografya1Yanlis.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSozelCografya1Yanlis.TabIndex = 107;
            this.txtAYTSozelCografya1Yanlis.Text = "0";
            this.txtAYTSozelCografya1Yanlis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAYTSozelTurkceYanlis_KeyPress);
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label90.Location = new System.Drawing.Point(234, 237);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(13, 17);
            this.label90.TabIndex = 106;
            this.label90.Text = "/";
            // 
            // txtAYTSozelCografya1Dogru
            // 
            this.txtAYTSozelCografya1Dogru.Location = new System.Drawing.Point(169, 236);
            this.txtAYTSozelCografya1Dogru.Name = "txtAYTSozelCografya1Dogru";
            this.txtAYTSozelCografya1Dogru.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSozelCografya1Dogru.TabIndex = 105;
            this.txtAYTSozelCografya1Dogru.Text = "0";
            this.txtAYTSozelCografya1Dogru.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAYTSozelTurkceYanlis_KeyPress);
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label91.Location = new System.Drawing.Point(3, 204);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(101, 17);
            this.label91.TabIndex = 104;
            this.label91.Text = "Tarih-1 Testi : ";
            // 
            // txtAYTSozelTarih1Yanlis
            // 
            this.txtAYTSozelTarih1Yanlis.Location = new System.Drawing.Point(253, 203);
            this.txtAYTSozelTarih1Yanlis.Name = "txtAYTSozelTarih1Yanlis";
            this.txtAYTSozelTarih1Yanlis.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSozelTarih1Yanlis.TabIndex = 103;
            this.txtAYTSozelTarih1Yanlis.Text = "0";
            this.txtAYTSozelTarih1Yanlis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAYTSozelTurkceYanlis_KeyPress);
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label92.Location = new System.Drawing.Point(234, 204);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(13, 17);
            this.label92.TabIndex = 102;
            this.label92.Text = "/";
            // 
            // txtAYTSozelTarih1Dogru
            // 
            this.txtAYTSozelTarih1Dogru.Location = new System.Drawing.Point(169, 203);
            this.txtAYTSozelTarih1Dogru.Name = "txtAYTSozelTarih1Dogru";
            this.txtAYTSozelTarih1Dogru.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSozelTarih1Dogru.TabIndex = 101;
            this.txtAYTSozelTarih1Dogru.Text = "0";
            this.txtAYTSozelTarih1Dogru.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAYTSozelTurkceYanlis_KeyPress);
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label94.Location = new System.Drawing.Point(318, 172);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(58, 17);
            this.label94.TabIndex = 99;
            this.label94.Text = "24 Soru";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label97.Location = new System.Drawing.Point(3, 172);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(110, 17);
            this.label97.TabIndex = 94;
            this.label97.Text = "Edebiyat Testi : ";
            // 
            // txtAYTSozelEdebiyatYanlis
            // 
            this.txtAYTSozelEdebiyatYanlis.Location = new System.Drawing.Point(253, 171);
            this.txtAYTSozelEdebiyatYanlis.Name = "txtAYTSozelEdebiyatYanlis";
            this.txtAYTSozelEdebiyatYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSozelEdebiyatYanlis.TabIndex = 93;
            this.txtAYTSozelEdebiyatYanlis.Text = "0";
            this.txtAYTSozelEdebiyatYanlis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAYTSozelTurkceYanlis_KeyPress);
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label98.Location = new System.Drawing.Point(234, 172);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(13, 17);
            this.label98.TabIndex = 92;
            this.label98.Text = "/";
            // 
            // txtAYTSozelEdebiyatDogru
            // 
            this.txtAYTSozelEdebiyatDogru.Location = new System.Drawing.Point(169, 171);
            this.txtAYTSozelEdebiyatDogru.Name = "txtAYTSozelEdebiyatDogru";
            this.txtAYTSozelEdebiyatDogru.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSozelEdebiyatDogru.TabIndex = 91;
            this.txtAYTSozelEdebiyatDogru.Text = "0";
            this.txtAYTSozelEdebiyatDogru.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAYTSozelTurkceYanlis_KeyPress);
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label73.Location = new System.Drawing.Point(318, 142);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(58, 17);
            this.label73.TabIndex = 90;
            this.label73.Text = "20 Soru";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label74.Location = new System.Drawing.Point(318, 109);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(58, 17);
            this.label74.TabIndex = 89;
            this.label74.Text = "40 Soru";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label75.Location = new System.Drawing.Point(3, 142);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(131, 17);
            this.label75.TabIndex = 88;
            this.label75.Text = "Fen Bilimleri Testi : ";
            // 
            // txtAYTSozelFenYanlis
            // 
            this.txtAYTSozelFenYanlis.Location = new System.Drawing.Point(253, 141);
            this.txtAYTSozelFenYanlis.Name = "txtAYTSozelFenYanlis";
            this.txtAYTSozelFenYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSozelFenYanlis.TabIndex = 87;
            this.txtAYTSozelFenYanlis.Text = "0";
            this.txtAYTSozelFenYanlis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAYTSozelTurkceYanlis_KeyPress);
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label76.Location = new System.Drawing.Point(234, 142);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(13, 17);
            this.label76.TabIndex = 86;
            this.label76.Text = "/";
            // 
            // txtAYTSozelFenDogru
            // 
            this.txtAYTSozelFenDogru.Location = new System.Drawing.Point(169, 141);
            this.txtAYTSozelFenDogru.Name = "txtAYTSozelFenDogru";
            this.txtAYTSozelFenDogru.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSozelFenDogru.TabIndex = 85;
            this.txtAYTSozelFenDogru.Text = "0";
            this.txtAYTSozelFenDogru.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAYTSozelTurkceYanlis_KeyPress);
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label77.Location = new System.Drawing.Point(3, 109);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(162, 17);
            this.label77.TabIndex = 84;
            this.label77.Text = "Temel Matematik Testi : ";
            // 
            // txtAYTSozelTemelMatYanlis
            // 
            this.txtAYTSozelTemelMatYanlis.Location = new System.Drawing.Point(253, 108);
            this.txtAYTSozelTemelMatYanlis.Name = "txtAYTSozelTemelMatYanlis";
            this.txtAYTSozelTemelMatYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSozelTemelMatYanlis.TabIndex = 83;
            this.txtAYTSozelTemelMatYanlis.Text = "0";
            this.txtAYTSozelTemelMatYanlis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAYTSozelTurkceYanlis_KeyPress);
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label78.Location = new System.Drawing.Point(234, 109);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(13, 17);
            this.label78.TabIndex = 82;
            this.label78.Text = "/";
            // 
            // txtAYTSozelTemelMatDogru
            // 
            this.txtAYTSozelTemelMatDogru.Location = new System.Drawing.Point(169, 108);
            this.txtAYTSozelTemelMatDogru.Name = "txtAYTSozelTemelMatDogru";
            this.txtAYTSozelTemelMatDogru.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSozelTemelMatDogru.TabIndex = 81;
            this.txtAYTSozelTemelMatDogru.Text = "0";
            this.txtAYTSozelTemelMatDogru.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAYTSozelTurkceYanlis_KeyPress);
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label79.Location = new System.Drawing.Point(318, 76);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(58, 17);
            this.label79.TabIndex = 80;
            this.label79.Text = "20 Soru";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label80.Location = new System.Drawing.Point(318, 43);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(58, 17);
            this.label80.TabIndex = 79;
            this.label80.Text = "40 Soru";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label81.Location = new System.Drawing.Point(3, 76);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(146, 17);
            this.label81.TabIndex = 78;
            this.label81.Text = "Sosyal Bilimler Testi : ";
            // 
            // txtAYTSozelSosyalYanlis
            // 
            this.txtAYTSozelSosyalYanlis.Location = new System.Drawing.Point(253, 75);
            this.txtAYTSozelSosyalYanlis.Name = "txtAYTSozelSosyalYanlis";
            this.txtAYTSozelSosyalYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSozelSosyalYanlis.TabIndex = 77;
            this.txtAYTSozelSosyalYanlis.Text = "0";
            this.txtAYTSozelSosyalYanlis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAYTSozelTurkceYanlis_KeyPress);
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label82.Location = new System.Drawing.Point(234, 76);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(13, 17);
            this.label82.TabIndex = 76;
            this.label82.Text = "/";
            // 
            // txtAYTSozelSosyalDogru
            // 
            this.txtAYTSozelSosyalDogru.Location = new System.Drawing.Point(169, 75);
            this.txtAYTSozelSosyalDogru.Name = "txtAYTSozelSosyalDogru";
            this.txtAYTSozelSosyalDogru.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSozelSosyalDogru.TabIndex = 75;
            this.txtAYTSozelSosyalDogru.Text = "0";
            this.txtAYTSozelSosyalDogru.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAYTSozelTurkceYanlis_KeyPress);
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label83.Location = new System.Drawing.Point(3, 43);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(99, 17);
            this.label83.TabIndex = 74;
            this.label83.Text = "Türkçe Testi : ";
            // 
            // txtAYTSozelTurkceYanlis
            // 
            this.txtAYTSozelTurkceYanlis.Location = new System.Drawing.Point(253, 42);
            this.txtAYTSozelTurkceYanlis.Name = "txtAYTSozelTurkceYanlis";
            this.txtAYTSozelTurkceYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSozelTurkceYanlis.TabIndex = 73;
            this.txtAYTSozelTurkceYanlis.Text = "0";
            this.txtAYTSozelTurkceYanlis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAYTSozelTurkceYanlis_KeyPress);
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label84.Location = new System.Drawing.Point(253, 13);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(62, 17);
            this.label84.TabIndex = 72;
            this.label84.Text = "YANLIŞ";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label85.Location = new System.Drawing.Point(234, 43);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(13, 17);
            this.label85.TabIndex = 71;
            this.label85.Text = "/";
            // 
            // txtAYTSozelTurkceDogru
            // 
            this.txtAYTSozelTurkceDogru.Location = new System.Drawing.Point(169, 42);
            this.txtAYTSozelTurkceDogru.Name = "txtAYTSozelTurkceDogru";
            this.txtAYTSozelTurkceDogru.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSozelTurkceDogru.TabIndex = 70;
            this.txtAYTSozelTurkceDogru.Text = "0";
            this.txtAYTSozelTurkceDogru.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAYTSozelTurkceYanlis_KeyPress);
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label86.Location = new System.Drawing.Point(167, 13);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(65, 17);
            this.label86.TabIndex = 69;
            this.label86.Text = "DOĞRU";
            // 
            // panelAYTEsitAgirlik
            // 
            this.panelAYTEsitAgirlik.Controls.Add(this.label68);
            this.panelAYTEsitAgirlik.Controls.Add(this.label69);
            this.panelAYTEsitAgirlik.Controls.Add(this.label70);
            this.panelAYTEsitAgirlik.Controls.Add(this.txtEsitAgirlikCografya1Yanlis);
            this.panelAYTEsitAgirlik.Controls.Add(this.label71);
            this.panelAYTEsitAgirlik.Controls.Add(this.txtEsitAgirlikCografya1Dogru);
            this.panelAYTEsitAgirlik.Controls.Add(this.label72);
            this.panelAYTEsitAgirlik.Controls.Add(this.txtEsitAgirlikTarih1Yanlis);
            this.panelAYTEsitAgirlik.Controls.Add(this.label99);
            this.panelAYTEsitAgirlik.Controls.Add(this.txtEsitAgirlikTarih1Dogru);
            this.panelAYTEsitAgirlik.Controls.Add(this.label101);
            this.panelAYTEsitAgirlik.Controls.Add(this.label102);
            this.panelAYTEsitAgirlik.Controls.Add(this.label111);
            this.panelAYTEsitAgirlik.Controls.Add(this.txtEsitAgirlikEdebiyatYanlis);
            this.panelAYTEsitAgirlik.Controls.Add(this.label112);
            this.panelAYTEsitAgirlik.Controls.Add(this.txtEsitAgirlikEdebiyatDogru);
            this.panelAYTEsitAgirlik.Controls.Add(this.label113);
            this.panelAYTEsitAgirlik.Controls.Add(this.txtEsitAgirlikMatematikYanlis);
            this.panelAYTEsitAgirlik.Controls.Add(this.label114);
            this.panelAYTEsitAgirlik.Controls.Add(this.txtEsitAgirlikMatematikDogru);
            this.panelAYTEsitAgirlik.Controls.Add(this.label115);
            this.panelAYTEsitAgirlik.Controls.Add(this.label116);
            this.panelAYTEsitAgirlik.Controls.Add(this.label117);
            this.panelAYTEsitAgirlik.Controls.Add(this.txtEsitAgirlikFenYanlis);
            this.panelAYTEsitAgirlik.Controls.Add(this.label118);
            this.panelAYTEsitAgirlik.Controls.Add(this.txtEsitAgirlikFenDogru);
            this.panelAYTEsitAgirlik.Controls.Add(this.label119);
            this.panelAYTEsitAgirlik.Controls.Add(this.txtEsitAgirlikTemelMatYanlis);
            this.panelAYTEsitAgirlik.Controls.Add(this.label120);
            this.panelAYTEsitAgirlik.Controls.Add(this.txtEsitAgirlikTemelMatDogru);
            this.panelAYTEsitAgirlik.Controls.Add(this.label121);
            this.panelAYTEsitAgirlik.Controls.Add(this.label122);
            this.panelAYTEsitAgirlik.Controls.Add(this.label123);
            this.panelAYTEsitAgirlik.Controls.Add(this.txtEsitAgirlikSosyalYanlis);
            this.panelAYTEsitAgirlik.Controls.Add(this.label124);
            this.panelAYTEsitAgirlik.Controls.Add(this.txtEsitAgirlikSosyalDogru);
            this.panelAYTEsitAgirlik.Controls.Add(this.label125);
            this.panelAYTEsitAgirlik.Controls.Add(this.txtEsitAgirlikTurkceYanlis);
            this.panelAYTEsitAgirlik.Controls.Add(this.label126);
            this.panelAYTEsitAgirlik.Controls.Add(this.label127);
            this.panelAYTEsitAgirlik.Controls.Add(this.txtEsitAgirlikTurkceDogru);
            this.panelAYTEsitAgirlik.Controls.Add(this.label128);
            this.panelAYTEsitAgirlik.Location = new System.Drawing.Point(231, 36);
            this.panelAYTEsitAgirlik.Name = "panelAYTEsitAgirlik";
            this.panelAYTEsitAgirlik.Size = new System.Drawing.Size(384, 390);
            this.panelAYTEsitAgirlik.TabIndex = 74;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label68.Location = new System.Drawing.Point(318, 271);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(58, 17);
            this.label68.TabIndex = 110;
            this.label68.Text = "06 Soru";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label69.Location = new System.Drawing.Point(318, 238);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(58, 17);
            this.label69.TabIndex = 109;
            this.label69.Text = "10 Soru";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label70.Location = new System.Drawing.Point(3, 271);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(125, 17);
            this.label70.TabIndex = 108;
            this.label70.Text = "Coğrafya-1 Testi : ";
            // 
            // txtEsitAgirlikCografya1Yanlis
            // 
            this.txtEsitAgirlikCografya1Yanlis.Location = new System.Drawing.Point(253, 270);
            this.txtEsitAgirlikCografya1Yanlis.Name = "txtEsitAgirlikCografya1Yanlis";
            this.txtEsitAgirlikCografya1Yanlis.Size = new System.Drawing.Size(59, 20);
            this.txtEsitAgirlikCografya1Yanlis.TabIndex = 107;
            this.txtEsitAgirlikCografya1Yanlis.Text = "0";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label71.Location = new System.Drawing.Point(234, 271);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(13, 17);
            this.label71.TabIndex = 106;
            this.label71.Text = "/";
            // 
            // txtEsitAgirlikCografya1Dogru
            // 
            this.txtEsitAgirlikCografya1Dogru.Location = new System.Drawing.Point(169, 270);
            this.txtEsitAgirlikCografya1Dogru.Name = "txtEsitAgirlikCografya1Dogru";
            this.txtEsitAgirlikCografya1Dogru.Size = new System.Drawing.Size(59, 20);
            this.txtEsitAgirlikCografya1Dogru.TabIndex = 105;
            this.txtEsitAgirlikCografya1Dogru.Text = "0";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label72.Location = new System.Drawing.Point(3, 238);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(101, 17);
            this.label72.TabIndex = 104;
            this.label72.Text = "Tarih-1 Testi : ";
            // 
            // txtEsitAgirlikTarih1Yanlis
            // 
            this.txtEsitAgirlikTarih1Yanlis.Location = new System.Drawing.Point(253, 237);
            this.txtEsitAgirlikTarih1Yanlis.Name = "txtEsitAgirlikTarih1Yanlis";
            this.txtEsitAgirlikTarih1Yanlis.Size = new System.Drawing.Size(59, 20);
            this.txtEsitAgirlikTarih1Yanlis.TabIndex = 103;
            this.txtEsitAgirlikTarih1Yanlis.Text = "0";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label99.Location = new System.Drawing.Point(234, 238);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(13, 17);
            this.label99.TabIndex = 102;
            this.label99.Text = "/";
            // 
            // txtEsitAgirlikTarih1Dogru
            // 
            this.txtEsitAgirlikTarih1Dogru.Location = new System.Drawing.Point(169, 237);
            this.txtEsitAgirlikTarih1Dogru.Name = "txtEsitAgirlikTarih1Dogru";
            this.txtEsitAgirlikTarih1Dogru.Size = new System.Drawing.Size(59, 20);
            this.txtEsitAgirlikTarih1Dogru.TabIndex = 101;
            this.txtEsitAgirlikTarih1Dogru.Text = "0";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label101.Location = new System.Drawing.Point(318, 205);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(58, 17);
            this.label101.TabIndex = 100;
            this.label101.Text = "24 Soru";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label102.Location = new System.Drawing.Point(318, 172);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(58, 17);
            this.label102.TabIndex = 99;
            this.label102.Text = "40 Soru";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label111.Location = new System.Drawing.Point(3, 205);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(110, 17);
            this.label111.TabIndex = 98;
            this.label111.Text = "Edebiyat Testi : ";
            // 
            // txtEsitAgirlikEdebiyatYanlis
            // 
            this.txtEsitAgirlikEdebiyatYanlis.Location = new System.Drawing.Point(253, 204);
            this.txtEsitAgirlikEdebiyatYanlis.Name = "txtEsitAgirlikEdebiyatYanlis";
            this.txtEsitAgirlikEdebiyatYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtEsitAgirlikEdebiyatYanlis.TabIndex = 97;
            this.txtEsitAgirlikEdebiyatYanlis.Text = "0";
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label112.Location = new System.Drawing.Point(234, 205);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(13, 17);
            this.label112.TabIndex = 96;
            this.label112.Text = "/";
            // 
            // txtEsitAgirlikEdebiyatDogru
            // 
            this.txtEsitAgirlikEdebiyatDogru.Location = new System.Drawing.Point(169, 204);
            this.txtEsitAgirlikEdebiyatDogru.Name = "txtEsitAgirlikEdebiyatDogru";
            this.txtEsitAgirlikEdebiyatDogru.Size = new System.Drawing.Size(59, 20);
            this.txtEsitAgirlikEdebiyatDogru.TabIndex = 95;
            this.txtEsitAgirlikEdebiyatDogru.Text = "0";
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label113.Location = new System.Drawing.Point(3, 172);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(119, 17);
            this.label113.TabIndex = 94;
            this.label113.Text = "Matematik Testi : ";
            // 
            // txtEsitAgirlikMatematikYanlis
            // 
            this.txtEsitAgirlikMatematikYanlis.Location = new System.Drawing.Point(253, 171);
            this.txtEsitAgirlikMatematikYanlis.Name = "txtEsitAgirlikMatematikYanlis";
            this.txtEsitAgirlikMatematikYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtEsitAgirlikMatematikYanlis.TabIndex = 93;
            this.txtEsitAgirlikMatematikYanlis.Text = "0";
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label114.Location = new System.Drawing.Point(234, 172);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(13, 17);
            this.label114.TabIndex = 92;
            this.label114.Text = "/";
            // 
            // txtEsitAgirlikMatematikDogru
            // 
            this.txtEsitAgirlikMatematikDogru.Location = new System.Drawing.Point(169, 171);
            this.txtEsitAgirlikMatematikDogru.Name = "txtEsitAgirlikMatematikDogru";
            this.txtEsitAgirlikMatematikDogru.Size = new System.Drawing.Size(59, 20);
            this.txtEsitAgirlikMatematikDogru.TabIndex = 91;
            this.txtEsitAgirlikMatematikDogru.Text = "0";
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label115.Location = new System.Drawing.Point(318, 142);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(58, 17);
            this.label115.TabIndex = 90;
            this.label115.Text = "20 Soru";
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label116.Location = new System.Drawing.Point(318, 109);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(58, 17);
            this.label116.TabIndex = 89;
            this.label116.Text = "40 Soru";
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label117.Location = new System.Drawing.Point(3, 142);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(131, 17);
            this.label117.TabIndex = 88;
            this.label117.Text = "Fen Bilimleri Testi : ";
            // 
            // txtEsitAgirlikFenYanlis
            // 
            this.txtEsitAgirlikFenYanlis.Location = new System.Drawing.Point(253, 141);
            this.txtEsitAgirlikFenYanlis.Name = "txtEsitAgirlikFenYanlis";
            this.txtEsitAgirlikFenYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtEsitAgirlikFenYanlis.TabIndex = 87;
            this.txtEsitAgirlikFenYanlis.Text = "0";
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label118.Location = new System.Drawing.Point(234, 142);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(13, 17);
            this.label118.TabIndex = 86;
            this.label118.Text = "/";
            // 
            // txtEsitAgirlikFenDogru
            // 
            this.txtEsitAgirlikFenDogru.Location = new System.Drawing.Point(169, 141);
            this.txtEsitAgirlikFenDogru.Name = "txtEsitAgirlikFenDogru";
            this.txtEsitAgirlikFenDogru.Size = new System.Drawing.Size(59, 20);
            this.txtEsitAgirlikFenDogru.TabIndex = 85;
            this.txtEsitAgirlikFenDogru.Text = "0";
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label119.Location = new System.Drawing.Point(3, 109);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(162, 17);
            this.label119.TabIndex = 84;
            this.label119.Text = "Temel Matematik Testi : ";
            // 
            // txtEsitAgirlikTemelMatYanlis
            // 
            this.txtEsitAgirlikTemelMatYanlis.Location = new System.Drawing.Point(253, 108);
            this.txtEsitAgirlikTemelMatYanlis.Name = "txtEsitAgirlikTemelMatYanlis";
            this.txtEsitAgirlikTemelMatYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtEsitAgirlikTemelMatYanlis.TabIndex = 83;
            this.txtEsitAgirlikTemelMatYanlis.Text = "0";
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label120.Location = new System.Drawing.Point(234, 109);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(13, 17);
            this.label120.TabIndex = 82;
            this.label120.Text = "/";
            // 
            // txtEsitAgirlikTemelMatDogru
            // 
            this.txtEsitAgirlikTemelMatDogru.Location = new System.Drawing.Point(169, 108);
            this.txtEsitAgirlikTemelMatDogru.Name = "txtEsitAgirlikTemelMatDogru";
            this.txtEsitAgirlikTemelMatDogru.Size = new System.Drawing.Size(59, 20);
            this.txtEsitAgirlikTemelMatDogru.TabIndex = 81;
            this.txtEsitAgirlikTemelMatDogru.Text = "0";
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label121.Location = new System.Drawing.Point(318, 76);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(58, 17);
            this.label121.TabIndex = 80;
            this.label121.Text = "20 Soru";
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label122.Location = new System.Drawing.Point(318, 43);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(58, 17);
            this.label122.TabIndex = 79;
            this.label122.Text = "40 Soru";
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label123.Location = new System.Drawing.Point(3, 76);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(146, 17);
            this.label123.TabIndex = 78;
            this.label123.Text = "Sosyal Bilimler Testi : ";
            // 
            // txtEsitAgirlikSosyalYanlis
            // 
            this.txtEsitAgirlikSosyalYanlis.Location = new System.Drawing.Point(253, 75);
            this.txtEsitAgirlikSosyalYanlis.Name = "txtEsitAgirlikSosyalYanlis";
            this.txtEsitAgirlikSosyalYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtEsitAgirlikSosyalYanlis.TabIndex = 77;
            this.txtEsitAgirlikSosyalYanlis.Text = "0";
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label124.Location = new System.Drawing.Point(234, 76);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(13, 17);
            this.label124.TabIndex = 76;
            this.label124.Text = "/";
            // 
            // txtEsitAgirlikSosyalDogru
            // 
            this.txtEsitAgirlikSosyalDogru.Location = new System.Drawing.Point(169, 75);
            this.txtEsitAgirlikSosyalDogru.Name = "txtEsitAgirlikSosyalDogru";
            this.txtEsitAgirlikSosyalDogru.Size = new System.Drawing.Size(59, 20);
            this.txtEsitAgirlikSosyalDogru.TabIndex = 75;
            this.txtEsitAgirlikSosyalDogru.Text = "0";
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label125.Location = new System.Drawing.Point(3, 43);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(99, 17);
            this.label125.TabIndex = 74;
            this.label125.Text = "Türkçe Testi : ";
            // 
            // txtEsitAgirlikTurkceYanlis
            // 
            this.txtEsitAgirlikTurkceYanlis.Location = new System.Drawing.Point(253, 42);
            this.txtEsitAgirlikTurkceYanlis.Name = "txtEsitAgirlikTurkceYanlis";
            this.txtEsitAgirlikTurkceYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtEsitAgirlikTurkceYanlis.TabIndex = 73;
            this.txtEsitAgirlikTurkceYanlis.Text = "0";
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label126.Location = new System.Drawing.Point(253, 13);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(62, 17);
            this.label126.TabIndex = 72;
            this.label126.Text = "YANLIŞ";
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label127.Location = new System.Drawing.Point(234, 43);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(13, 17);
            this.label127.TabIndex = 71;
            this.label127.Text = "/";
            // 
            // txtEsitAgirlikTurkceDogru
            // 
            this.txtEsitAgirlikTurkceDogru.Location = new System.Drawing.Point(169, 42);
            this.txtEsitAgirlikTurkceDogru.Name = "txtEsitAgirlikTurkceDogru";
            this.txtEsitAgirlikTurkceDogru.Size = new System.Drawing.Size(59, 20);
            this.txtEsitAgirlikTurkceDogru.TabIndex = 70;
            this.txtEsitAgirlikTurkceDogru.Text = "0";
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label128.Location = new System.Drawing.Point(167, 13);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(65, 17);
            this.label128.TabIndex = 69;
            this.label128.Text = "DOĞRU";
            // 
            // panelAYTSayisal
            // 
            this.panelAYTSayisal.Controls.Add(this.label57);
            this.panelAYTSayisal.Controls.Add(this.label58);
            this.panelAYTSayisal.Controls.Add(this.label59);
            this.panelAYTSayisal.Controls.Add(this.txtAYTSayisalBiyolojiYanlis);
            this.panelAYTSayisal.Controls.Add(this.label60);
            this.panelAYTSayisal.Controls.Add(this.txtATYSayisalBiyolojiDogru);
            this.panelAYTSayisal.Controls.Add(this.label61);
            this.panelAYTSayisal.Controls.Add(this.txtAYTSayisalKimyaYanlis);
            this.panelAYTSayisal.Controls.Add(this.label62);
            this.panelAYTSayisal.Controls.Add(this.txtATYSayisalKimyaDogru);
            this.panelAYTSayisal.Controls.Add(this.label64);
            this.panelAYTSayisal.Controls.Add(this.label65);
            this.panelAYTSayisal.Controls.Add(this.label67);
            this.panelAYTSayisal.Controls.Add(this.txtAYTSayisalFizikYanlis);
            this.panelAYTSayisal.Controls.Add(this.label129);
            this.panelAYTSayisal.Controls.Add(this.txtATYSayisalFizikDogru);
            this.panelAYTSayisal.Controls.Add(this.label130);
            this.panelAYTSayisal.Controls.Add(this.txtAYTSayisalMatematikYanlis);
            this.panelAYTSayisal.Controls.Add(this.label131);
            this.panelAYTSayisal.Controls.Add(this.txtATYSayisalMatematikDogru);
            this.panelAYTSayisal.Controls.Add(this.label132);
            this.panelAYTSayisal.Controls.Add(this.label133);
            this.panelAYTSayisal.Controls.Add(this.label134);
            this.panelAYTSayisal.Controls.Add(this.txtAYTSayisalFenYanlis);
            this.panelAYTSayisal.Controls.Add(this.label135);
            this.panelAYTSayisal.Controls.Add(this.txtATYSayisalFenDogru);
            this.panelAYTSayisal.Controls.Add(this.label136);
            this.panelAYTSayisal.Controls.Add(this.txtAYTSayisalTemelMatYanlis);
            this.panelAYTSayisal.Controls.Add(this.label137);
            this.panelAYTSayisal.Controls.Add(this.txtATYSayisalTemelMatDogru);
            this.panelAYTSayisal.Controls.Add(this.label138);
            this.panelAYTSayisal.Controls.Add(this.label139);
            this.panelAYTSayisal.Controls.Add(this.label140);
            this.panelAYTSayisal.Controls.Add(this.txtAYTSayisalSosyalYanlis);
            this.panelAYTSayisal.Controls.Add(this.label141);
            this.panelAYTSayisal.Controls.Add(this.txtATYSayisalSosyalDogru);
            this.panelAYTSayisal.Controls.Add(this.label142);
            this.panelAYTSayisal.Controls.Add(this.txtAYTSayisalTurkceYanlis);
            this.panelAYTSayisal.Controls.Add(this.label143);
            this.panelAYTSayisal.Controls.Add(this.label144);
            this.panelAYTSayisal.Controls.Add(this.txtATYSayisalTurkceDogru);
            this.panelAYTSayisal.Controls.Add(this.label145);
            this.panelAYTSayisal.Location = new System.Drawing.Point(231, 36);
            this.panelAYTSayisal.Name = "panelAYTSayisal";
            this.panelAYTSayisal.Size = new System.Drawing.Size(384, 390);
            this.panelAYTSayisal.TabIndex = 75;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label57.Location = new System.Drawing.Point(318, 271);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(58, 17);
            this.label57.TabIndex = 110;
            this.label57.Text = "13 Soru";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label58.Location = new System.Drawing.Point(318, 238);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(58, 17);
            this.label58.TabIndex = 109;
            this.label58.Text = "13 Soru";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label59.Location = new System.Drawing.Point(3, 271);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(99, 17);
            this.label59.TabIndex = 108;
            this.label59.Text = "Biyoloji Testi : ";
            // 
            // txtAYTSayisalBiyolojiYanlis
            // 
            this.txtAYTSayisalBiyolojiYanlis.Location = new System.Drawing.Point(253, 270);
            this.txtAYTSayisalBiyolojiYanlis.Name = "txtAYTSayisalBiyolojiYanlis";
            this.txtAYTSayisalBiyolojiYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSayisalBiyolojiYanlis.TabIndex = 107;
            this.txtAYTSayisalBiyolojiYanlis.Text = "0";
            this.txtAYTSayisalBiyolojiYanlis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label60.Location = new System.Drawing.Point(234, 271);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(13, 17);
            this.label60.TabIndex = 106;
            this.label60.Text = "/";
            // 
            // txtATYSayisalBiyolojiDogru
            // 
            this.txtATYSayisalBiyolojiDogru.Location = new System.Drawing.Point(169, 270);
            this.txtATYSayisalBiyolojiDogru.Name = "txtATYSayisalBiyolojiDogru";
            this.txtATYSayisalBiyolojiDogru.Size = new System.Drawing.Size(59, 20);
            this.txtATYSayisalBiyolojiDogru.TabIndex = 105;
            this.txtATYSayisalBiyolojiDogru.Text = "0";
            this.txtATYSayisalBiyolojiDogru.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label61.Location = new System.Drawing.Point(3, 238);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(93, 17);
            this.label61.TabIndex = 104;
            this.label61.Text = "Kimya Testi : ";
            // 
            // txtAYTSayisalKimyaYanlis
            // 
            this.txtAYTSayisalKimyaYanlis.Location = new System.Drawing.Point(253, 237);
            this.txtAYTSayisalKimyaYanlis.Name = "txtAYTSayisalKimyaYanlis";
            this.txtAYTSayisalKimyaYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSayisalKimyaYanlis.TabIndex = 103;
            this.txtAYTSayisalKimyaYanlis.Text = "0";
            this.txtAYTSayisalKimyaYanlis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label62.Location = new System.Drawing.Point(234, 238);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(13, 17);
            this.label62.TabIndex = 102;
            this.label62.Text = "/";
            // 
            // txtATYSayisalKimyaDogru
            // 
            this.txtATYSayisalKimyaDogru.Location = new System.Drawing.Point(169, 237);
            this.txtATYSayisalKimyaDogru.Name = "txtATYSayisalKimyaDogru";
            this.txtATYSayisalKimyaDogru.Size = new System.Drawing.Size(59, 20);
            this.txtATYSayisalKimyaDogru.TabIndex = 101;
            this.txtATYSayisalKimyaDogru.Text = "0";
            this.txtATYSayisalKimyaDogru.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label64.Location = new System.Drawing.Point(318, 205);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(58, 17);
            this.label64.TabIndex = 100;
            this.label64.Text = "14 Soru";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label65.Location = new System.Drawing.Point(318, 172);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(58, 17);
            this.label65.TabIndex = 99;
            this.label65.Text = "40 Soru";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label67.Location = new System.Drawing.Point(3, 205);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(83, 17);
            this.label67.TabIndex = 98;
            this.label67.Text = "Fizik Testi : ";
            // 
            // txtAYTSayisalFizikYanlis
            // 
            this.txtAYTSayisalFizikYanlis.Location = new System.Drawing.Point(253, 204);
            this.txtAYTSayisalFizikYanlis.Name = "txtAYTSayisalFizikYanlis";
            this.txtAYTSayisalFizikYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSayisalFizikYanlis.TabIndex = 97;
            this.txtAYTSayisalFizikYanlis.Text = "0";
            this.txtAYTSayisalFizikYanlis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label129.Location = new System.Drawing.Point(234, 205);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(13, 17);
            this.label129.TabIndex = 96;
            this.label129.Text = "/";
            // 
            // txtATYSayisalFizikDogru
            // 
            this.txtATYSayisalFizikDogru.Location = new System.Drawing.Point(169, 204);
            this.txtATYSayisalFizikDogru.Name = "txtATYSayisalFizikDogru";
            this.txtATYSayisalFizikDogru.Size = new System.Drawing.Size(59, 20);
            this.txtATYSayisalFizikDogru.TabIndex = 95;
            this.txtATYSayisalFizikDogru.Text = "0";
            this.txtATYSayisalFizikDogru.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label130.Location = new System.Drawing.Point(3, 172);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(119, 17);
            this.label130.TabIndex = 94;
            this.label130.Text = "Matematik Testi : ";
            // 
            // txtAYTSayisalMatematikYanlis
            // 
            this.txtAYTSayisalMatematikYanlis.Location = new System.Drawing.Point(253, 171);
            this.txtAYTSayisalMatematikYanlis.Name = "txtAYTSayisalMatematikYanlis";
            this.txtAYTSayisalMatematikYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSayisalMatematikYanlis.TabIndex = 93;
            this.txtAYTSayisalMatematikYanlis.Text = "0";
            this.txtAYTSayisalMatematikYanlis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label131.Location = new System.Drawing.Point(234, 172);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(13, 17);
            this.label131.TabIndex = 92;
            this.label131.Text = "/";
            // 
            // txtATYSayisalMatematikDogru
            // 
            this.txtATYSayisalMatematikDogru.Location = new System.Drawing.Point(169, 171);
            this.txtATYSayisalMatematikDogru.Name = "txtATYSayisalMatematikDogru";
            this.txtATYSayisalMatematikDogru.Size = new System.Drawing.Size(59, 20);
            this.txtATYSayisalMatematikDogru.TabIndex = 91;
            this.txtATYSayisalMatematikDogru.Text = "0";
            this.txtATYSayisalMatematikDogru.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label132.Location = new System.Drawing.Point(318, 142);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(58, 17);
            this.label132.TabIndex = 90;
            this.label132.Text = "20 Soru";
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label133.Location = new System.Drawing.Point(318, 109);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(58, 17);
            this.label133.TabIndex = 89;
            this.label133.Text = "40 Soru";
            // 
            // label134
            // 
            this.label134.AutoSize = true;
            this.label134.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label134.Location = new System.Drawing.Point(3, 142);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(131, 17);
            this.label134.TabIndex = 88;
            this.label134.Text = "Fen Bilimleri Testi : ";
            // 
            // txtAYTSayisalFenYanlis
            // 
            this.txtAYTSayisalFenYanlis.Location = new System.Drawing.Point(253, 141);
            this.txtAYTSayisalFenYanlis.Name = "txtAYTSayisalFenYanlis";
            this.txtAYTSayisalFenYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSayisalFenYanlis.TabIndex = 87;
            this.txtAYTSayisalFenYanlis.Text = "0";
            this.txtAYTSayisalFenYanlis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label135
            // 
            this.label135.AutoSize = true;
            this.label135.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label135.Location = new System.Drawing.Point(234, 142);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(13, 17);
            this.label135.TabIndex = 86;
            this.label135.Text = "/";
            // 
            // txtATYSayisalFenDogru
            // 
            this.txtATYSayisalFenDogru.Location = new System.Drawing.Point(169, 141);
            this.txtATYSayisalFenDogru.Name = "txtATYSayisalFenDogru";
            this.txtATYSayisalFenDogru.Size = new System.Drawing.Size(59, 20);
            this.txtATYSayisalFenDogru.TabIndex = 85;
            this.txtATYSayisalFenDogru.Text = "0";
            this.txtATYSayisalFenDogru.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label136
            // 
            this.label136.AutoSize = true;
            this.label136.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label136.Location = new System.Drawing.Point(3, 109);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(162, 17);
            this.label136.TabIndex = 84;
            this.label136.Text = "Temel Matematik Testi : ";
            // 
            // txtAYTSayisalTemelMatYanlis
            // 
            this.txtAYTSayisalTemelMatYanlis.Location = new System.Drawing.Point(253, 108);
            this.txtAYTSayisalTemelMatYanlis.Name = "txtAYTSayisalTemelMatYanlis";
            this.txtAYTSayisalTemelMatYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSayisalTemelMatYanlis.TabIndex = 83;
            this.txtAYTSayisalTemelMatYanlis.Text = "0";
            this.txtAYTSayisalTemelMatYanlis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label137
            // 
            this.label137.AutoSize = true;
            this.label137.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label137.Location = new System.Drawing.Point(234, 109);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(13, 17);
            this.label137.TabIndex = 82;
            this.label137.Text = "/";
            // 
            // txtATYSayisalTemelMatDogru
            // 
            this.txtATYSayisalTemelMatDogru.Location = new System.Drawing.Point(169, 108);
            this.txtATYSayisalTemelMatDogru.Name = "txtATYSayisalTemelMatDogru";
            this.txtATYSayisalTemelMatDogru.Size = new System.Drawing.Size(59, 20);
            this.txtATYSayisalTemelMatDogru.TabIndex = 81;
            this.txtATYSayisalTemelMatDogru.Text = "0";
            this.txtATYSayisalTemelMatDogru.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label138
            // 
            this.label138.AutoSize = true;
            this.label138.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label138.Location = new System.Drawing.Point(318, 76);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(58, 17);
            this.label138.TabIndex = 80;
            this.label138.Text = "20 Soru";
            // 
            // label139
            // 
            this.label139.AutoSize = true;
            this.label139.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label139.Location = new System.Drawing.Point(318, 43);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(58, 17);
            this.label139.TabIndex = 79;
            this.label139.Text = "40 Soru";
            // 
            // label140
            // 
            this.label140.AutoSize = true;
            this.label140.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label140.Location = new System.Drawing.Point(3, 76);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(146, 17);
            this.label140.TabIndex = 78;
            this.label140.Text = "Sosyal Bilimler Testi : ";
            // 
            // txtAYTSayisalSosyalYanlis
            // 
            this.txtAYTSayisalSosyalYanlis.Location = new System.Drawing.Point(253, 75);
            this.txtAYTSayisalSosyalYanlis.Name = "txtAYTSayisalSosyalYanlis";
            this.txtAYTSayisalSosyalYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSayisalSosyalYanlis.TabIndex = 77;
            this.txtAYTSayisalSosyalYanlis.Text = "0";
            this.txtAYTSayisalSosyalYanlis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label141.Location = new System.Drawing.Point(234, 76);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(13, 17);
            this.label141.TabIndex = 76;
            this.label141.Text = "/";
            // 
            // txtATYSayisalSosyalDogru
            // 
            this.txtATYSayisalSosyalDogru.Location = new System.Drawing.Point(169, 75);
            this.txtATYSayisalSosyalDogru.Name = "txtATYSayisalSosyalDogru";
            this.txtATYSayisalSosyalDogru.Size = new System.Drawing.Size(59, 20);
            this.txtATYSayisalSosyalDogru.TabIndex = 75;
            this.txtATYSayisalSosyalDogru.Text = "0";
            this.txtATYSayisalSosyalDogru.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label142
            // 
            this.label142.AutoSize = true;
            this.label142.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label142.Location = new System.Drawing.Point(3, 43);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(99, 17);
            this.label142.TabIndex = 74;
            this.label142.Text = "Türkçe Testi : ";
            // 
            // txtAYTSayisalTurkceYanlis
            // 
            this.txtAYTSayisalTurkceYanlis.Location = new System.Drawing.Point(253, 42);
            this.txtAYTSayisalTurkceYanlis.Name = "txtAYTSayisalTurkceYanlis";
            this.txtAYTSayisalTurkceYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtAYTSayisalTurkceYanlis.TabIndex = 73;
            this.txtAYTSayisalTurkceYanlis.Text = "0";
            this.txtAYTSayisalTurkceYanlis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label143
            // 
            this.label143.AutoSize = true;
            this.label143.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label143.Location = new System.Drawing.Point(253, 13);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(62, 17);
            this.label143.TabIndex = 72;
            this.label143.Text = "YANLIŞ";
            // 
            // label144
            // 
            this.label144.AutoSize = true;
            this.label144.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label144.Location = new System.Drawing.Point(234, 43);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(13, 17);
            this.label144.TabIndex = 71;
            this.label144.Text = "/";
            // 
            // txtATYSayisalTurkceDogru
            // 
            this.txtATYSayisalTurkceDogru.Location = new System.Drawing.Point(169, 42);
            this.txtATYSayisalTurkceDogru.Name = "txtATYSayisalTurkceDogru";
            this.txtATYSayisalTurkceDogru.Size = new System.Drawing.Size(59, 20);
            this.txtATYSayisalTurkceDogru.TabIndex = 70;
            this.txtATYSayisalTurkceDogru.Text = "0";
            this.txtATYSayisalTurkceDogru.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label145
            // 
            this.label145.AutoSize = true;
            this.label145.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label145.Location = new System.Drawing.Point(167, 13);
            this.label145.Name = "label145";
            this.label145.Size = new System.Drawing.Size(65, 17);
            this.label145.TabIndex = 69;
            this.label145.Text = "DOĞRU";
            // 
            // panelTYTHesap
            // 
            this.panelTYTHesap.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panelTYTHesap.Controls.Add(this.btnTYTTemizle);
            this.panelTYTHesap.Controls.Add(this.lblTYT);
            this.panelTYTHesap.Controls.Add(this.lblTYTpuan);
            this.panelTYTHesap.Controls.Add(this.btnTYTHesapla);
            this.panelTYTHesap.Controls.Add(this.label50);
            this.panelTYTHesap.Controls.Add(this.label51);
            this.panelTYTHesap.Controls.Add(this.label52);
            this.panelTYTHesap.Controls.Add(this.txtTYTFenYanlis);
            this.panelTYTHesap.Controls.Add(this.label53);
            this.panelTYTHesap.Controls.Add(this.txtTYTFenDogru);
            this.panelTYTHesap.Controls.Add(this.label54);
            this.panelTYTHesap.Controls.Add(this.txtTYTMatematikYanlis);
            this.panelTYTHesap.Controls.Add(this.label55);
            this.panelTYTHesap.Controls.Add(this.txtTYTMatematikDogru);
            this.panelTYTHesap.Controls.Add(this.label8);
            this.panelTYTHesap.Controls.Add(this.label41);
            this.panelTYTHesap.Controls.Add(this.label42);
            this.panelTYTHesap.Controls.Add(this.label43);
            this.panelTYTHesap.Controls.Add(this.txtTYTobp);
            this.panelTYTHesap.Controls.Add(this.label44);
            this.panelTYTHesap.Controls.Add(this.txtTYTSosyalYanlis);
            this.panelTYTHesap.Controls.Add(this.label45);
            this.panelTYTHesap.Controls.Add(this.txtTYTSosyalDogru);
            this.panelTYTHesap.Controls.Add(this.label46);
            this.panelTYTHesap.Controls.Add(this.txtTYTTurkceYanlis);
            this.panelTYTHesap.Controls.Add(this.label47);
            this.panelTYTHesap.Controls.Add(this.label48);
            this.panelTYTHesap.Controls.Add(this.txtTYTTurkceDogru);
            this.panelTYTHesap.Controls.Add(this.label49);
            this.panelTYTHesap.Location = new System.Drawing.Point(3, 27);
            this.panelTYTHesap.Name = "panelTYTHesap";
            this.panelTYTHesap.Size = new System.Drawing.Size(1018, 543);
            this.panelTYTHesap.TabIndex = 8;
            // 
            // btnTYTTemizle
            // 
            this.btnTYTTemizle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnTYTTemizle.Location = new System.Drawing.Point(466, 301);
            this.btnTYTTemizle.Name = "btnTYTTemizle";
            this.btnTYTTemizle.Size = new System.Drawing.Size(98, 46);
            this.btnTYTTemizle.TabIndex = 43;
            this.btnTYTTemizle.Text = "TEMİZLE";
            this.btnTYTTemizle.UseVisualStyleBackColor = true;
            this.btnTYTTemizle.Click += new System.EventHandler(this.btnTYTTemizle_Click);
            // 
            // lblTYT
            // 
            this.lblTYT.AutoSize = true;
            this.lblTYT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTYT.Location = new System.Drawing.Point(357, 383);
            this.lblTYT.Name = "lblTYT";
            this.lblTYT.Size = new System.Drawing.Size(0, 17);
            this.lblTYT.TabIndex = 42;
            this.lblTYT.Visible = false;
            // 
            // lblTYTpuan
            // 
            this.lblTYTpuan.AutoSize = true;
            this.lblTYTpuan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTYTpuan.Location = new System.Drawing.Point(191, 383);
            this.lblTYTpuan.Name = "lblTYTpuan";
            this.lblTYTpuan.Size = new System.Drawing.Size(87, 17);
            this.lblTYTpuan.TabIndex = 41;
            this.lblTYTpuan.Text = "TYT Puanı : ";
            this.lblTYTpuan.Visible = false;
            // 
            // btnTYTHesapla
            // 
            this.btnTYTHesapla.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnTYTHesapla.Location = new System.Drawing.Point(358, 300);
            this.btnTYTHesapla.Name = "btnTYTHesapla";
            this.btnTYTHesapla.Size = new System.Drawing.Size(98, 46);
            this.btnTYTHesapla.TabIndex = 40;
            this.btnTYTHesapla.Text = "HESAPLA";
            this.btnTYTHesapla.UseVisualStyleBackColor = true;
            this.btnTYTHesapla.Click += new System.EventHandler(this.btnTYTHesapla_Click);
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label50.Location = new System.Drawing.Point(506, 233);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(58, 17);
            this.label50.TabIndex = 39;
            this.label50.Text = "20 Soru";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label51.Location = new System.Drawing.Point(506, 200);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(58, 17);
            this.label51.TabIndex = 38;
            this.label51.Text = "40 Soru";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label52.Location = new System.Drawing.Point(191, 233);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(131, 17);
            this.label52.TabIndex = 37;
            this.label52.Text = "Fen Bilimleri Testi : ";
            // 
            // txtTYTFenYanlis
            // 
            this.txtTYTFenYanlis.Location = new System.Drawing.Point(441, 232);
            this.txtTYTFenYanlis.Name = "txtTYTFenYanlis";
            this.txtTYTFenYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtTYTFenYanlis.TabIndex = 36;
            this.txtTYTFenYanlis.Text = "0";
            this.txtTYTFenYanlis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTYTTurkceDogru_KeyPress);
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label53.Location = new System.Drawing.Point(422, 233);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(13, 17);
            this.label53.TabIndex = 35;
            this.label53.Text = "/";
            // 
            // txtTYTFenDogru
            // 
            this.txtTYTFenDogru.Location = new System.Drawing.Point(357, 232);
            this.txtTYTFenDogru.Name = "txtTYTFenDogru";
            this.txtTYTFenDogru.Size = new System.Drawing.Size(59, 20);
            this.txtTYTFenDogru.TabIndex = 34;
            this.txtTYTFenDogru.Text = "0";
            this.txtTYTFenDogru.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTYTTurkceDogru_KeyPress);
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label54.Location = new System.Drawing.Point(191, 200);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(162, 17);
            this.label54.TabIndex = 33;
            this.label54.Text = "Temel Matematik Testi : ";
            // 
            // txtTYTMatematikYanlis
            // 
            this.txtTYTMatematikYanlis.Location = new System.Drawing.Point(441, 199);
            this.txtTYTMatematikYanlis.Name = "txtTYTMatematikYanlis";
            this.txtTYTMatematikYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtTYTMatematikYanlis.TabIndex = 32;
            this.txtTYTMatematikYanlis.Text = "0";
            this.txtTYTMatematikYanlis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTYTTurkceDogru_KeyPress);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label55.Location = new System.Drawing.Point(422, 200);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(13, 17);
            this.label55.TabIndex = 31;
            this.label55.Text = "/";
            // 
            // txtTYTMatematikDogru
            // 
            this.txtTYTMatematikDogru.Location = new System.Drawing.Point(357, 199);
            this.txtTYTMatematikDogru.Name = "txtTYTMatematikDogru";
            this.txtTYTMatematikDogru.Size = new System.Drawing.Size(59, 20);
            this.txtTYTMatematikDogru.TabIndex = 30;
            this.txtTYTMatematikDogru.Text = "0";
            this.txtTYTMatematikDogru.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTYTTurkceDogru_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(422, 266);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(150, 17);
            this.label8.TabIndex = 29;
            this.label8.Text = "En az 250, en çok 500";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label41.Location = new System.Drawing.Point(506, 167);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(58, 17);
            this.label41.TabIndex = 28;
            this.label41.Text = "20 Soru";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label42.Location = new System.Drawing.Point(506, 134);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(58, 17);
            this.label42.TabIndex = 27;
            this.label42.Text = "40 Soru";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label43.Location = new System.Drawing.Point(191, 266);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(158, 17);
            this.label43.TabIndex = 26;
            this.label43.Text = "O. Başarı Puanı(OBP) : ";
            // 
            // txtTYTobp
            // 
            this.txtTYTobp.Location = new System.Drawing.Point(357, 265);
            this.txtTYTobp.Name = "txtTYTobp";
            this.txtTYTobp.Size = new System.Drawing.Size(59, 20);
            this.txtTYTobp.TabIndex = 25;
            this.txtTYTobp.Text = "250";
            this.txtTYTobp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTYTobp_KeyPress);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label44.Location = new System.Drawing.Point(191, 167);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(146, 17);
            this.label44.TabIndex = 24;
            this.label44.Text = "Sosyal Bilimler Testi : ";
            // 
            // txtTYTSosyalYanlis
            // 
            this.txtTYTSosyalYanlis.Location = new System.Drawing.Point(441, 166);
            this.txtTYTSosyalYanlis.Name = "txtTYTSosyalYanlis";
            this.txtTYTSosyalYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtTYTSosyalYanlis.TabIndex = 23;
            this.txtTYTSosyalYanlis.Text = "0";
            this.txtTYTSosyalYanlis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTYTTurkceDogru_KeyPress);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label45.Location = new System.Drawing.Point(422, 167);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(13, 17);
            this.label45.TabIndex = 22;
            this.label45.Text = "/";
            // 
            // txtTYTSosyalDogru
            // 
            this.txtTYTSosyalDogru.Location = new System.Drawing.Point(357, 166);
            this.txtTYTSosyalDogru.Name = "txtTYTSosyalDogru";
            this.txtTYTSosyalDogru.Size = new System.Drawing.Size(59, 20);
            this.txtTYTSosyalDogru.TabIndex = 21;
            this.txtTYTSosyalDogru.Text = "0";
            this.txtTYTSosyalDogru.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTYTTurkceDogru_KeyPress);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label46.Location = new System.Drawing.Point(191, 134);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(99, 17);
            this.label46.TabIndex = 20;
            this.label46.Text = "Türkçe Testi : ";
            // 
            // txtTYTTurkceYanlis
            // 
            this.txtTYTTurkceYanlis.Location = new System.Drawing.Point(441, 133);
            this.txtTYTTurkceYanlis.Name = "txtTYTTurkceYanlis";
            this.txtTYTTurkceYanlis.Size = new System.Drawing.Size(59, 20);
            this.txtTYTTurkceYanlis.TabIndex = 19;
            this.txtTYTTurkceYanlis.Text = "0";
            this.txtTYTTurkceYanlis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTYTTurkceDogru_KeyPress);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label47.Location = new System.Drawing.Point(441, 104);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(62, 17);
            this.label47.TabIndex = 18;
            this.label47.Text = "YANLIŞ";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label48.Location = new System.Drawing.Point(422, 134);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(13, 17);
            this.label48.TabIndex = 17;
            this.label48.Text = "/";
            // 
            // txtTYTTurkceDogru
            // 
            this.txtTYTTurkceDogru.Location = new System.Drawing.Point(357, 133);
            this.txtTYTTurkceDogru.Name = "txtTYTTurkceDogru";
            this.txtTYTTurkceDogru.Size = new System.Drawing.Size(59, 20);
            this.txtTYTTurkceDogru.TabIndex = 16;
            this.txtTYTTurkceDogru.Text = "0";
            this.txtTYTTurkceDogru.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTYTTurkceDogru_KeyPress);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label49.Location = new System.Drawing.Point(355, 104);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(65, 17);
            this.label49.TabIndex = 15;
            this.label49.Text = "DOĞRU";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1024, 571);
            this.Controls.Add(this.panelKullaniciGirisi);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelKayitOl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MainMenuStrip = this.menuStrip;
            this.MaximumSize = new System.Drawing.Size(1044, 614);
            this.MinimumSize = new System.Drawing.Size(1044, 614);
            this.Name = "Form1";
            this.Text = "ETÜT Takip Sistemi";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelKullaniciGirisi.ResumeLayout(false);
            this.panelKullaniciGirisi.PerformLayout();
            this.panelKayitOl.ResumeLayout(false);
            this.panelKayitOl.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelAnaSayfa.ResumeLayout(false);
            this.panelAnaSayfa.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.panelDersIslemleri.ResumeLayout(false);
            this.panelDersIslemleri.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDersIslemleri)).EndInit();
            this.panelNotIslemleri.ResumeLayout(false);
            this.panelNotIslemleri.PerformLayout();
            this.panelNotIslemleriAramaIslemi.ResumeLayout(false);
            this.panelNotIslemleriAramaIslemi.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewNotIslemleri)).EndInit();
            this.panelOgrenciKayitIslemleri.ResumeLayout(false);
            this.panelOgrenciKayitIslemleri.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOgrenciEkleCikar)).EndInit();
            this.panelEtutleriGoruntule.ResumeLayout(false);
            this.panelEtutleriGoruntule.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEtutGoruntule)).EndInit();
            this.panelYeniEtüt.ResumeLayout(false);
            this.panelYeniEtüt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEtutEkleme)).EndInit();
            this.panelOgretmenIslemleri.ResumeLayout(false);
            this.panelOgretmenIslemleri.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOgretmenIslemleri)).EndInit();
            this.panelOgrencileriGoruntuleme.ResumeLayout(false);
            this.panelOgrencileriGoruntuleme.PerformLayout();
            this.panelOgrFiltreCinsiyet.ResumeLayout(false);
            this.panelOgrFiltreCinsiyet.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOgrencileriGoruntule)).EndInit();
            this.panelDGSHesap.ResumeLayout(false);
            this.panelDGSHesap.PerformLayout();
            this.panelAYTHesap.ResumeLayout(false);
            this.panelAYTHesap.PerformLayout();
            this.panelAYTSozel.ResumeLayout(false);
            this.panelAYTSozel.PerformLayout();
            this.panelAYTEsitAgirlik.ResumeLayout(false);
            this.panelAYTEsitAgirlik.PerformLayout();
            this.panelAYTSayisal.ResumeLayout(false);
            this.panelAYTSayisal.PerformLayout();
            this.panelTYTHesap.ResumeLayout(false);
            this.panelTYTHesap.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panelKullaniciGirisi;
        private System.Windows.Forms.TextBox txtKullaniciGirisSifre;
        private System.Windows.Forms.TextBox txtKullaniciGirisKullaniciAdi;
        private System.Windows.Forms.Button btnKullaniciGiris;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.LinkLabel linkLabelKayitOl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelKayitOl;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtKayitOlSifreTekrar;
        private System.Windows.Forms.TextBox txtKayitOlSifre;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtKayitOlKullaniciAdi;
        private System.Windows.Forms.Button btnKayitOl;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem anaSayfaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem öğrenciİşlemleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem öğrenciKayToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem öğrencToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem notGörüntülemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem etütİşlemleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem öğretmenİşlemleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dersİşlemleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tYTAYTDGSPuanHesaplamaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aYTPuanHesaplamaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dGSPuanHesaplamaToolStripMenuItem;
        private System.Windows.Forms.Label labelSaatTarih;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripMenuItem yeniEtütToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem etütGörüntülemeToolStripMenuItem;
        private System.Windows.Forms.Panel panelDGSHesap;
        private System.Windows.Forms.Panel panelAYTHesap;
        private System.Windows.Forms.Panel panelTYTHesap;
        private System.Windows.Forms.Panel panelOgretmenIslemleri;
        private System.Windows.Forms.Panel panelEtutleriGoruntule;
        private System.Windows.Forms.Panel panelYeniEtüt;
        private System.Windows.Forms.Panel panelNotIslemleri;
        private System.Windows.Forms.Panel panelOgrenciKayitIslemleri;
        private System.Windows.Forms.Panel panelAnaSayfa;
        private System.Windows.Forms.Panel panelOgrencileriGoruntuleme;
        private System.Windows.Forms.Panel panelDersIslemleri;
        private System.Windows.Forms.DataGridView dataGridViewOgrencileriGoruntule;
        private System.Windows.Forms.TextBox txtOgrFiltreSoyisim;
        private System.Windows.Forms.TextBox txtOgrFiltreIsim;
        private System.Windows.Forms.TextBox txtOgrFiltreTC;
        private System.Windows.Forms.RadioButton radioButtonOgrFiltreSoyisim;
        private System.Windows.Forms.RadioButton radioButtonOgrFiltreCinsiyet;
        private System.Windows.Forms.RadioButton radioButtonOgrFiltreIsim;
        private System.Windows.Forms.RadioButton radioButtonOgrFiltreTC;
        private System.Windows.Forms.Panel panelOgrFiltreCinsiyet;
        private System.Windows.Forms.RadioButton radioButtonOgrFiltreErkek;
        private System.Windows.Forms.RadioButton radioButtonOgrFiltreKadin;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button btnOgrFiltreAra;
        private System.Windows.Forms.DataGridView dataGridViewOgrenciEkleCikar;
        private System.Windows.Forms.RadioButton radioButtonOgrKayitIslemleriGuncellemeIslemi;
        private System.Windows.Forms.RadioButton radioButtonOgrKayitIslemleriEklemeIslemi;
        private System.Windows.Forms.Button btnOgrenciGorntulemeSIL;
        private System.Windows.Forms.Button btnOgrKayitIslemleriEkle;
        private System.Windows.Forms.Button btnOgrKayitIslemleriGuncelle;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.DateTimePicker dateTimePickerKayitIslemleri;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton radioButtonOgrKayitIslemleriErkek;
        private System.Windows.Forms.RadioButton radioButtonOgrKayitIslemleriKadin;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtOgrKayitIslemleriAdres;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtOgrKayitIslemleriTelefon;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtOgrKayitIslemleriSoyisim;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtOgrKayitIslemleriIsim;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtOgrKayitIslemleriTC;
        private System.Windows.Forms.RadioButton radioButtonNotIslemleriGuncellemeIslemi;
        private System.Windows.Forms.RadioButton radioButtonNotIslemleriEklemeIslemi;
        private System.Windows.Forms.DataGridView dataGridViewNotIslemleri;
        private System.Windows.Forms.TextBox txtNotIslemleriNot;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comboBoxNotIslemleriDers;
        private System.Windows.Forms.ComboBox comboBoxNotIslemleriOgrenci;
        private System.Windows.Forms.RadioButton radioButtonNotIslemleriAramaIslemi;
        private System.Windows.Forms.Button btnNotIslemleriEkleKaydet;
        private System.Windows.Forms.Panel panelNotIslemleriAramaIslemi;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtNotIslemleriAramaMax;
        private System.Windows.Forms.TextBox txtNotIslemleriAramaMin;
        private System.Windows.Forms.ComboBox comboBoxNotIslemleriAramaDers;
        private System.Windows.Forms.ComboBox comboBoxNotIslemleriAramaOgrenci;
        private System.Windows.Forms.RadioButton radioButtonNotIslemleriAramaNot;
        private System.Windows.Forms.RadioButton radioButtonNotIslemleriAramaDers;
        private System.Windows.Forms.RadioButton radioButtonNotIslemleriAramaOgrenci;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button btnNotIslemleriArama;
        private System.Windows.Forms.TextBox txtOgretmenIslemleriSoyadi;
        private System.Windows.Forms.TextBox txtOgretmenIslemleriAdi;
        private System.Windows.Forms.DataGridView dataGridViewOgretmenIslemleri;
        private System.Windows.Forms.Button btnOgretmenIslemleriEkleSil;
        private System.Windows.Forms.TextBox txtOgretmenIslemleriTC;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.RadioButton radioButtonOgretmenIslemleriSilme;
        private System.Windows.Forms.RadioButton radioButtonOgretmenIslemleriEkleme;
        private System.Windows.Forms.TextBox txtDersIslemleriDersAdi;
        private System.Windows.Forms.DataGridView dataGridViewDersIslemleri;
        private System.Windows.Forms.Button btnDersIslemleriEkleSil;
        private System.Windows.Forms.TextBox txtDersIslemleriDersID;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.RadioButton radioButtonDersIslemleriSilme;
        private System.Windows.Forms.RadioButton radioButtonDersIslemleriEkleme;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtDGSonlisansPuani;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtDGSSozelYanlis;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txtDGSSozelDogru;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtDGSSayisalYanlis;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtDGSSayisalDogru;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnDGSTemizle;
        private System.Windows.Forms.Button btnDGSHesapla;
        private System.Windows.Forms.CheckBox checkBoxDGS;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label lblEsitAgirlikPuani;
        private System.Windows.Forms.Label lblSozelPuani;
        private System.Windows.Forms.Label lblSayisalPuan;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Button btnTYTHesapla;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox txtTYTFenYanlis;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox txtTYTFenDogru;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox txtTYTMatematikYanlis;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox txtTYTMatematikDogru;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox txtTYTobp;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox txtTYTSosyalYanlis;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox txtTYTSosyalDogru;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox txtTYTTurkceYanlis;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox txtTYTTurkceDogru;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label lblTYT;
        private System.Windows.Forms.Label lblTYTpuan;
        private System.Windows.Forms.Button btnTYTTemizle;
        private System.Windows.Forms.Panel panelAYTSozel;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.TextBox txtAYTSozelDKABYanlis;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.TextBox txtAYTSozelDKABDogru;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.TextBox txtAYTSozelCografya2Yanlis;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.TextBox txtAYTSozelCografya2Dogru;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.TextBox txtAYTSozelTarih2Yanlis;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.TextBox txtAYTSozelTarih2Dogru;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.TextBox txtAYTSozelCografya1Yanlis;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.TextBox txtAYTSozelCografya1Dogru;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.TextBox txtAYTSozelTarih1Yanlis;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.TextBox txtAYTSozelTarih1Dogru;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.TextBox txtAYTSozelEdebiyatYanlis;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.TextBox txtAYTSozelEdebiyatDogru;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.TextBox txtAYTSozelFenYanlis;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.TextBox txtAYTSozelFenDogru;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.TextBox txtAYTSozelTemelMatYanlis;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.TextBox txtAYTSozelTemelMatDogru;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.TextBox txtAYTSozelSosyalYanlis;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.TextBox txtAYTSozelSosyalDogru;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.TextBox txtAYTSozelTurkceYanlis;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.TextBox txtAYTSozelTurkceDogru;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Button btnAYTTemizle;
        private System.Windows.Forms.Label lblAYTpuani;
        private System.Windows.Forms.Label lblAYTpuanTuru;
        private System.Windows.Forms.Button btnAYTHesapla;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox txtAYTobp;
        private System.Windows.Forms.Panel panelAYTSayisal;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox txtAYTSayisalBiyolojiYanlis;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox txtATYSayisalBiyolojiDogru;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox txtAYTSayisalKimyaYanlis;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox txtATYSayisalKimyaDogru;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox txtAYTSayisalFizikYanlis;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.TextBox txtATYSayisalFizikDogru;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.TextBox txtAYTSayisalMatematikYanlis;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.TextBox txtATYSayisalMatematikDogru;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.TextBox txtAYTSayisalFenYanlis;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.TextBox txtATYSayisalFenDogru;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.TextBox txtAYTSayisalTemelMatYanlis;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.TextBox txtATYSayisalTemelMatDogru;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.TextBox txtAYTSayisalSosyalYanlis;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.TextBox txtATYSayisalSosyalDogru;
        private System.Windows.Forms.Label label142;
        private System.Windows.Forms.TextBox txtAYTSayisalTurkceYanlis;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.Label label144;
        private System.Windows.Forms.TextBox txtATYSayisalTurkceDogru;
        private System.Windows.Forms.Label label145;
        private System.Windows.Forms.Panel panelAYTEsitAgirlik;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TextBox txtEsitAgirlikCografya1Yanlis;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.TextBox txtEsitAgirlikCografya1Dogru;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.TextBox txtEsitAgirlikTarih1Yanlis;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.TextBox txtEsitAgirlikTarih1Dogru;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.TextBox txtEsitAgirlikEdebiyatYanlis;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.TextBox txtEsitAgirlikEdebiyatDogru;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.TextBox txtEsitAgirlikMatematikYanlis;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.TextBox txtEsitAgirlikMatematikDogru;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.TextBox txtEsitAgirlikFenYanlis;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.TextBox txtEsitAgirlikFenDogru;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.TextBox txtEsitAgirlikTemelMatYanlis;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.TextBox txtEsitAgirlikTemelMatDogru;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.TextBox txtEsitAgirlikSosyalYanlis;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.TextBox txtEsitAgirlikSosyalDogru;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.TextBox txtEsitAgirlikTurkceYanlis;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.TextBox txtEsitAgirlikTurkceDogru;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.RadioButton radioButtonAYTEsitAgirlik;
        private System.Windows.Forms.RadioButton radioButtonAYTSayisal;
        private System.Windows.Forms.RadioButton radioButtonAYTSozel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox txtAYTSozelFelsefeYanlis;
        private System.Windows.Forms.Label label146;
        private System.Windows.Forms.TextBox txtAYTSozelFelsefeDogru;
        private System.Windows.Forms.DateTimePicker dateTimePickerEtutTarih;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Button btnEtut22;
        private System.Windows.Forms.Button btnEtut21;
        private System.Windows.Forms.Button btnEtut20;
        private System.Windows.Forms.Button btnEtut19;
        private System.Windows.Forms.Button btnEtut18;
        private System.Windows.Forms.Button btnEtut17;
        private System.Windows.Forms.Button btnEtut16;
        private System.Windows.Forms.Button btnEtut15;
        private System.Windows.Forms.Button btnEtut14;
        private System.Windows.Forms.Button btnEtut13;
        private System.Windows.Forms.Button btnEtut12;
        private System.Windows.Forms.Button btnEtut11;
        private System.Windows.Forms.Button btnEtut10;
        private System.Windows.Forms.Button btnEtut09;
        private System.Windows.Forms.Button btnEtut08;
        private System.Windows.Forms.TextBox txtEtutUcret;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Button btnEtutEkle;
        private System.Windows.Forms.DataGridView dataGridViewEtutEkleme;
        private System.Windows.Forms.Label label147;
        private System.Windows.Forms.ComboBox comboBoxEtutDers;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboBoxEtutOgretmen;
        private System.Windows.Forms.ComboBox comboBoxEtutOgrenci;
        private System.Windows.Forms.DataGridView dataGridViewEtutGoruntule;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton radioButtonEtutGoruntuleSilmeIslemi;
        private System.Windows.Forms.RadioButton radioButtonEtutGoruntuleAramaIslemi;
        private System.Windows.Forms.DateTimePicker dateTimePickerEtutGotunrule;
        private System.Windows.Forms.RadioButton radioButtonEtutGoruntuleTarih;
        private System.Windows.Forms.ComboBox comboBoxEtutGoruntuleDers;
        private System.Windows.Forms.ComboBox comboBoxEtutGoruntuleOgretmen;
        private System.Windows.Forms.RadioButton radioButtonEtutGoruntuleDers;
        private System.Windows.Forms.RadioButton radioButtonEtutGoruntuleOgretmen;
        private System.Windows.Forms.ComboBox comboBoxEtutGoruntuleOgrenci;
        private System.Windows.Forms.RadioButton radioButtonEtutGoruntuleOgrenci;
        private System.Windows.Forms.Button btnEtutGoruntuleAraSil;
        private System.Windows.Forms.Button btnAnaSayfaCikis;
        private System.Windows.Forms.LinkLabel linkLabelKayitOlGeri;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblBaslangic;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

