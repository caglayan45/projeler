﻿namespace SoruVeritabani
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSoru1 = new System.Windows.Forms.Button();
            this.radioButtonSoru1Hayir = new System.Windows.Forms.RadioButton();
            this.radioButtonSoru1Evet = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnSoru2Onceki = new System.Windows.Forms.Button();
            this.btnSoru2Sonraki = new System.Windows.Forms.Button();
            this.radioButtonSoru2Hayir = new System.Windows.Forms.RadioButton();
            this.radioButtonSoru2Evet = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnSoru3Onceki = new System.Windows.Forms.Button();
            this.btnSoru3Sonraki = new System.Windows.Forms.Button();
            this.radioButtonSoru3Hayir = new System.Windows.Forms.RadioButton();
            this.radioButtonSoru3Evet = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnSoru4Onceki = new System.Windows.Forms.Button();
            this.btnSoru4Sonraki = new System.Windows.Forms.Button();
            this.radioButtonSoru4Hayir = new System.Windows.Forms.RadioButton();
            this.radioButtonSoru4Evet = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnSoru5Onceki = new System.Windows.Forms.Button();
            this.btnSoru5Sonraki = new System.Windows.Forms.Button();
            this.radioButtonSoru5Hayir = new System.Windows.Forms.RadioButton();
            this.radioButtonSoru5Evet = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btnSoru6Onceki = new System.Windows.Forms.Button();
            this.btnSoru6Sonraki = new System.Windows.Forms.Button();
            this.radioButtonSoru6Hayir = new System.Windows.Forms.RadioButton();
            this.radioButtonSoru6Evet = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btnSoru7Onceki = new System.Windows.Forms.Button();
            this.btnSoru7Gonder = new System.Windows.Forms.Button();
            this.radioButtonSoru7Hayir = new System.Windows.Forms.RadioButton();
            this.radioButtonSoru7Evet = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.panelGiris = new System.Windows.Forms.Panel();
            this.btnBaslat = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.txtKullaniciAdi = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnBasaDon = new System.Windows.Forms.Button();
            this.panelSonuc = new System.Windows.Forms.Panel();
            this.btnBasaDonBirinci = new System.Windows.Forms.Button();
            this.btnDataGirdGoster = new System.Windows.Forms.Button();
            this.lblSonuc = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panelGiris.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panelSonuc.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.btnSoru1);
            this.panel1.Controls.Add(this.radioButtonSoru1Hayir);
            this.panel1.Controls.Add(this.radioButtonSoru1Evet);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(504, 134);
            this.panel1.TabIndex = 0;
            // 
            // btnSoru1
            // 
            this.btnSoru1.Location = new System.Drawing.Point(201, 104);
            this.btnSoru1.Name = "btnSoru1";
            this.btnSoru1.Size = new System.Drawing.Size(75, 23);
            this.btnSoru1.TabIndex = 3;
            this.btnSoru1.Text = "Sonraki";
            this.btnSoru1.UseVisualStyleBackColor = true;
            this.btnSoru1.Click += new System.EventHandler(this.btnSoru1_Click);
            // 
            // radioButtonSoru1Hayir
            // 
            this.radioButtonSoru1Hayir.AutoSize = true;
            this.radioButtonSoru1Hayir.Checked = true;
            this.radioButtonSoru1Hayir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonSoru1Hayir.Location = new System.Drawing.Point(252, 50);
            this.radioButtonSoru1Hayir.Name = "radioButtonSoru1Hayir";
            this.radioButtonSoru1Hayir.Size = new System.Drawing.Size(53, 19);
            this.radioButtonSoru1Hayir.TabIndex = 2;
            this.radioButtonSoru1Hayir.TabStop = true;
            this.radioButtonSoru1Hayir.Text = "Hayır";
            this.radioButtonSoru1Hayir.UseVisualStyleBackColor = true;
            // 
            // radioButtonSoru1Evet
            // 
            this.radioButtonSoru1Evet.AutoSize = true;
            this.radioButtonSoru1Evet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonSoru1Evet.Location = new System.Drawing.Point(178, 50);
            this.radioButtonSoru1Evet.Name = "radioButtonSoru1Evet";
            this.radioButtonSoru1Evet.Size = new System.Drawing.Size(48, 19);
            this.radioButtonSoru1Evet.TabIndex = 1;
            this.radioButtonSoru1Evet.Text = "Evet";
            this.radioButtonSoru1Evet.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(93, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(293, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Teknik destek hizmeti alıyor musunuz ?";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Controls.Add(this.btnSoru2Onceki);
            this.panel2.Controls.Add(this.btnSoru2Sonraki);
            this.panel2.Controls.Add(this.radioButtonSoru2Hayir);
            this.panel2.Controls.Add(this.radioButtonSoru2Evet);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(12, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(504, 134);
            this.panel2.TabIndex = 1;
            // 
            // btnSoru2Onceki
            // 
            this.btnSoru2Onceki.Location = new System.Drawing.Point(159, 104);
            this.btnSoru2Onceki.Name = "btnSoru2Onceki";
            this.btnSoru2Onceki.Size = new System.Drawing.Size(75, 23);
            this.btnSoru2Onceki.TabIndex = 4;
            this.btnSoru2Onceki.Text = "Önceki";
            this.btnSoru2Onceki.UseVisualStyleBackColor = true;
            this.btnSoru2Onceki.Click += new System.EventHandler(this.btnSoru2Onceki_Click);
            // 
            // btnSoru2Sonraki
            // 
            this.btnSoru2Sonraki.Location = new System.Drawing.Point(240, 104);
            this.btnSoru2Sonraki.Name = "btnSoru2Sonraki";
            this.btnSoru2Sonraki.Size = new System.Drawing.Size(75, 23);
            this.btnSoru2Sonraki.TabIndex = 3;
            this.btnSoru2Sonraki.Text = "Sonraki";
            this.btnSoru2Sonraki.UseVisualStyleBackColor = true;
            this.btnSoru2Sonraki.Click += new System.EventHandler(this.btnSoru2Sonraki_Click);
            // 
            // radioButtonSoru2Hayir
            // 
            this.radioButtonSoru2Hayir.AutoSize = true;
            this.radioButtonSoru2Hayir.Checked = true;
            this.radioButtonSoru2Hayir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonSoru2Hayir.Location = new System.Drawing.Point(252, 50);
            this.radioButtonSoru2Hayir.Name = "radioButtonSoru2Hayir";
            this.radioButtonSoru2Hayir.Size = new System.Drawing.Size(53, 19);
            this.radioButtonSoru2Hayir.TabIndex = 2;
            this.radioButtonSoru2Hayir.TabStop = true;
            this.radioButtonSoru2Hayir.Text = "Hayır";
            this.radioButtonSoru2Hayir.UseVisualStyleBackColor = true;
            // 
            // radioButtonSoru2Evet
            // 
            this.radioButtonSoru2Evet.AutoSize = true;
            this.radioButtonSoru2Evet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonSoru2Evet.Location = new System.Drawing.Point(178, 50);
            this.radioButtonSoru2Evet.Name = "radioButtonSoru2Evet";
            this.radioButtonSoru2Evet.Size = new System.Drawing.Size(48, 19);
            this.radioButtonSoru2Evet.TabIndex = 1;
            this.radioButtonSoru2Evet.Text = "Evet";
            this.radioButtonSoru2Evet.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(93, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(304, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "Online güvenlik hizmeti alıyor musunuz ?";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel3.Controls.Add(this.btnSoru3Onceki);
            this.panel3.Controls.Add(this.btnSoru3Sonraki);
            this.panel3.Controls.Add(this.radioButtonSoru3Hayir);
            this.panel3.Controls.Add(this.radioButtonSoru3Evet);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Location = new System.Drawing.Point(12, 12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(504, 134);
            this.panel3.TabIndex = 2;
            // 
            // btnSoru3Onceki
            // 
            this.btnSoru3Onceki.Location = new System.Drawing.Point(159, 104);
            this.btnSoru3Onceki.Name = "btnSoru3Onceki";
            this.btnSoru3Onceki.Size = new System.Drawing.Size(75, 23);
            this.btnSoru3Onceki.TabIndex = 4;
            this.btnSoru3Onceki.Text = "Önceki";
            this.btnSoru3Onceki.UseVisualStyleBackColor = true;
            this.btnSoru3Onceki.Click += new System.EventHandler(this.btnSoru3Onceki_Click);
            // 
            // btnSoru3Sonraki
            // 
            this.btnSoru3Sonraki.Location = new System.Drawing.Point(240, 104);
            this.btnSoru3Sonraki.Name = "btnSoru3Sonraki";
            this.btnSoru3Sonraki.Size = new System.Drawing.Size(75, 23);
            this.btnSoru3Sonraki.TabIndex = 3;
            this.btnSoru3Sonraki.Text = "Sonraki";
            this.btnSoru3Sonraki.UseVisualStyleBackColor = true;
            this.btnSoru3Sonraki.Click += new System.EventHandler(this.btnSoru3Sonraki_Click);
            // 
            // radioButtonSoru3Hayir
            // 
            this.radioButtonSoru3Hayir.AutoSize = true;
            this.radioButtonSoru3Hayir.Checked = true;
            this.radioButtonSoru3Hayir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonSoru3Hayir.Location = new System.Drawing.Point(252, 50);
            this.radioButtonSoru3Hayir.Name = "radioButtonSoru3Hayir";
            this.radioButtonSoru3Hayir.Size = new System.Drawing.Size(53, 19);
            this.radioButtonSoru3Hayir.TabIndex = 2;
            this.radioButtonSoru3Hayir.TabStop = true;
            this.radioButtonSoru3Hayir.Text = "Hayır";
            this.radioButtonSoru3Hayir.UseVisualStyleBackColor = true;
            // 
            // radioButtonSoru3Evet
            // 
            this.radioButtonSoru3Evet.AutoSize = true;
            this.radioButtonSoru3Evet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonSoru3Evet.Location = new System.Drawing.Point(178, 50);
            this.radioButtonSoru3Evet.Name = "radioButtonSoru3Evet";
            this.radioButtonSoru3Evet.Size = new System.Drawing.Size(48, 19);
            this.radioButtonSoru3Evet.TabIndex = 1;
            this.radioButtonSoru3Evet.Text = "Evet";
            this.radioButtonSoru3Evet.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(134, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(221, 17);
            this.label3.TabIndex = 0;
            this.label3.Text = "Film hizmeti alıyor musunuz ?";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel4.Controls.Add(this.btnSoru4Onceki);
            this.panel4.Controls.Add(this.btnSoru4Sonraki);
            this.panel4.Controls.Add(this.radioButtonSoru4Hayir);
            this.panel4.Controls.Add(this.radioButtonSoru4Evet);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Location = new System.Drawing.Point(12, 12);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(504, 134);
            this.panel4.TabIndex = 3;
            // 
            // btnSoru4Onceki
            // 
            this.btnSoru4Onceki.Location = new System.Drawing.Point(159, 104);
            this.btnSoru4Onceki.Name = "btnSoru4Onceki";
            this.btnSoru4Onceki.Size = new System.Drawing.Size(75, 23);
            this.btnSoru4Onceki.TabIndex = 4;
            this.btnSoru4Onceki.Text = "Önceki";
            this.btnSoru4Onceki.UseVisualStyleBackColor = true;
            this.btnSoru4Onceki.Click += new System.EventHandler(this.btnSoru4Onceki_Click);
            // 
            // btnSoru4Sonraki
            // 
            this.btnSoru4Sonraki.Location = new System.Drawing.Point(240, 104);
            this.btnSoru4Sonraki.Name = "btnSoru4Sonraki";
            this.btnSoru4Sonraki.Size = new System.Drawing.Size(75, 23);
            this.btnSoru4Sonraki.TabIndex = 3;
            this.btnSoru4Sonraki.Text = "Sonraki";
            this.btnSoru4Sonraki.UseVisualStyleBackColor = true;
            this.btnSoru4Sonraki.Click += new System.EventHandler(this.btnSoru4Sonraki_Click);
            // 
            // radioButtonSoru4Hayir
            // 
            this.radioButtonSoru4Hayir.AutoSize = true;
            this.radioButtonSoru4Hayir.Checked = true;
            this.radioButtonSoru4Hayir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonSoru4Hayir.Location = new System.Drawing.Point(252, 50);
            this.radioButtonSoru4Hayir.Name = "radioButtonSoru4Hayir";
            this.radioButtonSoru4Hayir.Size = new System.Drawing.Size(53, 19);
            this.radioButtonSoru4Hayir.TabIndex = 2;
            this.radioButtonSoru4Hayir.TabStop = true;
            this.radioButtonSoru4Hayir.Text = "Hayır";
            this.radioButtonSoru4Hayir.UseVisualStyleBackColor = true;
            // 
            // radioButtonSoru4Evet
            // 
            this.radioButtonSoru4Evet.AutoSize = true;
            this.radioButtonSoru4Evet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonSoru4Evet.Location = new System.Drawing.Point(178, 50);
            this.radioButtonSoru4Evet.Name = "radioButtonSoru4Evet";
            this.radioButtonSoru4Evet.Size = new System.Drawing.Size(48, 19);
            this.radioButtonSoru4Evet.TabIndex = 1;
            this.radioButtonSoru4Evet.Text = "Evet";
            this.radioButtonSoru4Evet.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(116, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(247, 17);
            this.label4.TabIndex = 0;
            this.label4.Text = "Telefon hizmeti alıyor musunuz ?";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel5.Controls.Add(this.btnSoru5Onceki);
            this.panel5.Controls.Add(this.btnSoru5Sonraki);
            this.panel5.Controls.Add(this.radioButtonSoru5Hayir);
            this.panel5.Controls.Add(this.radioButtonSoru5Evet);
            this.panel5.Controls.Add(this.label5);
            this.panel5.Location = new System.Drawing.Point(12, 12);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(504, 134);
            this.panel5.TabIndex = 4;
            // 
            // btnSoru5Onceki
            // 
            this.btnSoru5Onceki.Location = new System.Drawing.Point(159, 104);
            this.btnSoru5Onceki.Name = "btnSoru5Onceki";
            this.btnSoru5Onceki.Size = new System.Drawing.Size(75, 23);
            this.btnSoru5Onceki.TabIndex = 8;
            this.btnSoru5Onceki.Text = "Önceki";
            this.btnSoru5Onceki.UseVisualStyleBackColor = true;
            this.btnSoru5Onceki.Click += new System.EventHandler(this.btnSoru5Onceki_Click);
            // 
            // btnSoru5Sonraki
            // 
            this.btnSoru5Sonraki.Location = new System.Drawing.Point(240, 104);
            this.btnSoru5Sonraki.Name = "btnSoru5Sonraki";
            this.btnSoru5Sonraki.Size = new System.Drawing.Size(75, 23);
            this.btnSoru5Sonraki.TabIndex = 7;
            this.btnSoru5Sonraki.Text = "Sonraki";
            this.btnSoru5Sonraki.UseVisualStyleBackColor = true;
            this.btnSoru5Sonraki.Click += new System.EventHandler(this.btnSoru5Sonraki_Click);
            // 
            // radioButtonSoru5Hayir
            // 
            this.radioButtonSoru5Hayir.AutoSize = true;
            this.radioButtonSoru5Hayir.Checked = true;
            this.radioButtonSoru5Hayir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonSoru5Hayir.Location = new System.Drawing.Point(252, 50);
            this.radioButtonSoru5Hayir.Name = "radioButtonSoru5Hayir";
            this.radioButtonSoru5Hayir.Size = new System.Drawing.Size(53, 19);
            this.radioButtonSoru5Hayir.TabIndex = 2;
            this.radioButtonSoru5Hayir.TabStop = true;
            this.radioButtonSoru5Hayir.Text = "Hayır";
            this.radioButtonSoru5Hayir.UseVisualStyleBackColor = true;
            // 
            // radioButtonSoru5Evet
            // 
            this.radioButtonSoru5Evet.AutoSize = true;
            this.radioButtonSoru5Evet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonSoru5Evet.Location = new System.Drawing.Point(178, 50);
            this.radioButtonSoru5Evet.Name = "radioButtonSoru5Evet";
            this.radioButtonSoru5Evet.Size = new System.Drawing.Size(48, 19);
            this.radioButtonSoru5Evet.TabIndex = 1;
            this.radioButtonSoru5Evet.Text = "Evet";
            this.radioButtonSoru5Evet.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(93, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(321, 17);
            this.label5.TabIndex = 0;
            this.label5.Text = "Online yedekleme hizmeti alıyor musunuz ?";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel6.Controls.Add(this.btnSoru6Onceki);
            this.panel6.Controls.Add(this.btnSoru6Sonraki);
            this.panel6.Controls.Add(this.radioButtonSoru6Hayir);
            this.panel6.Controls.Add(this.radioButtonSoru6Evet);
            this.panel6.Controls.Add(this.label6);
            this.panel6.Location = new System.Drawing.Point(12, 12);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(504, 134);
            this.panel6.TabIndex = 5;
            // 
            // btnSoru6Onceki
            // 
            this.btnSoru6Onceki.Location = new System.Drawing.Point(159, 104);
            this.btnSoru6Onceki.Name = "btnSoru6Onceki";
            this.btnSoru6Onceki.Size = new System.Drawing.Size(75, 23);
            this.btnSoru6Onceki.TabIndex = 6;
            this.btnSoru6Onceki.Text = "Önceki";
            this.btnSoru6Onceki.UseVisualStyleBackColor = true;
            this.btnSoru6Onceki.Click += new System.EventHandler(this.btnSoru6Onceki_Click);
            // 
            // btnSoru6Sonraki
            // 
            this.btnSoru6Sonraki.Location = new System.Drawing.Point(240, 104);
            this.btnSoru6Sonraki.Name = "btnSoru6Sonraki";
            this.btnSoru6Sonraki.Size = new System.Drawing.Size(75, 23);
            this.btnSoru6Sonraki.TabIndex = 5;
            this.btnSoru6Sonraki.Text = "Sonraki";
            this.btnSoru6Sonraki.UseVisualStyleBackColor = true;
            this.btnSoru6Sonraki.Click += new System.EventHandler(this.btnSoru6Sonraki_Click);
            // 
            // radioButtonSoru6Hayir
            // 
            this.radioButtonSoru6Hayir.AutoSize = true;
            this.radioButtonSoru6Hayir.Checked = true;
            this.radioButtonSoru6Hayir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonSoru6Hayir.Location = new System.Drawing.Point(252, 50);
            this.radioButtonSoru6Hayir.Name = "radioButtonSoru6Hayir";
            this.radioButtonSoru6Hayir.Size = new System.Drawing.Size(53, 19);
            this.radioButtonSoru6Hayir.TabIndex = 2;
            this.radioButtonSoru6Hayir.TabStop = true;
            this.radioButtonSoru6Hayir.Text = "Hayır";
            this.radioButtonSoru6Hayir.UseVisualStyleBackColor = true;
            // 
            // radioButtonSoru6Evet
            // 
            this.radioButtonSoru6Evet.AutoSize = true;
            this.radioButtonSoru6Evet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonSoru6Evet.Location = new System.Drawing.Point(178, 50);
            this.radioButtonSoru6Evet.Name = "radioButtonSoru6Evet";
            this.radioButtonSoru6Evet.Size = new System.Drawing.Size(48, 19);
            this.radioButtonSoru6Evet.TabIndex = 1;
            this.radioButtonSoru6Evet.Text = "Evet";
            this.radioButtonSoru6Evet.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(109, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(270, 17);
            this.label6.TabIndex = 0;
            this.label6.Text = "Televizyon hizmeti alıyor musunuz ?";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel7.Controls.Add(this.btnSoru7Onceki);
            this.panel7.Controls.Add(this.btnSoru7Gonder);
            this.panel7.Controls.Add(this.radioButtonSoru7Hayir);
            this.panel7.Controls.Add(this.radioButtonSoru7Evet);
            this.panel7.Controls.Add(this.label7);
            this.panel7.Location = new System.Drawing.Point(12, 12);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(504, 134);
            this.panel7.TabIndex = 6;
            // 
            // btnSoru7Onceki
            // 
            this.btnSoru7Onceki.Location = new System.Drawing.Point(159, 104);
            this.btnSoru7Onceki.Name = "btnSoru7Onceki";
            this.btnSoru7Onceki.Size = new System.Drawing.Size(75, 23);
            this.btnSoru7Onceki.TabIndex = 4;
            this.btnSoru7Onceki.Text = "Önceki";
            this.btnSoru7Onceki.UseVisualStyleBackColor = true;
            this.btnSoru7Onceki.Click += new System.EventHandler(this.btnSoru7Onceki_Click);
            // 
            // btnSoru7Gonder
            // 
            this.btnSoru7Gonder.Location = new System.Drawing.Point(240, 104);
            this.btnSoru7Gonder.Name = "btnSoru7Gonder";
            this.btnSoru7Gonder.Size = new System.Drawing.Size(75, 23);
            this.btnSoru7Gonder.TabIndex = 3;
            this.btnSoru7Gonder.Text = "Gönder";
            this.btnSoru7Gonder.UseVisualStyleBackColor = true;
            this.btnSoru7Gonder.Click += new System.EventHandler(this.btnSoru7Gonder_Click);
            // 
            // radioButtonSoru7Hayir
            // 
            this.radioButtonSoru7Hayir.AutoSize = true;
            this.radioButtonSoru7Hayir.Checked = true;
            this.radioButtonSoru7Hayir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonSoru7Hayir.Location = new System.Drawing.Point(252, 50);
            this.radioButtonSoru7Hayir.Name = "radioButtonSoru7Hayir";
            this.radioButtonSoru7Hayir.Size = new System.Drawing.Size(53, 19);
            this.radioButtonSoru7Hayir.TabIndex = 2;
            this.radioButtonSoru7Hayir.TabStop = true;
            this.radioButtonSoru7Hayir.Text = "Hayır";
            this.radioButtonSoru7Hayir.UseVisualStyleBackColor = true;
            // 
            // radioButtonSoru7Evet
            // 
            this.radioButtonSoru7Evet.AutoSize = true;
            this.radioButtonSoru7Evet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonSoru7Evet.Location = new System.Drawing.Point(178, 50);
            this.radioButtonSoru7Evet.Name = "radioButtonSoru7Evet";
            this.radioButtonSoru7Evet.Size = new System.Drawing.Size(48, 19);
            this.radioButtonSoru7Evet.TabIndex = 1;
            this.radioButtonSoru7Evet.Text = "Evet";
            this.radioButtonSoru7Evet.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(93, 20);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(290, 17);
            this.label7.TabIndex = 0;
            this.label7.Text = "Cihaz koruma hizmeti alıyor musunuz ?";
            // 
            // panelGiris
            // 
            this.panelGiris.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panelGiris.Controls.Add(this.btnBaslat);
            this.panelGiris.Controls.Add(this.label8);
            this.panelGiris.Controls.Add(this.txtKullaniciAdi);
            this.panelGiris.Location = new System.Drawing.Point(12, 12);
            this.panelGiris.Name = "panelGiris";
            this.panelGiris.Size = new System.Drawing.Size(504, 134);
            this.panelGiris.TabIndex = 7;
            // 
            // btnBaslat
            // 
            this.btnBaslat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnBaslat.Location = new System.Drawing.Point(225, 70);
            this.btnBaslat.Name = "btnBaslat";
            this.btnBaslat.Size = new System.Drawing.Size(138, 23);
            this.btnBaslat.TabIndex = 2;
            this.btnBaslat.Text = "BAŞLA";
            this.btnBaslat.UseVisualStyleBackColor = true;
            this.btnBaslat.Click += new System.EventHandler(this.btnBaslat_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(120, 45);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(99, 15);
            this.label8.TabIndex = 1;
            this.label8.Text = "Kullanıcı Adı : ";
            // 
            // txtKullaniciAdi
            // 
            this.txtKullaniciAdi.Location = new System.Drawing.Point(225, 44);
            this.txtKullaniciAdi.Name = "txtKullaniciAdi";
            this.txtKullaniciAdi.Size = new System.Drawing.Size(138, 20);
            this.txtKullaniciAdi.TabIndex = 0;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(504, 453);
            this.dataGridView1.TabIndex = 8;
            this.dataGridView1.Visible = false;
            // 
            // btnBasaDon
            // 
            this.btnBasaDon.Location = new System.Drawing.Point(441, 471);
            this.btnBasaDon.Name = "btnBasaDon";
            this.btnBasaDon.Size = new System.Drawing.Size(75, 23);
            this.btnBasaDon.TabIndex = 9;
            this.btnBasaDon.Text = "Başa Dön";
            this.btnBasaDon.UseVisualStyleBackColor = true;
            this.btnBasaDon.Click += new System.EventHandler(this.btnBasaDon_Click);
            // 
            // panelSonuc
            // 
            this.panelSonuc.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panelSonuc.Controls.Add(this.btnBasaDonBirinci);
            this.panelSonuc.Controls.Add(this.btnDataGirdGoster);
            this.panelSonuc.Controls.Add(this.lblSonuc);
            this.panelSonuc.Location = new System.Drawing.Point(12, 12);
            this.panelSonuc.Name = "panelSonuc";
            this.panelSonuc.Size = new System.Drawing.Size(504, 134);
            this.panelSonuc.TabIndex = 10;
            // 
            // btnBasaDonBirinci
            // 
            this.btnBasaDonBirinci.Location = new System.Drawing.Point(144, 100);
            this.btnBasaDonBirinci.Name = "btnBasaDonBirinci";
            this.btnBasaDonBirinci.Size = new System.Drawing.Size(193, 23);
            this.btnBasaDonBirinci.TabIndex = 4;
            this.btnBasaDonBirinci.Text = "Başa dönmek için tıklayın";
            this.btnBasaDonBirinci.UseVisualStyleBackColor = true;
            this.btnBasaDonBirinci.Click += new System.EventHandler(this.btnBasaDonBirinci_Click);
            // 
            // btnDataGirdGoster
            // 
            this.btnDataGirdGoster.Location = new System.Drawing.Point(144, 71);
            this.btnDataGirdGoster.Name = "btnDataGirdGoster";
            this.btnDataGirdGoster.Size = new System.Drawing.Size(193, 23);
            this.btnDataGirdGoster.TabIndex = 3;
            this.btnDataGirdGoster.Text = "Verileri görüntülemek için tıklayın";
            this.btnDataGirdGoster.UseVisualStyleBackColor = true;
            this.btnDataGirdGoster.Click += new System.EventHandler(this.btnDataGirdGoster_Click);
            // 
            // lblSonuc
            // 
            this.lblSonuc.AutoSize = true;
            this.lblSonuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSonuc.Location = new System.Drawing.Point(137, 20);
            this.lblSonuc.Name = "lblSonuc";
            this.lblSonuc.Size = new System.Drawing.Size(0, 17);
            this.lblSonuc.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(528, 499);
            this.Controls.Add(this.panelSonuc);
            this.Controls.Add(this.btnBasaDon);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelGiris);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Müşteri Analiz Programı";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panelGiris.ResumeLayout(false);
            this.panelGiris.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panelSonuc.ResumeLayout(false);
            this.panelSonuc.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnSoru1;
        private System.Windows.Forms.RadioButton radioButtonSoru1Hayir;
        private System.Windows.Forms.RadioButton radioButtonSoru1Evet;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnSoru2Sonraki;
        private System.Windows.Forms.RadioButton radioButtonSoru2Hayir;
        private System.Windows.Forms.RadioButton radioButtonSoru2Evet;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnSoru3Sonraki;
        private System.Windows.Forms.RadioButton radioButtonSoru3Hayir;
        private System.Windows.Forms.RadioButton radioButtonSoru3Evet;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnSoru4Sonraki;
        private System.Windows.Forms.RadioButton radioButtonSoru4Hayir;
        private System.Windows.Forms.RadioButton radioButtonSoru4Evet;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.RadioButton radioButtonSoru5Hayir;
        private System.Windows.Forms.RadioButton radioButtonSoru5Evet;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.RadioButton radioButtonSoru6Hayir;
        private System.Windows.Forms.RadioButton radioButtonSoru6Evet;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button btnSoru7Gonder;
        private System.Windows.Forms.RadioButton radioButtonSoru7Hayir;
        private System.Windows.Forms.RadioButton radioButtonSoru7Evet;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnSoru7Onceki;
        private System.Windows.Forms.Button btnSoru5Onceki;
        private System.Windows.Forms.Button btnSoru5Sonraki;
        private System.Windows.Forms.Button btnSoru6Onceki;
        private System.Windows.Forms.Button btnSoru6Sonraki;
        private System.Windows.Forms.Button btnSoru4Onceki;
        private System.Windows.Forms.Button btnSoru3Onceki;
        private System.Windows.Forms.Button btnSoru2Onceki;
        private System.Windows.Forms.Panel panelGiris;
        private System.Windows.Forms.Button btnBaslat;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtKullaniciAdi;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnBasaDon;
        private System.Windows.Forms.Panel panelSonuc;
        private System.Windows.Forms.Button btnDataGirdGoster;
        private System.Windows.Forms.Label lblSonuc;
        private System.Windows.Forms.Button btnBasaDonBirinci;
    }
}

