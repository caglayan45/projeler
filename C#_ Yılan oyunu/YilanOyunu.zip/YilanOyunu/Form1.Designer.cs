﻿namespace YilanOyunu
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblPuan = new System.Windows.Forms.Label();
            this.lblGecenSure = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panelOyun = new System.Windows.Forms.Panel();
            this.radioButtonZor = new System.Windows.Forms.RadioButton();
            this.panelBilgi = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.radioButtonKolay = new System.Windows.Forms.RadioButton();
            this.btnYardim = new System.Windows.Forms.Button();
            this.txtKisi = new System.Windows.Forms.TextBox();
            this.btnKaydet = new System.Windows.Forms.Button();
            this.btnSkorGoruntule = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timerGecenSure = new System.Windows.Forms.Timer(this.components);
            this.panelBilgiGenel = new System.Windows.Forms.Panel();
            this.timerYemSuresi = new System.Windows.Forms.Timer(this.components);
            this.timerOyunZorlugu = new System.Windows.Forms.Timer(this.components);
            this.panelBilgi.SuspendLayout();
            this.panelBilgiGenel.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblPuan
            // 
            this.lblPuan.AutoSize = true;
            this.lblPuan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblPuan.Location = new System.Drawing.Point(48, 39);
            this.lblPuan.Name = "lblPuan";
            this.lblPuan.Size = new System.Drawing.Size(61, 17);
            this.lblPuan.TabIndex = 32;
            this.lblPuan.Text = "Puan : 0";
            // 
            // lblGecenSure
            // 
            this.lblGecenSure.AutoSize = true;
            this.lblGecenSure.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblGecenSure.Location = new System.Drawing.Point(611, 39);
            this.lblGecenSure.Name = "lblGecenSure";
            this.lblGecenSure.Size = new System.Drawing.Size(132, 17);
            this.lblGecenSure.TabIndex = 1;
            this.lblGecenSure.Text = "Geçen Süre : 00:00";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(251, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(237, 44);
            this.label1.TabIndex = 2;
            this.label1.Text = "Yılan Oyunu";
            // 
            // panelOyun
            // 
            this.panelOyun.Location = new System.Drawing.Point(54, 72);
            this.panelOyun.Name = "panelOyun";
            this.panelOyun.Size = new System.Drawing.Size(680, 480);
            this.panelOyun.TabIndex = 0;
            // 
            // radioButtonZor
            // 
            this.radioButtonZor.AutoSize = true;
            this.radioButtonZor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonZor.Location = new System.Drawing.Point(351, 437);
            this.radioButtonZor.Name = "radioButtonZor";
            this.radioButtonZor.Size = new System.Drawing.Size(94, 21);
            this.radioButtonZor.TabIndex = 5;
            this.radioButtonZor.Text = "Zor Seviye";
            this.radioButtonZor.UseVisualStyleBackColor = true;
            // 
            // panelBilgi
            // 
            this.panelBilgi.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panelBilgi.Controls.Add(this.label5);
            this.panelBilgi.Controls.Add(this.label4);
            this.panelBilgi.Controls.Add(this.label3);
            this.panelBilgi.Controls.Add(this.label2);
            this.panelBilgi.Location = new System.Drawing.Point(138, 23);
            this.panelBilgi.Name = "panelBilgi";
            this.panelBilgi.Size = new System.Drawing.Size(425, 344);
            this.panelBilgi.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(134, 302);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(161, 29);
            this.label5.TabIndex = 3;
            this.label5.Text = "BAŞARILAR...";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(154, 200);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(116, 29);
            this.label4.TabIndex = 2;
            this.label4.Text = "Kullanınız";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(22, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(370, 29);
            this.label3.TabIndex = 1;
            this.label3.Text = "Oyunu Başlatmak için  [B Tuşunu]";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(20, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(378, 29);
            this.label2.TabIndex = 0;
            this.label2.Text = "Oyunu Durdurmak için  [D Tuşunu]";
            // 
            // radioButtonKolay
            // 
            this.radioButtonKolay.AutoSize = true;
            this.radioButtonKolay.Checked = true;
            this.radioButtonKolay.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioButtonKolay.Location = new System.Drawing.Point(228, 437);
            this.radioButtonKolay.Name = "radioButtonKolay";
            this.radioButtonKolay.Size = new System.Drawing.Size(107, 21);
            this.radioButtonKolay.TabIndex = 0;
            this.radioButtonKolay.TabStop = true;
            this.radioButtonKolay.Text = "Kolay Seviye";
            this.radioButtonKolay.UseVisualStyleBackColor = true;
            this.radioButtonKolay.CheckedChanged += new System.EventHandler(this.radioButtonKolay_CheckedChanged);
            // 
            // btnYardim
            // 
            this.btnYardim.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnYardim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnYardim.Location = new System.Drawing.Point(1, 558);
            this.btnYardim.Name = "btnYardim";
            this.btnYardim.Size = new System.Drawing.Size(100, 51);
            this.btnYardim.TabIndex = 4;
            this.btnYardim.Text = "Yardım";
            this.btnYardim.UseVisualStyleBackColor = false;
            this.btnYardim.Click += new System.EventHandler(this.btnYardim_Click);
            // 
            // txtKisi
            // 
            this.txtKisi.Location = new System.Drawing.Point(197, 572);
            this.txtKisi.Name = "txtKisi";
            this.txtKisi.Size = new System.Drawing.Size(179, 20);
            this.txtKisi.TabIndex = 5;
            // 
            // btnKaydet
            // 
            this.btnKaydet.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKaydet.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKaydet.Location = new System.Drawing.Point(382, 562);
            this.btnKaydet.Name = "btnKaydet";
            this.btnKaydet.Size = new System.Drawing.Size(161, 39);
            this.btnKaydet.TabIndex = 6;
            this.btnKaydet.Text = "Kişiyi Kaydet";
            this.btnKaydet.UseVisualStyleBackColor = false;
            this.btnKaydet.Click += new System.EventHandler(this.btnKaydet_Click);
            // 
            // btnSkorGoruntule
            // 
            this.btnSkorGoruntule.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnSkorGoruntule.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSkorGoruntule.Location = new System.Drawing.Point(639, 560);
            this.btnSkorGoruntule.Name = "btnSkorGoruntule";
            this.btnSkorGoruntule.Size = new System.Drawing.Size(148, 51);
            this.btnSkorGoruntule.TabIndex = 7;
            this.btnSkorGoruntule.Text = "Skorları Görüntüle";
            this.btnSkorGoruntule.UseVisualStyleBackColor = false;
            this.btnSkorGoruntule.Click += new System.EventHandler(this.btnSkorGoruntule_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timerGecenSure
            // 
            this.timerGecenSure.Interval = 1000;
            this.timerGecenSure.Tick += new System.EventHandler(this.timerGecenSure_Tick);
            // 
            // panelBilgiGenel
            // 
            this.panelBilgiGenel.Controls.Add(this.radioButtonZor);
            this.panelBilgiGenel.Controls.Add(this.panelBilgi);
            this.panelBilgiGenel.Controls.Add(this.radioButtonKolay);
            this.panelBilgiGenel.Location = new System.Drawing.Point(40, 72);
            this.panelBilgiGenel.Name = "panelBilgiGenel";
            this.panelBilgiGenel.Size = new System.Drawing.Size(710, 482);
            this.panelBilgiGenel.TabIndex = 8;
            // 
            // timerYemSuresi
            // 
            this.timerYemSuresi.Interval = 1000;
            this.timerYemSuresi.Tick += new System.EventHandler(this.timerYemSuresi_Tick);
            // 
            // timerOyunZorlugu
            // 
            this.timerOyunZorlugu.Tick += new System.EventHandler(this.timerOyunZorlugu_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.ClientSize = new System.Drawing.Size(788, 609);
            this.Controls.Add(this.btnSkorGoruntule);
            this.Controls.Add(this.btnKaydet);
            this.Controls.Add(this.txtKisi);
            this.Controls.Add(this.btnYardim);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblGecenSure);
            this.Controls.Add(this.lblPuan);
            this.Controls.Add(this.panelBilgiGenel);
            this.Controls.Add(this.panelOyun);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(808, 652);
            this.MinimumSize = new System.Drawing.Size(808, 652);
            this.Name = "Form1";
            this.Text = "Yılan Oyunu";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            this.panelBilgi.ResumeLayout(false);
            this.panelBilgi.PerformLayout();
            this.panelBilgiGenel.ResumeLayout(false);
            this.panelBilgiGenel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPuan;
        private System.Windows.Forms.Label lblGecenSure;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelOyun;
        private System.Windows.Forms.Panel panelBilgi;
        private System.Windows.Forms.RadioButton radioButtonZor;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton radioButtonKolay;
        private System.Windows.Forms.Button btnYardim;
        private System.Windows.Forms.TextBox txtKisi;
        private System.Windows.Forms.Button btnKaydet;
        private System.Windows.Forms.Button btnSkorGoruntule;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timerGecenSure;
        private System.Windows.Forms.Panel panelBilgiGenel;
        private System.Windows.Forms.Timer timerYemSuresi;
        private System.Windows.Forms.Timer timerOyunZorlugu;
    }
}

