﻿namespace alisverisUygulamasi
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button btnKullaniciCikis;
            this.tabControlKullaniciGirisi = new System.Windows.Forms.TabControl();
            this.tabPageUrunler = new System.Windows.Forms.TabPage();
            this.label74 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.comboBoxKullaniciUrunlerKargo = new System.Windows.Forms.ComboBox();
            this.label76 = new System.Windows.Forms.Label();
            this.labelUrunId = new System.Windows.Forms.Label();
            this.comboBoxKullaniciUrunlerAdres = new System.Windows.Forms.ComboBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.btnKullaniciUrunSatinAl = new System.Windows.Forms.Button();
            this.labelSiparisMiktari = new System.Windows.Forms.Label();
            this.labelStokDurumu = new System.Windows.Forms.Label();
            this.labelUrunFiyati = new System.Windows.Forms.Label();
            this.labelUrunAdi = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.dataGridViewKullaniciUrunler = new System.Windows.Forms.DataGridView();
            this.tabPageSiparislerim = new System.Windows.Forms.TabPage();
            this.dataGridViewKullaniciSiparislerim = new System.Windows.Forms.DataGridView();
            this.tabPageAdreslerim = new System.Windows.Forms.TabPage();
            this.txtKullaniciAdresSilAdresNo = new System.Windows.Forms.TextBox();
            this.label83 = new System.Windows.Forms.Label();
            this.txtKullaniciAdresSilKulNo = new System.Windows.Forms.TextBox();
            this.label84 = new System.Windows.Forms.Label();
            this.btnKullaniciAdresSil = new System.Windows.Forms.Button();
            this.btnKullaniciAdresEkle = new System.Windows.Forms.Button();
            this.txtKullaniciAdresEkleAdres = new System.Windows.Forms.TextBox();
            this.label82 = new System.Windows.Forms.Label();
            this.txtKullaniciAdresEkleIlceNo = new System.Windows.Forms.TextBox();
            this.label81 = new System.Windows.Forms.Label();
            this.txtKullaniciAdresEklePlakaNo = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.txtKullaniciAdresEkleAdresNo = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.dataGridViewKullaniciAdreslerim = new System.Windows.Forms.DataGridView();
            this.tabPageKullaniciAyarlar = new System.Windows.Forms.TabPage();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.txtKullaniciSifreDegistirTekrar = new System.Windows.Forms.TextBox();
            this.txtKullaniciSifreDegistirYeni = new System.Windows.Forms.TextBox();
            this.txtKullaniciSifreDegistirMevcut = new System.Windows.Forms.TextBox();
            this.btnKullaniciSifreDegistir = new System.Windows.Forms.Button();
            this.PanelKullaniciGirisi = new System.Windows.Forms.Panel();
            this.linkLabelKullaniciGirisiToYoneticiGirisi = new System.Windows.Forms.LinkLabel();
            this.label47 = new System.Windows.Forms.Label();
            this.linkKayitOl = new System.Windows.Forms.LinkLabel();
            this.linkSifremiUnuttum = new System.Windows.Forms.LinkLabel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtGirisSifre = new System.Windows.Forms.TextBox();
            this.txtGirisKullaniciAdi = new System.Windows.Forms.TextBox();
            this.btnUyeGiris = new System.Windows.Forms.Button();
            this.sifremiUnuttumPanel = new System.Windows.Forms.Panel();
            this.label45 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtSifreDegistirKullaniciAdi = new System.Windows.Forms.TextBox();
            this.linkLabelSifreDegistirIptal = new System.Windows.Forms.LinkLabel();
            this.label6 = new System.Windows.Forms.Label();
            this.txtSifreDegistirYeniSifreTekrar = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtSifreDegistirYeniSifre = new System.Windows.Forms.TextBox();
            this.comboBoxSifreDegistirGuvenlikSorusu = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtSifreDegistirGuvenlikSorusuCevabi = new System.Windows.Forms.TextBox();
            this.btnSifreDegistir = new System.Windows.Forms.Button();
            this.panelKayitOl = new System.Windows.Forms.Panel();
            this.label46 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtKayitOlGuvenlikCevap = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.comboBoxKayitOlGuvenlikSorusu = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.kayitOlRadioButtonErkek = new System.Windows.Forms.RadioButton();
            this.kayitOlRadioButtonKadin = new System.Windows.Forms.RadioButton();
            this.label13 = new System.Windows.Forms.Label();
            this.kayitOlDogumTarihi = new System.Windows.Forms.DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.txtKayitOlTelefon = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtKayitOlSifreTekrar = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtKayitOlSoyisim = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtKayitOlisim = new System.Windows.Forms.TextBox();
            this.linkLabelKayitOlIptal = new System.Windows.Forms.LinkLabel();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtKayitOlSifre = new System.Windows.Forms.TextBox();
            this.txtKayitOlKullaniciAdi = new System.Windows.Forms.TextBox();
            this.btnKayitOl = new System.Windows.Forms.Button();
            this.tabControlYoneticiGirisi = new System.Windows.Forms.TabControl();
            this.tabPageYoneticiKullanicilarVeSiparisler = new System.Windows.Forms.TabPage();
            this.dataGridViewYoneticiSiparisler = new System.Windows.Forms.DataGridView();
            this.btnYoneticiKullaniciSil = new System.Windows.Forms.Button();
            this.txtYoneticiSilinecekKullanici = new System.Windows.Forms.TextBox();
            this.dataGridViewYoneticiKullanicilar = new System.Windows.Forms.DataGridView();
            this.tabPageYoneticiUrunler = new System.Windows.Forms.TabPage();
            this.btnYoneticiUrunSil = new System.Windows.Forms.Button();
            this.btnYoneticiUrunEkle = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.txtYoneticiUrunEkleTedarikciId = new System.Windows.Forms.TextBox();
            this.txtYoneticiUrunEkleSiparisAdedi = new System.Windows.Forms.TextBox();
            this.txtYoneticiUrunEkleStokAdedi = new System.Windows.Forms.TextBox();
            this.txtYoneticiUrunEkleBirimFiyati = new System.Windows.Forms.TextBox();
            this.txtYoneticiUrunEkleKategoriId = new System.Windows.Forms.TextBox();
            this.txtYoneticiUrunEkleAdi = new System.Windows.Forms.TextBox();
            this.txtYoneticiUrunEkleId = new System.Windows.Forms.TextBox();
            this.listBoxYoneticiTedarikciler = new System.Windows.Forms.ListBox();
            this.listBoxYoneticiKategoriler = new System.Windows.Forms.ListBox();
            this.labelUrunGuncelleTedarikciler = new System.Windows.Forms.Label();
            this.labelUrunGuncelleKategoriler = new System.Windows.Forms.Label();
            this.btnYoneticiUrunGuncelle = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.txtYoneticiUrunGuncelleTedarikciId = new System.Windows.Forms.TextBox();
            this.txtYoneticiUrunGuncelleSiparisAdedi = new System.Windows.Forms.TextBox();
            this.txtYoneticiUrunGuncelleStokAdedi = new System.Windows.Forms.TextBox();
            this.txtYoneticiUrunGuncelleBirimFiyati = new System.Windows.Forms.TextBox();
            this.txtYoneticiUrunGuncelleKategoriId = new System.Windows.Forms.TextBox();
            this.txtYoneticiUrunGuncelleAdi = new System.Windows.Forms.TextBox();
            this.txtYoneticiUrunGuncelleId = new System.Windows.Forms.TextBox();
            this.dataGridViewYoneticiUrunler = new System.Windows.Forms.DataGridView();
            this.tabPageKargoVeKategori = new System.Windows.Forms.TabPage();
            this.label44 = new System.Windows.Forms.Label();
            this.txtYoneticiEkleKategoriAciklama = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.txtYoneticiGuncelleKategoriAciklama = new System.Windows.Forms.TextBox();
            this.btnYoneticiKategoriEkle = new System.Windows.Forms.Button();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.txtYoneticiEkleKategoriAdi = new System.Windows.Forms.TextBox();
            this.txtYoneticiEkleKategoriId = new System.Windows.Forms.TextBox();
            this.btnYoneticiKategoriSil = new System.Windows.Forms.Button();
            this.btnYoneticiKategoriGuncelle = new System.Windows.Forms.Button();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.txtYoneticiGuncelleKategoriAdi = new System.Windows.Forms.TextBox();
            this.txtYoneticiGuncelleKategoriId = new System.Windows.Forms.TextBox();
            this.dataGridViewYoneticiKategori = new System.Windows.Forms.DataGridView();
            this.btnYoneticiKargoEkle = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.txtYoneticiEkleKargoAdi = new System.Windows.Forms.TextBox();
            this.txtYoneticiEkleKargoId = new System.Windows.Forms.TextBox();
            this.btnYoneticiKargoSil = new System.Windows.Forms.Button();
            this.btnYoneticiKargoGuncelle = new System.Windows.Forms.Button();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.txtYoneticiGuncelleKargoAdi = new System.Windows.Forms.TextBox();
            this.txtYoneticiGuncelleKargoId = new System.Windows.Forms.TextBox();
            this.dataGridViewYoneticiKargo = new System.Windows.Forms.DataGridView();
            this.tabPageYoneticiSilinenler = new System.Windows.Forms.TabPage();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.dataGridViewSilinenKargolar = new System.Windows.Forms.DataGridView();
            this.dataGridViewSilinenAdresler = new System.Windows.Forms.DataGridView();
            this.dataGridViewSilinenKullanicilar = new System.Windows.Forms.DataGridView();
            this.tabPageYoneticiGirisiTedarikciler = new System.Windows.Forms.TabPage();
            this.btnYoneticiTedarikciEkle = new System.Windows.Forms.Button();
            this.btnYoneticiTedarikciSil = new System.Windows.Forms.Button();
            this.btnYoneticiTedarikciGuncelle = new System.Windows.Forms.Button();
            this.label57 = new System.Windows.Forms.Label();
            this.comboBoxYoneticiEkleTedarikciIlce = new System.Windows.Forms.ComboBox();
            this.label58 = new System.Windows.Forms.Label();
            this.comboBoxYoneticiEkleTedarikciIl = new System.Windows.Forms.ComboBox();
            this.label59 = new System.Windows.Forms.Label();
            this.txtYoneticiEkleTedarikciAdres = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.txtYoneticiEkleTedarikciTelefon = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.txtYoneticiEkleTedarikciAdi = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.txtYoneticiEkleTedarikciId = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.comboBoxYoneticiGuncelleTedarikciIlce = new System.Windows.Forms.ComboBox();
            this.label55 = new System.Windows.Forms.Label();
            this.comboBoxYoneticiGuncelleTedarikciIl = new System.Windows.Forms.ComboBox();
            this.label54 = new System.Windows.Forms.Label();
            this.txtYoneticiGuncelleTedarikciAdres = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.txtYoneticiGuncelleTedarikciTelefon = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.txtYoneticiGuncelleTedarikciAdi = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.txtYoneticiGuncelleTedarikciId = new System.Windows.Forms.TextBox();
            this.dataGridViewYoneticiTedarikciler = new System.Windows.Forms.DataGridView();
            this.tabPageYoneticiUrunFiyatTakibi = new System.Windows.Forms.TabPage();
            this.dataGridViewYoneticiUrunFiyatTakibi = new System.Windows.Forms.DataGridView();
            this.tabPageYoneticiAyarlar = new System.Windows.Forms.TabPage();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.txtYoneticiSifreDegistirTekrar = new System.Windows.Forms.TextBox();
            this.txtYoneticiSifreDegistirYeni = new System.Windows.Forms.TextBox();
            this.txtYoneticiSifreDegistirMevcut = new System.Windows.Forms.TextBox();
            this.btnYoneticiSifreDegistir = new System.Windows.Forms.Button();
            this.btnYoneticiCikis = new System.Windows.Forms.Button();
            this.panelYoneticiGiris = new System.Windows.Forms.Panel();
            this.linkLabelYoneticiGirisIptal = new System.Windows.Forms.LinkLabel();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.txtYoneticiGirisSifre = new System.Windows.Forms.TextBox();
            this.txtYoneticiGirisKullaniciAdi = new System.Windows.Forms.TextBox();
            this.btnYoneticiGiris = new System.Windows.Forms.Button();
            btnKullaniciCikis = new System.Windows.Forms.Button();
            this.tabControlKullaniciGirisi.SuspendLayout();
            this.tabPageUrunler.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewKullaniciUrunler)).BeginInit();
            this.tabPageSiparislerim.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewKullaniciSiparislerim)).BeginInit();
            this.tabPageAdreslerim.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewKullaniciAdreslerim)).BeginInit();
            this.tabPageKullaniciAyarlar.SuspendLayout();
            this.PanelKullaniciGirisi.SuspendLayout();
            this.sifremiUnuttumPanel.SuspendLayout();
            this.panelKayitOl.SuspendLayout();
            this.tabControlYoneticiGirisi.SuspendLayout();
            this.tabPageYoneticiKullanicilarVeSiparisler.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewYoneticiSiparisler)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewYoneticiKullanicilar)).BeginInit();
            this.tabPageYoneticiUrunler.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewYoneticiUrunler)).BeginInit();
            this.tabPageKargoVeKategori.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewYoneticiKategori)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewYoneticiKargo)).BeginInit();
            this.tabPageYoneticiSilinenler.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSilinenKargolar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSilinenAdresler)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSilinenKullanicilar)).BeginInit();
            this.tabPageYoneticiGirisiTedarikciler.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewYoneticiTedarikciler)).BeginInit();
            this.tabPageYoneticiUrunFiyatTakibi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewYoneticiUrunFiyatTakibi)).BeginInit();
            this.tabPageYoneticiAyarlar.SuspendLayout();
            this.panelYoneticiGiris.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnKullaniciCikis
            // 
            btnKullaniciCikis.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            btnKullaniciCikis.Location = new System.Drawing.Point(274, 452);
            btnKullaniciCikis.Name = "btnKullaniciCikis";
            btnKullaniciCikis.Size = new System.Drawing.Size(152, 45);
            btnKullaniciCikis.TabIndex = 9;
            btnKullaniciCikis.Text = "ÇIKIŞ";
            btnKullaniciCikis.UseVisualStyleBackColor = true;
            btnKullaniciCikis.Click += new System.EventHandler(this.btnKullaniciCikis_Click);
            // 
            // tabControlKullaniciGirisi
            // 
            this.tabControlKullaniciGirisi.Controls.Add(this.tabPageUrunler);
            this.tabControlKullaniciGirisi.Controls.Add(this.tabPageSiparislerim);
            this.tabControlKullaniciGirisi.Controls.Add(this.tabPageAdreslerim);
            this.tabControlKullaniciGirisi.Controls.Add(this.tabPageKullaniciAyarlar);
            this.tabControlKullaniciGirisi.Location = new System.Drawing.Point(0, 0);
            this.tabControlKullaniciGirisi.Name = "tabControlKullaniciGirisi";
            this.tabControlKullaniciGirisi.SelectedIndex = 0;
            this.tabControlKullaniciGirisi.Size = new System.Drawing.Size(710, 582);
            this.tabControlKullaniciGirisi.TabIndex = 0;
            // 
            // tabPageUrunler
            // 
            this.tabPageUrunler.Controls.Add(this.label74);
            this.tabPageUrunler.Controls.Add(this.label77);
            this.tabPageUrunler.Controls.Add(this.comboBoxKullaniciUrunlerKargo);
            this.tabPageUrunler.Controls.Add(this.label76);
            this.tabPageUrunler.Controls.Add(this.labelUrunId);
            this.tabPageUrunler.Controls.Add(this.comboBoxKullaniciUrunlerAdres);
            this.tabPageUrunler.Controls.Add(this.radioButton1);
            this.tabPageUrunler.Controls.Add(this.btnKullaniciUrunSatinAl);
            this.tabPageUrunler.Controls.Add(this.labelSiparisMiktari);
            this.tabPageUrunler.Controls.Add(this.labelStokDurumu);
            this.tabPageUrunler.Controls.Add(this.labelUrunFiyati);
            this.tabPageUrunler.Controls.Add(this.labelUrunAdi);
            this.tabPageUrunler.Controls.Add(this.label75);
            this.tabPageUrunler.Controls.Add(this.label73);
            this.tabPageUrunler.Controls.Add(this.label72);
            this.tabPageUrunler.Controls.Add(this.label71);
            this.tabPageUrunler.Controls.Add(this.dataGridViewKullaniciUrunler);
            this.tabPageUrunler.Location = new System.Drawing.Point(4, 22);
            this.tabPageUrunler.Name = "tabPageUrunler";
            this.tabPageUrunler.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageUrunler.Size = new System.Drawing.Size(702, 556);
            this.tabPageUrunler.TabIndex = 1;
            this.tabPageUrunler.Text = "Ürünler";
            this.tabPageUrunler.UseVisualStyleBackColor = true;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label74.Location = new System.Drawing.Point(3, 447);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(52, 13);
            this.label74.TabIndex = 18;
            this.label74.Text = "Kargo : ";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label77.Location = new System.Drawing.Point(4, 420);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(51, 13);
            this.label77.TabIndex = 17;
            this.label77.Text = "Adres : ";
            // 
            // comboBoxKullaniciUrunlerKargo
            // 
            this.comboBoxKullaniciUrunlerKargo.FormattingEnabled = true;
            this.comboBoxKullaniciUrunlerKargo.Location = new System.Drawing.Point(61, 444);
            this.comboBoxKullaniciUrunlerKargo.Name = "comboBoxKullaniciUrunlerKargo";
            this.comboBoxKullaniciUrunlerKargo.Size = new System.Drawing.Size(177, 21);
            this.comboBoxKullaniciUrunlerKargo.TabIndex = 16;
            this.comboBoxKullaniciUrunlerKargo.Text = "Seçiniz..";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label76.Location = new System.Drawing.Point(4, 231);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(102, 13);
            this.label76.TabIndex = 15;
            this.label76.Text = "Ürün Numarası : ";
            // 
            // labelUrunId
            // 
            this.labelUrunId.AutoSize = true;
            this.labelUrunId.Location = new System.Drawing.Point(123, 231);
            this.labelUrunId.Name = "labelUrunId";
            this.labelUrunId.Size = new System.Drawing.Size(0, 13);
            this.labelUrunId.TabIndex = 14;
            // 
            // comboBoxKullaniciUrunlerAdres
            // 
            this.comboBoxKullaniciUrunlerAdres.FormattingEnabled = true;
            this.comboBoxKullaniciUrunlerAdres.Location = new System.Drawing.Point(61, 417);
            this.comboBoxKullaniciUrunlerAdres.Name = "comboBoxKullaniciUrunlerAdres";
            this.comboBoxKullaniciUrunlerAdres.Size = new System.Drawing.Size(177, 21);
            this.comboBoxKullaniciUrunlerAdres.TabIndex = 13;
            this.comboBoxKullaniciUrunlerAdres.Text = "Seçiniz..";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(7, 390);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(95, 17);
            this.radioButton1.TabIndex = 12;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Kapıda Ödeme";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // btnKullaniciUrunSatinAl
            // 
            this.btnKullaniciUrunSatinAl.Location = new System.Drawing.Point(60, 471);
            this.btnKullaniciUrunSatinAl.Name = "btnKullaniciUrunSatinAl";
            this.btnKullaniciUrunSatinAl.Size = new System.Drawing.Size(177, 42);
            this.btnKullaniciUrunSatinAl.TabIndex = 11;
            this.btnKullaniciUrunSatinAl.Text = "SATIN AL";
            this.btnKullaniciUrunSatinAl.UseVisualStyleBackColor = true;
            this.btnKullaniciUrunSatinAl.Click += new System.EventHandler(this.btnKullaniciUrunSatinAl_Click);
            // 
            // labelSiparisMiktari
            // 
            this.labelSiparisMiktari.AutoSize = true;
            this.labelSiparisMiktari.Location = new System.Drawing.Point(123, 343);
            this.labelSiparisMiktari.Name = "labelSiparisMiktari";
            this.labelSiparisMiktari.Size = new System.Drawing.Size(0, 13);
            this.labelSiparisMiktari.TabIndex = 10;
            // 
            // labelStokDurumu
            // 
            this.labelStokDurumu.AutoSize = true;
            this.labelStokDurumu.Location = new System.Drawing.Point(123, 315);
            this.labelStokDurumu.Name = "labelStokDurumu";
            this.labelStokDurumu.Size = new System.Drawing.Size(0, 13);
            this.labelStokDurumu.TabIndex = 9;
            // 
            // labelUrunFiyati
            // 
            this.labelUrunFiyati.AutoSize = true;
            this.labelUrunFiyati.Location = new System.Drawing.Point(123, 285);
            this.labelUrunFiyati.Name = "labelUrunFiyati";
            this.labelUrunFiyati.Size = new System.Drawing.Size(0, 13);
            this.labelUrunFiyati.TabIndex = 8;
            // 
            // labelUrunAdi
            // 
            this.labelUrunAdi.AutoSize = true;
            this.labelUrunAdi.Location = new System.Drawing.Point(123, 257);
            this.labelUrunAdi.Name = "labelUrunAdi";
            this.labelUrunAdi.Size = new System.Drawing.Size(0, 13);
            this.labelUrunAdi.TabIndex = 7;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label75.Location = new System.Drawing.Point(4, 343);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(99, 13);
            this.label75.TabIndex = 6;
            this.label75.Text = "Sipariş Miktarı : ";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label73.Location = new System.Drawing.Point(4, 315);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(92, 13);
            this.label73.TabIndex = 4;
            this.label73.Text = "Stok Durumu : ";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label72.Location = new System.Drawing.Point(4, 285);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(94, 13);
            this.label72.TabIndex = 3;
            this.label72.Text = "Ürünün Fiyatı : ";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label71.Location = new System.Drawing.Point(4, 257);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(82, 13);
            this.label71.TabIndex = 2;
            this.label71.Text = "Ürünün Adı : ";
            // 
            // dataGridViewKullaniciUrunler
            // 
            this.dataGridViewKullaniciUrunler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewKullaniciUrunler.Location = new System.Drawing.Point(7, 7);
            this.dataGridViewKullaniciUrunler.Name = "dataGridViewKullaniciUrunler";
            this.dataGridViewKullaniciUrunler.ReadOnly = true;
            this.dataGridViewKullaniciUrunler.Size = new System.Drawing.Size(686, 205);
            this.dataGridViewKullaniciUrunler.TabIndex = 1;
            // 
            // tabPageSiparislerim
            // 
            this.tabPageSiparislerim.Controls.Add(this.dataGridViewKullaniciSiparislerim);
            this.tabPageSiparislerim.Location = new System.Drawing.Point(4, 22);
            this.tabPageSiparislerim.Name = "tabPageSiparislerim";
            this.tabPageSiparislerim.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageSiparislerim.Size = new System.Drawing.Size(702, 556);
            this.tabPageSiparislerim.TabIndex = 0;
            this.tabPageSiparislerim.Text = "Siparişlerim";
            this.tabPageSiparislerim.UseVisualStyleBackColor = true;
            // 
            // dataGridViewKullaniciSiparislerim
            // 
            this.dataGridViewKullaniciSiparislerim.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewKullaniciSiparislerim.Location = new System.Drawing.Point(7, 7);
            this.dataGridViewKullaniciSiparislerim.Name = "dataGridViewKullaniciSiparislerim";
            this.dataGridViewKullaniciSiparislerim.ReadOnly = true;
            this.dataGridViewKullaniciSiparislerim.Size = new System.Drawing.Size(686, 288);
            this.dataGridViewKullaniciSiparislerim.TabIndex = 2;
            // 
            // tabPageAdreslerim
            // 
            this.tabPageAdreslerim.Controls.Add(this.txtKullaniciAdresSilAdresNo);
            this.tabPageAdreslerim.Controls.Add(this.label83);
            this.tabPageAdreslerim.Controls.Add(this.txtKullaniciAdresSilKulNo);
            this.tabPageAdreslerim.Controls.Add(this.label84);
            this.tabPageAdreslerim.Controls.Add(this.btnKullaniciAdresSil);
            this.tabPageAdreslerim.Controls.Add(this.btnKullaniciAdresEkle);
            this.tabPageAdreslerim.Controls.Add(this.txtKullaniciAdresEkleAdres);
            this.tabPageAdreslerim.Controls.Add(this.label82);
            this.tabPageAdreslerim.Controls.Add(this.txtKullaniciAdresEkleIlceNo);
            this.tabPageAdreslerim.Controls.Add(this.label81);
            this.tabPageAdreslerim.Controls.Add(this.txtKullaniciAdresEklePlakaNo);
            this.tabPageAdreslerim.Controls.Add(this.label80);
            this.tabPageAdreslerim.Controls.Add(this.txtKullaniciAdresEkleAdresNo);
            this.tabPageAdreslerim.Controls.Add(this.label79);
            this.tabPageAdreslerim.Controls.Add(this.dataGridViewKullaniciAdreslerim);
            this.tabPageAdreslerim.Location = new System.Drawing.Point(4, 22);
            this.tabPageAdreslerim.Name = "tabPageAdreslerim";
            this.tabPageAdreslerim.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageAdreslerim.Size = new System.Drawing.Size(702, 556);
            this.tabPageAdreslerim.TabIndex = 2;
            this.tabPageAdreslerim.Text = "Adreslerim";
            this.tabPageAdreslerim.UseVisualStyleBackColor = true;
            // 
            // txtKullaniciAdresSilAdresNo
            // 
            this.txtKullaniciAdresSilAdresNo.Location = new System.Drawing.Point(536, 246);
            this.txtKullaniciAdresSilAdresNo.Name = "txtKullaniciAdresSilAdresNo";
            this.txtKullaniciAdresSilAdresNo.ReadOnly = true;
            this.txtKullaniciAdresSilAdresNo.Size = new System.Drawing.Size(157, 20);
            this.txtKullaniciAdresSilAdresNo.TabIndex = 18;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(430, 249);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(88, 13);
            this.label83.TabIndex = 17;
            this.label83.Text = "Adres numarası : ";
            // 
            // txtKullaniciAdresSilKulNo
            // 
            this.txtKullaniciAdresSilKulNo.Location = new System.Drawing.Point(536, 220);
            this.txtKullaniciAdresSilKulNo.Name = "txtKullaniciAdresSilKulNo";
            this.txtKullaniciAdresSilKulNo.ReadOnly = true;
            this.txtKullaniciAdresSilKulNo.Size = new System.Drawing.Size(157, 20);
            this.txtKullaniciAdresSilKulNo.TabIndex = 16;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(430, 223);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(100, 13);
            this.label84.TabIndex = 15;
            this.label84.Text = "Kullanıcı numarası : ";
            // 
            // btnKullaniciAdresSil
            // 
            this.btnKullaniciAdresSil.Location = new System.Drawing.Point(618, 268);
            this.btnKullaniciAdresSil.Name = "btnKullaniciAdresSil";
            this.btnKullaniciAdresSil.Size = new System.Drawing.Size(75, 23);
            this.btnKullaniciAdresSil.TabIndex = 14;
            this.btnKullaniciAdresSil.Text = "SİL";
            this.btnKullaniciAdresSil.UseVisualStyleBackColor = true;
            this.btnKullaniciAdresSil.Click += new System.EventHandler(this.btnKullaniciAdresSil_Click);
            // 
            // btnKullaniciAdresEkle
            // 
            this.btnKullaniciAdresEkle.Location = new System.Drawing.Point(153, 324);
            this.btnKullaniciAdresEkle.Name = "btnKullaniciAdresEkle";
            this.btnKullaniciAdresEkle.Size = new System.Drawing.Size(75, 23);
            this.btnKullaniciAdresEkle.TabIndex = 13;
            this.btnKullaniciAdresEkle.Text = "Ekle";
            this.btnKullaniciAdresEkle.UseVisualStyleBackColor = true;
            this.btnKullaniciAdresEkle.Click += new System.EventHandler(this.btnKullaniciAdresEkle_Click);
            // 
            // txtKullaniciAdresEkleAdres
            // 
            this.txtKullaniciAdresEkleAdres.Location = new System.Drawing.Point(110, 298);
            this.txtKullaniciAdresEkleAdres.Name = "txtKullaniciAdresEkleAdres";
            this.txtKullaniciAdresEkleAdres.Size = new System.Drawing.Size(157, 20);
            this.txtKullaniciAdresEkleAdres.TabIndex = 12;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(4, 301);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(43, 13);
            this.label82.TabIndex = 11;
            this.label82.Text = "Adres : ";
            // 
            // txtKullaniciAdresEkleIlceNo
            // 
            this.txtKullaniciAdresEkleIlceNo.Location = new System.Drawing.Point(110, 272);
            this.txtKullaniciAdresEkleIlceNo.Name = "txtKullaniciAdresEkleIlceNo";
            this.txtKullaniciAdresEkleIlceNo.Size = new System.Drawing.Size(157, 20);
            this.txtKullaniciAdresEkleIlceNo.TabIndex = 10;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(4, 275);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(80, 13);
            this.label81.TabIndex = 9;
            this.label81.Text = "İlçe Numarası : ";
            // 
            // txtKullaniciAdresEklePlakaNo
            // 
            this.txtKullaniciAdresEklePlakaNo.Location = new System.Drawing.Point(110, 246);
            this.txtKullaniciAdresEklePlakaNo.Name = "txtKullaniciAdresEklePlakaNo";
            this.txtKullaniciAdresEklePlakaNo.Size = new System.Drawing.Size(157, 20);
            this.txtKullaniciAdresEklePlakaNo.TabIndex = 8;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(4, 249);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(71, 13);
            this.label80.TabIndex = 7;
            this.label80.Text = "Plaka Kodu : ";
            // 
            // txtKullaniciAdresEkleAdresNo
            // 
            this.txtKullaniciAdresEkleAdresNo.Location = new System.Drawing.Point(110, 220);
            this.txtKullaniciAdresEkleAdresNo.Name = "txtKullaniciAdresEkleAdresNo";
            this.txtKullaniciAdresEkleAdresNo.Size = new System.Drawing.Size(157, 20);
            this.txtKullaniciAdresEkleAdresNo.TabIndex = 6;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(4, 223);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(88, 13);
            this.label79.TabIndex = 5;
            this.label79.Text = "Adres numarası : ";
            // 
            // dataGridViewKullaniciAdreslerim
            // 
            this.dataGridViewKullaniciAdreslerim.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewKullaniciAdreslerim.Location = new System.Drawing.Point(7, 7);
            this.dataGridViewKullaniciAdreslerim.Name = "dataGridViewKullaniciAdreslerim";
            this.dataGridViewKullaniciAdreslerim.ReadOnly = true;
            this.dataGridViewKullaniciAdreslerim.Size = new System.Drawing.Size(686, 205);
            this.dataGridViewKullaniciAdreslerim.TabIndex = 2;
            // 
            // tabPageKullaniciAyarlar
            // 
            this.tabPageKullaniciAyarlar.Controls.Add(this.label67);
            this.tabPageKullaniciAyarlar.Controls.Add(this.label68);
            this.tabPageKullaniciAyarlar.Controls.Add(this.label69);
            this.tabPageKullaniciAyarlar.Controls.Add(this.label70);
            this.tabPageKullaniciAyarlar.Controls.Add(this.txtKullaniciSifreDegistirTekrar);
            this.tabPageKullaniciAyarlar.Controls.Add(this.txtKullaniciSifreDegistirYeni);
            this.tabPageKullaniciAyarlar.Controls.Add(this.txtKullaniciSifreDegistirMevcut);
            this.tabPageKullaniciAyarlar.Controls.Add(this.btnKullaniciSifreDegistir);
            this.tabPageKullaniciAyarlar.Controls.Add(btnKullaniciCikis);
            this.tabPageKullaniciAyarlar.Location = new System.Drawing.Point(4, 22);
            this.tabPageKullaniciAyarlar.Name = "tabPageKullaniciAyarlar";
            this.tabPageKullaniciAyarlar.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageKullaniciAyarlar.Size = new System.Drawing.Size(702, 556);
            this.tabPageKullaniciAyarlar.TabIndex = 3;
            this.tabPageKullaniciAyarlar.Text = "Ayarlar";
            this.tabPageKullaniciAyarlar.UseVisualStyleBackColor = true;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label67.Location = new System.Drawing.Point(285, 125);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(136, 25);
            this.label67.TabIndex = 17;
            this.label67.Text = "Şifre Değiştir";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(184, 220);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(94, 13);
            this.label68.TabIndex = 16;
            this.label68.Text = "Yeni Şifre(tekrar) : ";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(184, 195);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(61, 13);
            this.label69.TabIndex = 15;
            this.label69.Text = "Yeni Şifre : ";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(184, 169);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(76, 13);
            this.label70.TabIndex = 14;
            this.label70.Text = "Mevcut Şifre : ";
            // 
            // txtKullaniciSifreDegistirTekrar
            // 
            this.txtKullaniciSifreDegistirTekrar.Location = new System.Drawing.Point(284, 217);
            this.txtKullaniciSifreDegistirTekrar.Name = "txtKullaniciSifreDegistirTekrar";
            this.txtKullaniciSifreDegistirTekrar.Size = new System.Drawing.Size(137, 20);
            this.txtKullaniciSifreDegistirTekrar.TabIndex = 13;
            this.txtKullaniciSifreDegistirTekrar.UseSystemPasswordChar = true;
            // 
            // txtKullaniciSifreDegistirYeni
            // 
            this.txtKullaniciSifreDegistirYeni.Location = new System.Drawing.Point(284, 192);
            this.txtKullaniciSifreDegistirYeni.Name = "txtKullaniciSifreDegistirYeni";
            this.txtKullaniciSifreDegistirYeni.Size = new System.Drawing.Size(137, 20);
            this.txtKullaniciSifreDegistirYeni.TabIndex = 12;
            this.txtKullaniciSifreDegistirYeni.UseSystemPasswordChar = true;
            // 
            // txtKullaniciSifreDegistirMevcut
            // 
            this.txtKullaniciSifreDegistirMevcut.Location = new System.Drawing.Point(284, 166);
            this.txtKullaniciSifreDegistirMevcut.Name = "txtKullaniciSifreDegistirMevcut";
            this.txtKullaniciSifreDegistirMevcut.Size = new System.Drawing.Size(137, 20);
            this.txtKullaniciSifreDegistirMevcut.TabIndex = 11;
            this.txtKullaniciSifreDegistirMevcut.UseSystemPasswordChar = true;
            // 
            // btnKullaniciSifreDegistir
            // 
            this.btnKullaniciSifreDegistir.Location = new System.Drawing.Point(302, 243);
            this.btnKullaniciSifreDegistir.Name = "btnKullaniciSifreDegistir";
            this.btnKullaniciSifreDegistir.Size = new System.Drawing.Size(99, 23);
            this.btnKullaniciSifreDegistir.TabIndex = 10;
            this.btnKullaniciSifreDegistir.Text = "Şifreyi Değiştir";
            this.btnKullaniciSifreDegistir.UseVisualStyleBackColor = true;
            this.btnKullaniciSifreDegistir.Click += new System.EventHandler(this.btnKullaniciSifreDegistir_Click);
            // 
            // PanelKullaniciGirisi
            // 
            this.PanelKullaniciGirisi.Controls.Add(this.linkLabelKullaniciGirisiToYoneticiGirisi);
            this.PanelKullaniciGirisi.Controls.Add(this.label47);
            this.PanelKullaniciGirisi.Controls.Add(this.linkKayitOl);
            this.PanelKullaniciGirisi.Controls.Add(this.linkSifremiUnuttum);
            this.PanelKullaniciGirisi.Controls.Add(this.label2);
            this.PanelKullaniciGirisi.Controls.Add(this.label1);
            this.PanelKullaniciGirisi.Controls.Add(this.txtGirisSifre);
            this.PanelKullaniciGirisi.Controls.Add(this.txtGirisKullaniciAdi);
            this.PanelKullaniciGirisi.Controls.Add(this.btnUyeGiris);
            this.PanelKullaniciGirisi.Location = new System.Drawing.Point(0, 0);
            this.PanelKullaniciGirisi.Name = "PanelKullaniciGirisi";
            this.PanelKullaniciGirisi.Size = new System.Drawing.Size(706, 582);
            this.PanelKullaniciGirisi.TabIndex = 1;
            this.PanelKullaniciGirisi.Paint += new System.Windows.Forms.PaintEventHandler(this.girisPanel_Paint);
            // 
            // linkLabelKullaniciGirisiToYoneticiGirisi
            // 
            this.linkLabelKullaniciGirisiToYoneticiGirisi.AutoSize = true;
            this.linkLabelKullaniciGirisiToYoneticiGirisi.Location = new System.Drawing.Point(322, 366);
            this.linkLabelKullaniciGirisiToYoneticiGirisi.Name = "linkLabelKullaniciGirisiToYoneticiGirisi";
            this.linkLabelKullaniciGirisiToYoneticiGirisi.Size = new System.Drawing.Size(70, 13);
            this.linkLabelKullaniciGirisiToYoneticiGirisi.TabIndex = 118;
            this.linkLabelKullaniciGirisiToYoneticiGirisi.TabStop = true;
            this.linkLabelKullaniciGirisiToYoneticiGirisi.Text = "Yönetici Girişi";
            this.linkLabelKullaniciGirisiToYoneticiGirisi.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelKullaniciGirisiToYoneticiGirisi_LinkClicked);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label47.Location = new System.Drawing.Point(277, 194);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(149, 25);
            this.label47.TabIndex = 117;
            this.label47.Text = "Kullanıcı Girişi";
            // 
            // linkKayitOl
            // 
            this.linkKayitOl.AutoSize = true;
            this.linkKayitOl.Location = new System.Drawing.Point(334, 344);
            this.linkKayitOl.Name = "linkKayitOl";
            this.linkKayitOl.Size = new System.Drawing.Size(43, 13);
            this.linkKayitOl.TabIndex = 6;
            this.linkKayitOl.TabStop = true;
            this.linkKayitOl.Text = "Kayıt Ol";
            this.linkKayitOl.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkKayitOl_LinkClicked);
            // 
            // linkSifremiUnuttum
            // 
            this.linkSifremiUnuttum.AutoSize = true;
            this.linkSifremiUnuttum.Location = new System.Drawing.Point(315, 322);
            this.linkSifremiUnuttum.Name = "linkSifremiUnuttum";
            this.linkSifremiUnuttum.Size = new System.Drawing.Size(81, 13);
            this.linkSifremiUnuttum.TabIndex = 5;
            this.linkSifremiUnuttum.TabStop = true;
            this.linkSifremiUnuttum.Text = "Şifremi Unuttum";
            this.linkSifremiUnuttum.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkSifremiUnuttum_LinkClicked);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(172, 271);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Şifre : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(172, 245);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Kullanıcı Adı : ";
            // 
            // txtGirisSifre
            // 
            this.txtGirisSifre.Location = new System.Drawing.Point(253, 268);
            this.txtGirisSifre.Name = "txtGirisSifre";
            this.txtGirisSifre.Size = new System.Drawing.Size(200, 20);
            this.txtGirisSifre.TabIndex = 2;
            this.txtGirisSifre.UseSystemPasswordChar = true;
            // 
            // txtGirisKullaniciAdi
            // 
            this.txtGirisKullaniciAdi.Location = new System.Drawing.Point(253, 242);
            this.txtGirisKullaniciAdi.Name = "txtGirisKullaniciAdi";
            this.txtGirisKullaniciAdi.Size = new System.Drawing.Size(200, 20);
            this.txtGirisKullaniciAdi.TabIndex = 1;
            // 
            // btnUyeGiris
            // 
            this.btnUyeGiris.Location = new System.Drawing.Point(297, 294);
            this.btnUyeGiris.Name = "btnUyeGiris";
            this.btnUyeGiris.Size = new System.Drawing.Size(118, 23);
            this.btnUyeGiris.TabIndex = 0;
            this.btnUyeGiris.Text = "GİRİŞ";
            this.btnUyeGiris.UseVisualStyleBackColor = true;
            this.btnUyeGiris.Click += new System.EventHandler(this.btnUyeGiris_Click);
            // 
            // sifremiUnuttumPanel
            // 
            this.sifremiUnuttumPanel.Controls.Add(this.label45);
            this.sifremiUnuttumPanel.Controls.Add(this.label17);
            this.sifremiUnuttumPanel.Controls.Add(this.txtSifreDegistirKullaniciAdi);
            this.sifremiUnuttumPanel.Controls.Add(this.linkLabelSifreDegistirIptal);
            this.sifremiUnuttumPanel.Controls.Add(this.label6);
            this.sifremiUnuttumPanel.Controls.Add(this.txtSifreDegistirYeniSifreTekrar);
            this.sifremiUnuttumPanel.Controls.Add(this.label5);
            this.sifremiUnuttumPanel.Controls.Add(this.txtSifreDegistirYeniSifre);
            this.sifremiUnuttumPanel.Controls.Add(this.comboBoxSifreDegistirGuvenlikSorusu);
            this.sifremiUnuttumPanel.Controls.Add(this.label3);
            this.sifremiUnuttumPanel.Controls.Add(this.label4);
            this.sifremiUnuttumPanel.Controls.Add(this.txtSifreDegistirGuvenlikSorusuCevabi);
            this.sifremiUnuttumPanel.Controls.Add(this.btnSifreDegistir);
            this.sifremiUnuttumPanel.Location = new System.Drawing.Point(1, -1);
            this.sifremiUnuttumPanel.Name = "sifremiUnuttumPanel";
            this.sifremiUnuttumPanel.Size = new System.Drawing.Size(706, 582);
            this.sifremiUnuttumPanel.TabIndex = 2;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label45.Location = new System.Drawing.Point(271, 171);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(165, 25);
            this.label45.TabIndex = 116;
            this.label45.Text = "Şifre Değiştirme";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(113, 211);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(73, 13);
            this.label17.TabIndex = 115;
            this.label17.Text = "Kullanıcı Adı : ";
            // 
            // txtSifreDegistirKullaniciAdi
            // 
            this.txtSifreDegistirKullaniciAdi.Location = new System.Drawing.Point(253, 208);
            this.txtSifreDegistirKullaniciAdi.Name = "txtSifreDegistirKullaniciAdi";
            this.txtSifreDegistirKullaniciAdi.Size = new System.Drawing.Size(200, 20);
            this.txtSifreDegistirKullaniciAdi.TabIndex = 114;
            // 
            // linkLabelSifreDegistirIptal
            // 
            this.linkLabelSifreDegistirIptal.AutoSize = true;
            this.linkLabelSifreDegistirIptal.Location = new System.Drawing.Point(340, 367);
            this.linkLabelSifreDegistirIptal.Name = "linkLabelSifreDegistirIptal";
            this.linkLabelSifreDegistirIptal.Size = new System.Drawing.Size(27, 13);
            this.linkLabelSifreDegistirIptal.TabIndex = 113;
            this.linkLabelSifreDegistirIptal.TabStop = true;
            this.linkLabelSifreDegistirIptal.Text = "İptal";
            this.linkLabelSifreDegistirIptal.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelSifreDegistirIptal_LinkClicked);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(113, 315);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Yeni Şifre(tekrar) : ";
            // 
            // txtSifreDegistirYeniSifreTekrar
            // 
            this.txtSifreDegistirYeniSifreTekrar.Location = new System.Drawing.Point(252, 312);
            this.txtSifreDegistirYeniSifreTekrar.Name = "txtSifreDegistirYeniSifreTekrar";
            this.txtSifreDegistirYeniSifreTekrar.Size = new System.Drawing.Size(200, 20);
            this.txtSifreDegistirYeniSifreTekrar.TabIndex = 9;
            this.txtSifreDegistirYeniSifreTekrar.UseSystemPasswordChar = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(113, 289);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Yeni Şifre : ";
            // 
            // txtSifreDegistirYeniSifre
            // 
            this.txtSifreDegistirYeniSifre.Location = new System.Drawing.Point(253, 286);
            this.txtSifreDegistirYeniSifre.Name = "txtSifreDegistirYeniSifre";
            this.txtSifreDegistirYeniSifre.Size = new System.Drawing.Size(200, 20);
            this.txtSifreDegistirYeniSifre.TabIndex = 7;
            this.txtSifreDegistirYeniSifre.UseSystemPasswordChar = true;
            // 
            // comboBoxSifreDegistirGuvenlikSorusu
            // 
            this.comboBoxSifreDegistirGuvenlikSorusu.FormattingEnabled = true;
            this.comboBoxSifreDegistirGuvenlikSorusu.Location = new System.Drawing.Point(253, 234);
            this.comboBoxSifreDegistirGuvenlikSorusu.Name = "comboBoxSifreDegistirGuvenlikSorusu";
            this.comboBoxSifreDegistirGuvenlikSorusu.Size = new System.Drawing.Size(200, 21);
            this.comboBoxSifreDegistirGuvenlikSorusu.TabIndex = 6;
            this.comboBoxSifreDegistirGuvenlikSorusu.Text = "Seçiniz..";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(113, 263);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(130, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Güvenlik Sorusu Cevabı : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(113, 237);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Güvenlik Sorusu : ";
            // 
            // txtSifreDegistirGuvenlikSorusuCevabi
            // 
            this.txtSifreDegistirGuvenlikSorusuCevabi.Location = new System.Drawing.Point(253, 260);
            this.txtSifreDegistirGuvenlikSorusuCevabi.Name = "txtSifreDegistirGuvenlikSorusuCevabi";
            this.txtSifreDegistirGuvenlikSorusuCevabi.Size = new System.Drawing.Size(200, 20);
            this.txtSifreDegistirGuvenlikSorusuCevabi.TabIndex = 2;
            // 
            // btnSifreDegistir
            // 
            this.btnSifreDegistir.Location = new System.Drawing.Point(296, 338);
            this.btnSifreDegistir.Name = "btnSifreDegistir";
            this.btnSifreDegistir.Size = new System.Drawing.Size(118, 23);
            this.btnSifreDegistir.TabIndex = 0;
            this.btnSifreDegistir.Text = "Şifreyi Değiştir";
            this.btnSifreDegistir.UseVisualStyleBackColor = true;
            this.btnSifreDegistir.Click += new System.EventHandler(this.btnSifreDegistir_Click);
            // 
            // panelKayitOl
            // 
            this.panelKayitOl.Controls.Add(this.label46);
            this.panelKayitOl.Controls.Add(this.label16);
            this.panelKayitOl.Controls.Add(this.txtKayitOlGuvenlikCevap);
            this.panelKayitOl.Controls.Add(this.label15);
            this.panelKayitOl.Controls.Add(this.comboBoxKayitOlGuvenlikSorusu);
            this.panelKayitOl.Controls.Add(this.label14);
            this.panelKayitOl.Controls.Add(this.kayitOlRadioButtonErkek);
            this.panelKayitOl.Controls.Add(this.kayitOlRadioButtonKadin);
            this.panelKayitOl.Controls.Add(this.label13);
            this.panelKayitOl.Controls.Add(this.kayitOlDogumTarihi);
            this.panelKayitOl.Controls.Add(this.label12);
            this.panelKayitOl.Controls.Add(this.txtKayitOlTelefon);
            this.panelKayitOl.Controls.Add(this.label11);
            this.panelKayitOl.Controls.Add(this.txtKayitOlSifreTekrar);
            this.panelKayitOl.Controls.Add(this.label10);
            this.panelKayitOl.Controls.Add(this.txtKayitOlSoyisim);
            this.panelKayitOl.Controls.Add(this.label9);
            this.panelKayitOl.Controls.Add(this.txtKayitOlisim);
            this.panelKayitOl.Controls.Add(this.linkLabelKayitOlIptal);
            this.panelKayitOl.Controls.Add(this.label7);
            this.panelKayitOl.Controls.Add(this.label8);
            this.panelKayitOl.Controls.Add(this.txtKayitOlSifre);
            this.panelKayitOl.Controls.Add(this.txtKayitOlKullaniciAdi);
            this.panelKayitOl.Controls.Add(this.btnKayitOl);
            this.panelKayitOl.Location = new System.Drawing.Point(0, 0);
            this.panelKayitOl.Name = "panelKayitOl";
            this.panelKayitOl.Size = new System.Drawing.Size(706, 582);
            this.panelKayitOl.TabIndex = 3;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label46.Location = new System.Drawing.Point(292, 78);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(118, 25);
            this.label46.TabIndex = 117;
            this.label46.Text = "Kayıt Olma";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(154, 357);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(47, 13);
            this.label16.TabIndex = 23;
            this.label16.Text = "Cevap : ";
            // 
            // txtKayitOlGuvenlikCevap
            // 
            this.txtKayitOlGuvenlikCevap.Location = new System.Drawing.Point(253, 354);
            this.txtKayitOlGuvenlikCevap.Name = "txtKayitOlGuvenlikCevap";
            this.txtKayitOlGuvenlikCevap.Size = new System.Drawing.Size(200, 20);
            this.txtKayitOlGuvenlikCevap.TabIndex = 110;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(154, 330);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(94, 13);
            this.label15.TabIndex = 21;
            this.label15.Text = "Güvenlik Sorusu : ";
            // 
            // comboBoxKayitOlGuvenlikSorusu
            // 
            this.comboBoxKayitOlGuvenlikSorusu.FormattingEnabled = true;
            this.comboBoxKayitOlGuvenlikSorusu.Location = new System.Drawing.Point(253, 327);
            this.comboBoxKayitOlGuvenlikSorusu.Name = "comboBoxKayitOlGuvenlikSorusu";
            this.comboBoxKayitOlGuvenlikSorusu.Size = new System.Drawing.Size(200, 21);
            this.comboBoxKayitOlGuvenlikSorusu.TabIndex = 109;
            this.comboBoxKayitOlGuvenlikSorusu.Text = "Seçiniz..";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(154, 305);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(52, 13);
            this.label14.TabIndex = 19;
            this.label14.Text = "Cinsiyet : ";
            // 
            // kayitOlRadioButtonErkek
            // 
            this.kayitOlRadioButtonErkek.AutoSize = true;
            this.kayitOlRadioButtonErkek.Location = new System.Drawing.Point(311, 303);
            this.kayitOlRadioButtonErkek.Name = "kayitOlRadioButtonErkek";
            this.kayitOlRadioButtonErkek.Size = new System.Drawing.Size(53, 17);
            this.kayitOlRadioButtonErkek.TabIndex = 108;
            this.kayitOlRadioButtonErkek.Text = "Erkek";
            this.kayitOlRadioButtonErkek.UseVisualStyleBackColor = true;
            // 
            // kayitOlRadioButtonKadin
            // 
            this.kayitOlRadioButtonKadin.AutoSize = true;
            this.kayitOlRadioButtonKadin.Checked = true;
            this.kayitOlRadioButtonKadin.Location = new System.Drawing.Point(253, 303);
            this.kayitOlRadioButtonKadin.Name = "kayitOlRadioButtonKadin";
            this.kayitOlRadioButtonKadin.Size = new System.Drawing.Size(52, 17);
            this.kayitOlRadioButtonKadin.TabIndex = 107;
            this.kayitOlRadioButtonKadin.TabStop = true;
            this.kayitOlRadioButtonKadin.Text = "Kadın";
            this.kayitOlRadioButtonKadin.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(154, 280);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(79, 13);
            this.label13.TabIndex = 16;
            this.label13.Text = "Doğum Tarihi : ";
            // 
            // kayitOlDogumTarihi
            // 
            this.kayitOlDogumTarihi.Location = new System.Drawing.Point(253, 276);
            this.kayitOlDogumTarihi.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.kayitOlDogumTarihi.Name = "kayitOlDogumTarihi";
            this.kayitOlDogumTarihi.Size = new System.Drawing.Size(200, 20);
            this.kayitOlDogumTarihi.TabIndex = 106;
            this.kayitOlDogumTarihi.Value = new System.DateTime(2020, 7, 29, 14, 38, 36, 0);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(154, 253);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(52, 13);
            this.label12.TabIndex = 14;
            this.label12.Text = "Telefon : ";
            // 
            // txtKayitOlTelefon
            // 
            this.txtKayitOlTelefon.Location = new System.Drawing.Point(253, 250);
            this.txtKayitOlTelefon.Name = "txtKayitOlTelefon";
            this.txtKayitOlTelefon.Size = new System.Drawing.Size(200, 20);
            this.txtKayitOlTelefon.TabIndex = 105;
            this.txtKayitOlTelefon.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtKayitOlTelefon_KeyPress);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(154, 227);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(73, 13);
            this.label11.TabIndex = 12;
            this.label11.Text = "Şifre (tekrar) : ";
            // 
            // txtKayitOlSifreTekrar
            // 
            this.txtKayitOlSifreTekrar.Location = new System.Drawing.Point(253, 224);
            this.txtKayitOlSifreTekrar.Name = "txtKayitOlSifreTekrar";
            this.txtKayitOlSifreTekrar.Size = new System.Drawing.Size(200, 20);
            this.txtKayitOlSifreTekrar.TabIndex = 104;
            this.txtKayitOlSifreTekrar.UseSystemPasswordChar = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(154, 175);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(51, 13);
            this.label10.TabIndex = 10;
            this.label10.Text = "Soyisim : ";
            // 
            // txtKayitOlSoyisim
            // 
            this.txtKayitOlSoyisim.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtKayitOlSoyisim.Location = new System.Drawing.Point(253, 172);
            this.txtKayitOlSoyisim.Name = "txtKayitOlSoyisim";
            this.txtKayitOlSoyisim.Size = new System.Drawing.Size(200, 20);
            this.txtKayitOlSoyisim.TabIndex = 102;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(154, 149);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(34, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "İsim : ";
            // 
            // txtKayitOlisim
            // 
            this.txtKayitOlisim.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtKayitOlisim.Location = new System.Drawing.Point(253, 146);
            this.txtKayitOlisim.Name = "txtKayitOlisim";
            this.txtKayitOlisim.Size = new System.Drawing.Size(200, 20);
            this.txtKayitOlisim.TabIndex = 101;
            // 
            // linkLabelKayitOlIptal
            // 
            this.linkLabelKayitOlIptal.AutoSize = true;
            this.linkLabelKayitOlIptal.Location = new System.Drawing.Point(341, 408);
            this.linkLabelKayitOlIptal.Name = "linkLabelKayitOlIptal";
            this.linkLabelKayitOlIptal.Size = new System.Drawing.Size(27, 13);
            this.linkLabelKayitOlIptal.TabIndex = 112;
            this.linkLabelKayitOlIptal.TabStop = true;
            this.linkLabelKayitOlIptal.Text = "İptal";
            this.linkLabelKayitOlIptal.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelKayitOlIptal_LinkClicked);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(154, 201);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "Şifre : ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(154, 123);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 13);
            this.label8.TabIndex = 3;
            this.label8.Text = "Kullanıcı Adı : ";
            // 
            // txtKayitOlSifre
            // 
            this.txtKayitOlSifre.Location = new System.Drawing.Point(253, 198);
            this.txtKayitOlSifre.Name = "txtKayitOlSifre";
            this.txtKayitOlSifre.Size = new System.Drawing.Size(200, 20);
            this.txtKayitOlSifre.TabIndex = 103;
            this.txtKayitOlSifre.UseSystemPasswordChar = true;
            // 
            // txtKayitOlKullaniciAdi
            // 
            this.txtKayitOlKullaniciAdi.Location = new System.Drawing.Point(253, 120);
            this.txtKayitOlKullaniciAdi.Name = "txtKayitOlKullaniciAdi";
            this.txtKayitOlKullaniciAdi.Size = new System.Drawing.Size(200, 20);
            this.txtKayitOlKullaniciAdi.TabIndex = 100;
            // 
            // btnKayitOl
            // 
            this.btnKayitOl.Location = new System.Drawing.Point(294, 380);
            this.btnKayitOl.Name = "btnKayitOl";
            this.btnKayitOl.Size = new System.Drawing.Size(118, 23);
            this.btnKayitOl.TabIndex = 111;
            this.btnKayitOl.Text = "KAYIT OL";
            this.btnKayitOl.UseVisualStyleBackColor = true;
            this.btnKayitOl.Click += new System.EventHandler(this.btnKayitOl_Click);
            // 
            // tabControlYoneticiGirisi
            // 
            this.tabControlYoneticiGirisi.Controls.Add(this.tabPageYoneticiKullanicilarVeSiparisler);
            this.tabControlYoneticiGirisi.Controls.Add(this.tabPageYoneticiUrunler);
            this.tabControlYoneticiGirisi.Controls.Add(this.tabPageKargoVeKategori);
            this.tabControlYoneticiGirisi.Controls.Add(this.tabPageYoneticiSilinenler);
            this.tabControlYoneticiGirisi.Controls.Add(this.tabPageYoneticiGirisiTedarikciler);
            this.tabControlYoneticiGirisi.Controls.Add(this.tabPageYoneticiUrunFiyatTakibi);
            this.tabControlYoneticiGirisi.Controls.Add(this.tabPageYoneticiAyarlar);
            this.tabControlYoneticiGirisi.Location = new System.Drawing.Point(-1, -1);
            this.tabControlYoneticiGirisi.Name = "tabControlYoneticiGirisi";
            this.tabControlYoneticiGirisi.SelectedIndex = 0;
            this.tabControlYoneticiGirisi.Size = new System.Drawing.Size(710, 582);
            this.tabControlYoneticiGirisi.TabIndex = 4;
            this.tabControlYoneticiGirisi.SelectedIndexChanged += new System.EventHandler(this.tabControlYoneticiGirisi_SelectedIndexChanged);
            // 
            // tabPageYoneticiKullanicilarVeSiparisler
            // 
            this.tabPageYoneticiKullanicilarVeSiparisler.Controls.Add(this.dataGridViewYoneticiSiparisler);
            this.tabPageYoneticiKullanicilarVeSiparisler.Controls.Add(this.btnYoneticiKullaniciSil);
            this.tabPageYoneticiKullanicilarVeSiparisler.Controls.Add(this.txtYoneticiSilinecekKullanici);
            this.tabPageYoneticiKullanicilarVeSiparisler.Controls.Add(this.dataGridViewYoneticiKullanicilar);
            this.tabPageYoneticiKullanicilarVeSiparisler.Location = new System.Drawing.Point(4, 22);
            this.tabPageYoneticiKullanicilarVeSiparisler.Name = "tabPageYoneticiKullanicilarVeSiparisler";
            this.tabPageYoneticiKullanicilarVeSiparisler.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageYoneticiKullanicilarVeSiparisler.Size = new System.Drawing.Size(702, 556);
            this.tabPageYoneticiKullanicilarVeSiparisler.TabIndex = 1;
            this.tabPageYoneticiKullanicilarVeSiparisler.Text = "Kullanıcılar ve Siparişler";
            this.tabPageYoneticiKullanicilarVeSiparisler.UseVisualStyleBackColor = true;
            // 
            // dataGridViewYoneticiSiparisler
            // 
            this.dataGridViewYoneticiSiparisler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewYoneticiSiparisler.Location = new System.Drawing.Point(6, 317);
            this.dataGridViewYoneticiSiparisler.Name = "dataGridViewYoneticiSiparisler";
            this.dataGridViewYoneticiSiparisler.ReadOnly = true;
            this.dataGridViewYoneticiSiparisler.Size = new System.Drawing.Size(684, 231);
            this.dataGridViewYoneticiSiparisler.TabIndex = 4;
            // 
            // btnYoneticiKullaniciSil
            // 
            this.btnYoneticiKullaniciSil.Location = new System.Drawing.Point(6, 243);
            this.btnYoneticiKullaniciSil.Name = "btnYoneticiKullaniciSil";
            this.btnYoneticiKullaniciSil.Size = new System.Drawing.Size(112, 23);
            this.btnYoneticiKullaniciSil.TabIndex = 3;
            this.btnYoneticiKullaniciSil.Text = "Kullanıcıyı Sil";
            this.btnYoneticiKullaniciSil.UseVisualStyleBackColor = true;
            this.btnYoneticiKullaniciSil.Click += new System.EventHandler(this.btnYoneticiKullaniciSil_Click);
            // 
            // txtYoneticiSilinecekKullanici
            // 
            this.txtYoneticiSilinecekKullanici.Location = new System.Drawing.Point(566, 243);
            this.txtYoneticiSilinecekKullanici.Name = "txtYoneticiSilinecekKullanici";
            this.txtYoneticiSilinecekKullanici.ReadOnly = true;
            this.txtYoneticiSilinecekKullanici.Size = new System.Drawing.Size(124, 20);
            this.txtYoneticiSilinecekKullanici.TabIndex = 2;
            // 
            // dataGridViewYoneticiKullanicilar
            // 
            this.dataGridViewYoneticiKullanicilar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewYoneticiKullanicilar.Location = new System.Drawing.Point(6, 6);
            this.dataGridViewYoneticiKullanicilar.Name = "dataGridViewYoneticiKullanicilar";
            this.dataGridViewYoneticiKullanicilar.ReadOnly = true;
            this.dataGridViewYoneticiKullanicilar.Size = new System.Drawing.Size(684, 231);
            this.dataGridViewYoneticiKullanicilar.TabIndex = 1;
            // 
            // tabPageYoneticiUrunler
            // 
            this.tabPageYoneticiUrunler.Controls.Add(this.btnYoneticiUrunSil);
            this.tabPageYoneticiUrunler.Controls.Add(this.btnYoneticiUrunEkle);
            this.tabPageYoneticiUrunler.Controls.Add(this.label28);
            this.tabPageYoneticiUrunler.Controls.Add(this.label29);
            this.tabPageYoneticiUrunler.Controls.Add(this.label30);
            this.tabPageYoneticiUrunler.Controls.Add(this.label31);
            this.tabPageYoneticiUrunler.Controls.Add(this.label32);
            this.tabPageYoneticiUrunler.Controls.Add(this.label33);
            this.tabPageYoneticiUrunler.Controls.Add(this.label34);
            this.tabPageYoneticiUrunler.Controls.Add(this.txtYoneticiUrunEkleTedarikciId);
            this.tabPageYoneticiUrunler.Controls.Add(this.txtYoneticiUrunEkleSiparisAdedi);
            this.tabPageYoneticiUrunler.Controls.Add(this.txtYoneticiUrunEkleStokAdedi);
            this.tabPageYoneticiUrunler.Controls.Add(this.txtYoneticiUrunEkleBirimFiyati);
            this.tabPageYoneticiUrunler.Controls.Add(this.txtYoneticiUrunEkleKategoriId);
            this.tabPageYoneticiUrunler.Controls.Add(this.txtYoneticiUrunEkleAdi);
            this.tabPageYoneticiUrunler.Controls.Add(this.txtYoneticiUrunEkleId);
            this.tabPageYoneticiUrunler.Controls.Add(this.listBoxYoneticiTedarikciler);
            this.tabPageYoneticiUrunler.Controls.Add(this.listBoxYoneticiKategoriler);
            this.tabPageYoneticiUrunler.Controls.Add(this.labelUrunGuncelleTedarikciler);
            this.tabPageYoneticiUrunler.Controls.Add(this.labelUrunGuncelleKategoriler);
            this.tabPageYoneticiUrunler.Controls.Add(this.btnYoneticiUrunGuncelle);
            this.tabPageYoneticiUrunler.Controls.Add(this.label27);
            this.tabPageYoneticiUrunler.Controls.Add(this.label26);
            this.tabPageYoneticiUrunler.Controls.Add(this.label25);
            this.tabPageYoneticiUrunler.Controls.Add(this.label24);
            this.tabPageYoneticiUrunler.Controls.Add(this.label23);
            this.tabPageYoneticiUrunler.Controls.Add(this.label22);
            this.tabPageYoneticiUrunler.Controls.Add(this.label21);
            this.tabPageYoneticiUrunler.Controls.Add(this.txtYoneticiUrunGuncelleTedarikciId);
            this.tabPageYoneticiUrunler.Controls.Add(this.txtYoneticiUrunGuncelleSiparisAdedi);
            this.tabPageYoneticiUrunler.Controls.Add(this.txtYoneticiUrunGuncelleStokAdedi);
            this.tabPageYoneticiUrunler.Controls.Add(this.txtYoneticiUrunGuncelleBirimFiyati);
            this.tabPageYoneticiUrunler.Controls.Add(this.txtYoneticiUrunGuncelleKategoriId);
            this.tabPageYoneticiUrunler.Controls.Add(this.txtYoneticiUrunGuncelleAdi);
            this.tabPageYoneticiUrunler.Controls.Add(this.txtYoneticiUrunGuncelleId);
            this.tabPageYoneticiUrunler.Controls.Add(this.dataGridViewYoneticiUrunler);
            this.tabPageYoneticiUrunler.Location = new System.Drawing.Point(4, 22);
            this.tabPageYoneticiUrunler.Name = "tabPageYoneticiUrunler";
            this.tabPageYoneticiUrunler.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageYoneticiUrunler.Size = new System.Drawing.Size(702, 556);
            this.tabPageYoneticiUrunler.TabIndex = 0;
            this.tabPageYoneticiUrunler.Text = "Ürünler";
            this.tabPageYoneticiUrunler.UseVisualStyleBackColor = true;
            // 
            // btnYoneticiUrunSil
            // 
            this.btnYoneticiUrunSil.Location = new System.Drawing.Point(175, 404);
            this.btnYoneticiUrunSil.Name = "btnYoneticiUrunSil";
            this.btnYoneticiUrunSil.Size = new System.Drawing.Size(75, 23);
            this.btnYoneticiUrunSil.TabIndex = 35;
            this.btnYoneticiUrunSil.Text = "SİL";
            this.btnYoneticiUrunSil.UseVisualStyleBackColor = true;
            this.btnYoneticiUrunSil.Click += new System.EventHandler(this.btnYoneticiUrunSil_Click);
            // 
            // btnYoneticiUrunEkle
            // 
            this.btnYoneticiUrunEkle.Location = new System.Drawing.Point(573, 404);
            this.btnYoneticiUrunEkle.Name = "btnYoneticiUrunEkle";
            this.btnYoneticiUrunEkle.Size = new System.Drawing.Size(75, 23);
            this.btnYoneticiUrunEkle.TabIndex = 34;
            this.btnYoneticiUrunEkle.Text = "EKLE";
            this.btnYoneticiUrunEkle.UseVisualStyleBackColor = true;
            this.btnYoneticiUrunEkle.Click += new System.EventHandler(this.btnYoneticiUrunEkle_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(452, 381);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(74, 13);
            this.label28.TabIndex = 33;
            this.label28.Text = "Tedarikçi ID : ";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(452, 356);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(77, 13);
            this.label29.TabIndex = 32;
            this.label29.Text = "Sipariş Adedi : ";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(452, 331);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(68, 13);
            this.label30.TabIndex = 31;
            this.label30.Text = "Stok Adedi : ";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(452, 305);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(65, 13);
            this.label31.TabIndex = 30;
            this.label31.Text = "Birim Fiyatı : ";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(452, 280);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(69, 13);
            this.label32.TabIndex = 29;
            this.label32.Text = "Kategori ID : ";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(452, 255);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(57, 13);
            this.label33.TabIndex = 28;
            this.label33.Text = "Urun Adı : ";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(452, 228);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(53, 13);
            this.label34.TabIndex = 27;
            this.label34.Text = "Urun ID : ";
            // 
            // txtYoneticiUrunEkleTedarikciId
            // 
            this.txtYoneticiUrunEkleTedarikciId.Location = new System.Drawing.Point(535, 378);
            this.txtYoneticiUrunEkleTedarikciId.Name = "txtYoneticiUrunEkleTedarikciId";
            this.txtYoneticiUrunEkleTedarikciId.Size = new System.Drawing.Size(158, 20);
            this.txtYoneticiUrunEkleTedarikciId.TabIndex = 26;
            // 
            // txtYoneticiUrunEkleSiparisAdedi
            // 
            this.txtYoneticiUrunEkleSiparisAdedi.Location = new System.Drawing.Point(535, 353);
            this.txtYoneticiUrunEkleSiparisAdedi.Name = "txtYoneticiUrunEkleSiparisAdedi";
            this.txtYoneticiUrunEkleSiparisAdedi.ReadOnly = true;
            this.txtYoneticiUrunEkleSiparisAdedi.Size = new System.Drawing.Size(158, 20);
            this.txtYoneticiUrunEkleSiparisAdedi.TabIndex = 25;
            this.txtYoneticiUrunEkleSiparisAdedi.Text = "0";
            // 
            // txtYoneticiUrunEkleStokAdedi
            // 
            this.txtYoneticiUrunEkleStokAdedi.Location = new System.Drawing.Point(535, 328);
            this.txtYoneticiUrunEkleStokAdedi.Name = "txtYoneticiUrunEkleStokAdedi";
            this.txtYoneticiUrunEkleStokAdedi.Size = new System.Drawing.Size(158, 20);
            this.txtYoneticiUrunEkleStokAdedi.TabIndex = 24;
            // 
            // txtYoneticiUrunEkleBirimFiyati
            // 
            this.txtYoneticiUrunEkleBirimFiyati.Location = new System.Drawing.Point(535, 302);
            this.txtYoneticiUrunEkleBirimFiyati.Name = "txtYoneticiUrunEkleBirimFiyati";
            this.txtYoneticiUrunEkleBirimFiyati.Size = new System.Drawing.Size(158, 20);
            this.txtYoneticiUrunEkleBirimFiyati.TabIndex = 23;
            this.txtYoneticiUrunEkleBirimFiyati.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtYoneticiUrunEkleBirimFiyati_KeyPress);
            // 
            // txtYoneticiUrunEkleKategoriId
            // 
            this.txtYoneticiUrunEkleKategoriId.Location = new System.Drawing.Point(535, 277);
            this.txtYoneticiUrunEkleKategoriId.Name = "txtYoneticiUrunEkleKategoriId";
            this.txtYoneticiUrunEkleKategoriId.Size = new System.Drawing.Size(158, 20);
            this.txtYoneticiUrunEkleKategoriId.TabIndex = 22;
            // 
            // txtYoneticiUrunEkleAdi
            // 
            this.txtYoneticiUrunEkleAdi.Location = new System.Drawing.Point(535, 252);
            this.txtYoneticiUrunEkleAdi.Name = "txtYoneticiUrunEkleAdi";
            this.txtYoneticiUrunEkleAdi.Size = new System.Drawing.Size(158, 20);
            this.txtYoneticiUrunEkleAdi.TabIndex = 21;
            // 
            // txtYoneticiUrunEkleId
            // 
            this.txtYoneticiUrunEkleId.Location = new System.Drawing.Point(535, 225);
            this.txtYoneticiUrunEkleId.Name = "txtYoneticiUrunEkleId";
            this.txtYoneticiUrunEkleId.Size = new System.Drawing.Size(158, 20);
            this.txtYoneticiUrunEkleId.TabIndex = 20;
            // 
            // listBoxYoneticiTedarikciler
            // 
            this.listBoxYoneticiTedarikciler.FormattingEnabled = true;
            this.listBoxYoneticiTedarikciler.Location = new System.Drawing.Point(140, 452);
            this.listBoxYoneticiTedarikciler.Name = "listBoxYoneticiTedarikciler";
            this.listBoxYoneticiTedarikciler.Size = new System.Drawing.Size(122, 95);
            this.listBoxYoneticiTedarikciler.TabIndex = 19;
            // 
            // listBoxYoneticiKategoriler
            // 
            this.listBoxYoneticiKategoriler.FormattingEnabled = true;
            this.listBoxYoneticiKategoriler.Location = new System.Drawing.Point(12, 452);
            this.listBoxYoneticiKategoriler.Name = "listBoxYoneticiKategoriler";
            this.listBoxYoneticiKategoriler.Size = new System.Drawing.Size(122, 95);
            this.listBoxYoneticiKategoriler.TabIndex = 18;
            // 
            // labelUrunGuncelleTedarikciler
            // 
            this.labelUrunGuncelleTedarikciler.AutoSize = true;
            this.labelUrunGuncelleTedarikciler.Location = new System.Drawing.Point(137, 436);
            this.labelUrunGuncelleTedarikciler.Name = "labelUrunGuncelleTedarikciler";
            this.labelUrunGuncelleTedarikciler.Size = new System.Drawing.Size(71, 13);
            this.labelUrunGuncelleTedarikciler.TabIndex = 17;
            this.labelUrunGuncelleTedarikciler.Text = "Tedarikçiler : ";
            // 
            // labelUrunGuncelleKategoriler
            // 
            this.labelUrunGuncelleKategoriler.AutoSize = true;
            this.labelUrunGuncelleKategoriler.Location = new System.Drawing.Point(9, 436);
            this.labelUrunGuncelleKategoriler.Name = "labelUrunGuncelleKategoriler";
            this.labelUrunGuncelleKategoriler.Size = new System.Drawing.Size(66, 13);
            this.labelUrunGuncelleKategoriler.TabIndex = 16;
            this.labelUrunGuncelleKategoriler.Text = "Kategoriler : ";
            // 
            // btnYoneticiUrunGuncelle
            // 
            this.btnYoneticiUrunGuncelle.Location = new System.Drawing.Point(92, 404);
            this.btnYoneticiUrunGuncelle.Name = "btnYoneticiUrunGuncelle";
            this.btnYoneticiUrunGuncelle.Size = new System.Drawing.Size(75, 23);
            this.btnYoneticiUrunGuncelle.TabIndex = 15;
            this.btnYoneticiUrunGuncelle.Text = "GÜNCELLE";
            this.btnYoneticiUrunGuncelle.UseVisualStyleBackColor = true;
            this.btnYoneticiUrunGuncelle.Click += new System.EventHandler(this.btnYoneticiUrunGuncelle_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(9, 381);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(74, 13);
            this.label27.TabIndex = 14;
            this.label27.Text = "Tedarikçi ID : ";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(9, 356);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(77, 13);
            this.label26.TabIndex = 13;
            this.label26.Text = "Sipariş Adedi : ";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(9, 331);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(68, 13);
            this.label25.TabIndex = 12;
            this.label25.Text = "Stok Adedi : ";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(9, 305);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(65, 13);
            this.label24.TabIndex = 11;
            this.label24.Text = "Birim Fiyatı : ";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(9, 280);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(69, 13);
            this.label23.TabIndex = 10;
            this.label23.Text = "Kategori ID : ";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(9, 255);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(57, 13);
            this.label22.TabIndex = 9;
            this.label22.Text = "Urun Adı : ";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(9, 228);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(53, 13);
            this.label21.TabIndex = 8;
            this.label21.Text = "Urun ID : ";
            // 
            // txtYoneticiUrunGuncelleTedarikciId
            // 
            this.txtYoneticiUrunGuncelleTedarikciId.Location = new System.Drawing.Point(92, 378);
            this.txtYoneticiUrunGuncelleTedarikciId.Name = "txtYoneticiUrunGuncelleTedarikciId";
            this.txtYoneticiUrunGuncelleTedarikciId.Size = new System.Drawing.Size(158, 20);
            this.txtYoneticiUrunGuncelleTedarikciId.TabIndex = 7;
            // 
            // txtYoneticiUrunGuncelleSiparisAdedi
            // 
            this.txtYoneticiUrunGuncelleSiparisAdedi.Location = new System.Drawing.Point(92, 353);
            this.txtYoneticiUrunGuncelleSiparisAdedi.Name = "txtYoneticiUrunGuncelleSiparisAdedi";
            this.txtYoneticiUrunGuncelleSiparisAdedi.ReadOnly = true;
            this.txtYoneticiUrunGuncelleSiparisAdedi.Size = new System.Drawing.Size(158, 20);
            this.txtYoneticiUrunGuncelleSiparisAdedi.TabIndex = 6;
            // 
            // txtYoneticiUrunGuncelleStokAdedi
            // 
            this.txtYoneticiUrunGuncelleStokAdedi.Location = new System.Drawing.Point(92, 328);
            this.txtYoneticiUrunGuncelleStokAdedi.Name = "txtYoneticiUrunGuncelleStokAdedi";
            this.txtYoneticiUrunGuncelleStokAdedi.Size = new System.Drawing.Size(158, 20);
            this.txtYoneticiUrunGuncelleStokAdedi.TabIndex = 5;
            // 
            // txtYoneticiUrunGuncelleBirimFiyati
            // 
            this.txtYoneticiUrunGuncelleBirimFiyati.Location = new System.Drawing.Point(92, 302);
            this.txtYoneticiUrunGuncelleBirimFiyati.Name = "txtYoneticiUrunGuncelleBirimFiyati";
            this.txtYoneticiUrunGuncelleBirimFiyati.Size = new System.Drawing.Size(158, 20);
            this.txtYoneticiUrunGuncelleBirimFiyati.TabIndex = 4;
            // 
            // txtYoneticiUrunGuncelleKategoriId
            // 
            this.txtYoneticiUrunGuncelleKategoriId.Location = new System.Drawing.Point(92, 277);
            this.txtYoneticiUrunGuncelleKategoriId.Name = "txtYoneticiUrunGuncelleKategoriId";
            this.txtYoneticiUrunGuncelleKategoriId.Size = new System.Drawing.Size(158, 20);
            this.txtYoneticiUrunGuncelleKategoriId.TabIndex = 3;
            // 
            // txtYoneticiUrunGuncelleAdi
            // 
            this.txtYoneticiUrunGuncelleAdi.Location = new System.Drawing.Point(92, 252);
            this.txtYoneticiUrunGuncelleAdi.Name = "txtYoneticiUrunGuncelleAdi";
            this.txtYoneticiUrunGuncelleAdi.Size = new System.Drawing.Size(158, 20);
            this.txtYoneticiUrunGuncelleAdi.TabIndex = 2;
            // 
            // txtYoneticiUrunGuncelleId
            // 
            this.txtYoneticiUrunGuncelleId.Location = new System.Drawing.Point(92, 225);
            this.txtYoneticiUrunGuncelleId.Name = "txtYoneticiUrunGuncelleId";
            this.txtYoneticiUrunGuncelleId.ReadOnly = true;
            this.txtYoneticiUrunGuncelleId.Size = new System.Drawing.Size(158, 20);
            this.txtYoneticiUrunGuncelleId.TabIndex = 1;
            // 
            // dataGridViewYoneticiUrunler
            // 
            this.dataGridViewYoneticiUrunler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewYoneticiUrunler.Location = new System.Drawing.Point(7, 7);
            this.dataGridViewYoneticiUrunler.Name = "dataGridViewYoneticiUrunler";
            this.dataGridViewYoneticiUrunler.ReadOnly = true;
            this.dataGridViewYoneticiUrunler.Size = new System.Drawing.Size(686, 205);
            this.dataGridViewYoneticiUrunler.TabIndex = 0;
            // 
            // tabPageKargoVeKategori
            // 
            this.tabPageKargoVeKategori.Controls.Add(this.label44);
            this.tabPageKargoVeKategori.Controls.Add(this.txtYoneticiEkleKategoriAciklama);
            this.tabPageKargoVeKategori.Controls.Add(this.label43);
            this.tabPageKargoVeKategori.Controls.Add(this.txtYoneticiGuncelleKategoriAciklama);
            this.tabPageKargoVeKategori.Controls.Add(this.btnYoneticiKategoriEkle);
            this.tabPageKargoVeKategori.Controls.Add(this.label39);
            this.tabPageKargoVeKategori.Controls.Add(this.label40);
            this.tabPageKargoVeKategori.Controls.Add(this.txtYoneticiEkleKategoriAdi);
            this.tabPageKargoVeKategori.Controls.Add(this.txtYoneticiEkleKategoriId);
            this.tabPageKargoVeKategori.Controls.Add(this.btnYoneticiKategoriSil);
            this.tabPageKargoVeKategori.Controls.Add(this.btnYoneticiKategoriGuncelle);
            this.tabPageKargoVeKategori.Controls.Add(this.label41);
            this.tabPageKargoVeKategori.Controls.Add(this.label42);
            this.tabPageKargoVeKategori.Controls.Add(this.txtYoneticiGuncelleKategoriAdi);
            this.tabPageKargoVeKategori.Controls.Add(this.txtYoneticiGuncelleKategoriId);
            this.tabPageKargoVeKategori.Controls.Add(this.dataGridViewYoneticiKategori);
            this.tabPageKargoVeKategori.Controls.Add(this.btnYoneticiKargoEkle);
            this.tabPageKargoVeKategori.Controls.Add(this.label37);
            this.tabPageKargoVeKategori.Controls.Add(this.label38);
            this.tabPageKargoVeKategori.Controls.Add(this.txtYoneticiEkleKargoAdi);
            this.tabPageKargoVeKategori.Controls.Add(this.txtYoneticiEkleKargoId);
            this.tabPageKargoVeKategori.Controls.Add(this.btnYoneticiKargoSil);
            this.tabPageKargoVeKategori.Controls.Add(this.btnYoneticiKargoGuncelle);
            this.tabPageKargoVeKategori.Controls.Add(this.label35);
            this.tabPageKargoVeKategori.Controls.Add(this.label36);
            this.tabPageKargoVeKategori.Controls.Add(this.txtYoneticiGuncelleKargoAdi);
            this.tabPageKargoVeKategori.Controls.Add(this.txtYoneticiGuncelleKargoId);
            this.tabPageKargoVeKategori.Controls.Add(this.dataGridViewYoneticiKargo);
            this.tabPageKargoVeKategori.Location = new System.Drawing.Point(4, 22);
            this.tabPageKargoVeKategori.Name = "tabPageKargoVeKategori";
            this.tabPageKargoVeKategori.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageKargoVeKategori.Size = new System.Drawing.Size(702, 556);
            this.tabPageKargoVeKategori.TabIndex = 3;
            this.tabPageKargoVeKategori.Text = "Kargo ve Kategori";
            this.tabPageKargoVeKategori.UseVisualStyleBackColor = true;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(401, 489);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(59, 13);
            this.label44.TabIndex = 58;
            this.label44.Text = "Açıklama : ";
            // 
            // txtYoneticiEkleKategoriAciklama
            // 
            this.txtYoneticiEkleKategoriAciklama.Location = new System.Drawing.Point(480, 486);
            this.txtYoneticiEkleKategoriAciklama.Name = "txtYoneticiEkleKategoriAciklama";
            this.txtYoneticiEkleKategoriAciklama.Size = new System.Drawing.Size(214, 20);
            this.txtYoneticiEkleKategoriAciklama.TabIndex = 57;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(9, 489);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(59, 13);
            this.label43.TabIndex = 56;
            this.label43.Text = "Açıklama : ";
            // 
            // txtYoneticiGuncelleKategoriAciklama
            // 
            this.txtYoneticiGuncelleKategoriAciklama.Location = new System.Drawing.Point(88, 486);
            this.txtYoneticiGuncelleKategoriAciklama.Name = "txtYoneticiGuncelleKategoriAciklama";
            this.txtYoneticiGuncelleKategoriAciklama.Size = new System.Drawing.Size(214, 20);
            this.txtYoneticiGuncelleKategoriAciklama.TabIndex = 55;
            // 
            // btnYoneticiKategoriEkle
            // 
            this.btnYoneticiKategoriEkle.Location = new System.Drawing.Point(551, 512);
            this.btnYoneticiKategoriEkle.Name = "btnYoneticiKategoriEkle";
            this.btnYoneticiKategoriEkle.Size = new System.Drawing.Size(75, 23);
            this.btnYoneticiKategoriEkle.TabIndex = 54;
            this.btnYoneticiKategoriEkle.Text = "EKLE";
            this.btnYoneticiKategoriEkle.UseVisualStyleBackColor = true;
            this.btnYoneticiKategoriEkle.Click += new System.EventHandler(this.btnYoneticiKategoriEkle_Click);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(401, 463);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(73, 13);
            this.label39.TabIndex = 53;
            this.label39.Text = "Kategori Adı : ";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(401, 438);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(69, 13);
            this.label40.TabIndex = 52;
            this.label40.Text = "Kategori ID : ";
            // 
            // txtYoneticiEkleKategoriAdi
            // 
            this.txtYoneticiEkleKategoriAdi.Location = new System.Drawing.Point(480, 460);
            this.txtYoneticiEkleKategoriAdi.Name = "txtYoneticiEkleKategoriAdi";
            this.txtYoneticiEkleKategoriAdi.Size = new System.Drawing.Size(214, 20);
            this.txtYoneticiEkleKategoriAdi.TabIndex = 51;
            // 
            // txtYoneticiEkleKategoriId
            // 
            this.txtYoneticiEkleKategoriId.Location = new System.Drawing.Point(480, 435);
            this.txtYoneticiEkleKategoriId.Name = "txtYoneticiEkleKategoriId";
            this.txtYoneticiEkleKategoriId.Size = new System.Drawing.Size(214, 20);
            this.txtYoneticiEkleKategoriId.TabIndex = 50;
            // 
            // btnYoneticiKategoriSil
            // 
            this.btnYoneticiKategoriSil.Location = new System.Drawing.Point(202, 512);
            this.btnYoneticiKategoriSil.Name = "btnYoneticiKategoriSil";
            this.btnYoneticiKategoriSil.Size = new System.Drawing.Size(100, 23);
            this.btnYoneticiKategoriSil.TabIndex = 49;
            this.btnYoneticiKategoriSil.Text = "SİL";
            this.btnYoneticiKategoriSil.UseVisualStyleBackColor = true;
            this.btnYoneticiKategoriSil.Click += new System.EventHandler(this.btnYoneticiKategoriSil_Click);
            // 
            // btnYoneticiKategoriGuncelle
            // 
            this.btnYoneticiKategoriGuncelle.Location = new System.Drawing.Point(88, 512);
            this.btnYoneticiKategoriGuncelle.Name = "btnYoneticiKategoriGuncelle";
            this.btnYoneticiKategoriGuncelle.Size = new System.Drawing.Size(100, 23);
            this.btnYoneticiKategoriGuncelle.TabIndex = 48;
            this.btnYoneticiKategoriGuncelle.Text = "GÜNCELLE";
            this.btnYoneticiKategoriGuncelle.UseVisualStyleBackColor = true;
            this.btnYoneticiKategoriGuncelle.Click += new System.EventHandler(this.btnYoneticiKategoriGuncelle_Click);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(9, 463);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(73, 13);
            this.label41.TabIndex = 47;
            this.label41.Text = "Kategori Adı : ";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(9, 438);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(69, 13);
            this.label42.TabIndex = 46;
            this.label42.Text = "Kategori ID : ";
            // 
            // txtYoneticiGuncelleKategoriAdi
            // 
            this.txtYoneticiGuncelleKategoriAdi.Location = new System.Drawing.Point(88, 460);
            this.txtYoneticiGuncelleKategoriAdi.Name = "txtYoneticiGuncelleKategoriAdi";
            this.txtYoneticiGuncelleKategoriAdi.Size = new System.Drawing.Size(214, 20);
            this.txtYoneticiGuncelleKategoriAdi.TabIndex = 45;
            // 
            // txtYoneticiGuncelleKategoriId
            // 
            this.txtYoneticiGuncelleKategoriId.Location = new System.Drawing.Point(88, 435);
            this.txtYoneticiGuncelleKategoriId.Name = "txtYoneticiGuncelleKategoriId";
            this.txtYoneticiGuncelleKategoriId.ReadOnly = true;
            this.txtYoneticiGuncelleKategoriId.Size = new System.Drawing.Size(214, 20);
            this.txtYoneticiGuncelleKategoriId.TabIndex = 44;
            // 
            // dataGridViewYoneticiKategori
            // 
            this.dataGridViewYoneticiKategori.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewYoneticiKategori.Location = new System.Drawing.Point(8, 268);
            this.dataGridViewYoneticiKategori.Name = "dataGridViewYoneticiKategori";
            this.dataGridViewYoneticiKategori.ReadOnly = true;
            this.dataGridViewYoneticiKategori.Size = new System.Drawing.Size(686, 160);
            this.dataGridViewYoneticiKategori.TabIndex = 43;
            // 
            // btnYoneticiKargoEkle
            // 
            this.btnYoneticiKargoEkle.Location = new System.Drawing.Point(578, 225);
            this.btnYoneticiKargoEkle.Name = "btnYoneticiKargoEkle";
            this.btnYoneticiKargoEkle.Size = new System.Drawing.Size(75, 23);
            this.btnYoneticiKargoEkle.TabIndex = 42;
            this.btnYoneticiKargoEkle.Text = "EKLE";
            this.btnYoneticiKargoEkle.UseVisualStyleBackColor = true;
            this.btnYoneticiKargoEkle.Click += new System.EventHandler(this.btnYoneticiKargoEkle_Click);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(467, 202);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(62, 13);
            this.label37.TabIndex = 41;
            this.label37.Text = "Kargo Adı : ";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(467, 177);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(58, 13);
            this.label38.TabIndex = 40;
            this.label38.Text = "Kargo ID : ";
            // 
            // txtYoneticiEkleKargoAdi
            // 
            this.txtYoneticiEkleKargoAdi.Location = new System.Drawing.Point(535, 199);
            this.txtYoneticiEkleKargoAdi.Name = "txtYoneticiEkleKargoAdi";
            this.txtYoneticiEkleKargoAdi.Size = new System.Drawing.Size(158, 20);
            this.txtYoneticiEkleKargoAdi.TabIndex = 39;
            // 
            // txtYoneticiEkleKargoId
            // 
            this.txtYoneticiEkleKargoId.Location = new System.Drawing.Point(535, 174);
            this.txtYoneticiEkleKargoId.Name = "txtYoneticiEkleKargoId";
            this.txtYoneticiEkleKargoId.Size = new System.Drawing.Size(158, 20);
            this.txtYoneticiEkleKargoId.TabIndex = 38;
            // 
            // btnYoneticiKargoSil
            // 
            this.btnYoneticiKargoSil.Location = new System.Drawing.Point(160, 225);
            this.btnYoneticiKargoSil.Name = "btnYoneticiKargoSil";
            this.btnYoneticiKargoSil.Size = new System.Drawing.Size(75, 23);
            this.btnYoneticiKargoSil.TabIndex = 37;
            this.btnYoneticiKargoSil.Text = "SİL";
            this.btnYoneticiKargoSil.UseVisualStyleBackColor = true;
            this.btnYoneticiKargoSil.Click += new System.EventHandler(this.btnYoneticiKargoSil_Click);
            // 
            // btnYoneticiKargoGuncelle
            // 
            this.btnYoneticiKargoGuncelle.Location = new System.Drawing.Point(77, 225);
            this.btnYoneticiKargoGuncelle.Name = "btnYoneticiKargoGuncelle";
            this.btnYoneticiKargoGuncelle.Size = new System.Drawing.Size(75, 23);
            this.btnYoneticiKargoGuncelle.TabIndex = 36;
            this.btnYoneticiKargoGuncelle.Text = "GÜNCELLE";
            this.btnYoneticiKargoGuncelle.UseVisualStyleBackColor = true;
            this.btnYoneticiKargoGuncelle.Click += new System.EventHandler(this.btnYoneticiKargoGuncelle_Click);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(9, 202);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(62, 13);
            this.label35.TabIndex = 14;
            this.label35.Text = "Kargo Adı : ";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(9, 177);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(58, 13);
            this.label36.TabIndex = 13;
            this.label36.Text = "Kargo ID : ";
            // 
            // txtYoneticiGuncelleKargoAdi
            // 
            this.txtYoneticiGuncelleKargoAdi.Location = new System.Drawing.Point(77, 199);
            this.txtYoneticiGuncelleKargoAdi.Name = "txtYoneticiGuncelleKargoAdi";
            this.txtYoneticiGuncelleKargoAdi.Size = new System.Drawing.Size(158, 20);
            this.txtYoneticiGuncelleKargoAdi.TabIndex = 12;
            // 
            // txtYoneticiGuncelleKargoId
            // 
            this.txtYoneticiGuncelleKargoId.Location = new System.Drawing.Point(77, 174);
            this.txtYoneticiGuncelleKargoId.Name = "txtYoneticiGuncelleKargoId";
            this.txtYoneticiGuncelleKargoId.ReadOnly = true;
            this.txtYoneticiGuncelleKargoId.Size = new System.Drawing.Size(158, 20);
            this.txtYoneticiGuncelleKargoId.TabIndex = 11;
            // 
            // dataGridViewYoneticiKargo
            // 
            this.dataGridViewYoneticiKargo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewYoneticiKargo.Location = new System.Drawing.Point(8, 7);
            this.dataGridViewYoneticiKargo.Name = "dataGridViewYoneticiKargo";
            this.dataGridViewYoneticiKargo.ReadOnly = true;
            this.dataGridViewYoneticiKargo.Size = new System.Drawing.Size(686, 160);
            this.dataGridViewYoneticiKargo.TabIndex = 1;
            // 
            // tabPageYoneticiSilinenler
            // 
            this.tabPageYoneticiSilinenler.Controls.Add(this.label20);
            this.tabPageYoneticiSilinenler.Controls.Add(this.label19);
            this.tabPageYoneticiSilinenler.Controls.Add(this.label18);
            this.tabPageYoneticiSilinenler.Controls.Add(this.dataGridViewSilinenKargolar);
            this.tabPageYoneticiSilinenler.Controls.Add(this.dataGridViewSilinenAdresler);
            this.tabPageYoneticiSilinenler.Controls.Add(this.dataGridViewSilinenKullanicilar);
            this.tabPageYoneticiSilinenler.Location = new System.Drawing.Point(4, 22);
            this.tabPageYoneticiSilinenler.Name = "tabPageYoneticiSilinenler";
            this.tabPageYoneticiSilinenler.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageYoneticiSilinenler.Size = new System.Drawing.Size(702, 556);
            this.tabPageYoneticiSilinenler.TabIndex = 2;
            this.tabPageYoneticiSilinenler.Text = "Silinenler";
            this.tabPageYoneticiSilinenler.UseVisualStyleBackColor = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(7, 371);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(55, 13);
            this.label20.TabIndex = 5;
            this.label20.Text = "Kargolar : ";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(7, 189);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(54, 13);
            this.label19.TabIndex = 4;
            this.label19.Text = "Adresler : ";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(7, 7);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(66, 13);
            this.label18.TabIndex = 3;
            this.label18.Text = "Kullanıcılar : ";
            // 
            // dataGridViewSilinenKargolar
            // 
            this.dataGridViewSilinenKargolar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSilinenKargolar.Location = new System.Drawing.Point(7, 387);
            this.dataGridViewSilinenKargolar.Name = "dataGridViewSilinenKargolar";
            this.dataGridViewSilinenKargolar.ReadOnly = true;
            this.dataGridViewSilinenKargolar.Size = new System.Drawing.Size(684, 150);
            this.dataGridViewSilinenKargolar.TabIndex = 2;
            // 
            // dataGridViewSilinenAdresler
            // 
            this.dataGridViewSilinenAdresler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSilinenAdresler.Location = new System.Drawing.Point(7, 204);
            this.dataGridViewSilinenAdresler.Name = "dataGridViewSilinenAdresler";
            this.dataGridViewSilinenAdresler.ReadOnly = true;
            this.dataGridViewSilinenAdresler.Size = new System.Drawing.Size(684, 150);
            this.dataGridViewSilinenAdresler.TabIndex = 1;
            // 
            // dataGridViewSilinenKullanicilar
            // 
            this.dataGridViewSilinenKullanicilar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSilinenKullanicilar.Location = new System.Drawing.Point(7, 23);
            this.dataGridViewSilinenKullanicilar.Name = "dataGridViewSilinenKullanicilar";
            this.dataGridViewSilinenKullanicilar.ReadOnly = true;
            this.dataGridViewSilinenKullanicilar.Size = new System.Drawing.Size(684, 150);
            this.dataGridViewSilinenKullanicilar.TabIndex = 0;
            // 
            // tabPageYoneticiGirisiTedarikciler
            // 
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.btnYoneticiTedarikciEkle);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.btnYoneticiTedarikciSil);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.btnYoneticiTedarikciGuncelle);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.label57);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.comboBoxYoneticiEkleTedarikciIlce);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.label58);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.comboBoxYoneticiEkleTedarikciIl);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.label59);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.txtYoneticiEkleTedarikciAdres);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.label60);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.txtYoneticiEkleTedarikciTelefon);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.label61);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.txtYoneticiEkleTedarikciAdi);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.label62);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.txtYoneticiEkleTedarikciId);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.label56);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.comboBoxYoneticiGuncelleTedarikciIlce);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.label55);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.comboBoxYoneticiGuncelleTedarikciIl);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.label54);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.txtYoneticiGuncelleTedarikciAdres);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.label53);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.txtYoneticiGuncelleTedarikciTelefon);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.label52);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.txtYoneticiGuncelleTedarikciAdi);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.label51);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.txtYoneticiGuncelleTedarikciId);
            this.tabPageYoneticiGirisiTedarikciler.Controls.Add(this.dataGridViewYoneticiTedarikciler);
            this.tabPageYoneticiGirisiTedarikciler.Location = new System.Drawing.Point(4, 22);
            this.tabPageYoneticiGirisiTedarikciler.Name = "tabPageYoneticiGirisiTedarikciler";
            this.tabPageYoneticiGirisiTedarikciler.Size = new System.Drawing.Size(702, 556);
            this.tabPageYoneticiGirisiTedarikciler.TabIndex = 4;
            this.tabPageYoneticiGirisiTedarikciler.Text = "Tedarikçiler";
            this.tabPageYoneticiGirisiTedarikciler.UseVisualStyleBackColor = true;
            // 
            // btnYoneticiTedarikciEkle
            // 
            this.btnYoneticiTedarikciEkle.Location = new System.Drawing.Point(534, 405);
            this.btnYoneticiTedarikciEkle.Name = "btnYoneticiTedarikciEkle";
            this.btnYoneticiTedarikciEkle.Size = new System.Drawing.Size(100, 23);
            this.btnYoneticiTedarikciEkle.TabIndex = 36;
            this.btnYoneticiTedarikciEkle.Text = "EKLE";
            this.btnYoneticiTedarikciEkle.UseVisualStyleBackColor = true;
            this.btnYoneticiTedarikciEkle.Click += new System.EventHandler(this.btnYoneticiTedarikciEkle_Click);
            // 
            // btnYoneticiTedarikciSil
            // 
            this.btnYoneticiTedarikciSil.Location = new System.Drawing.Point(232, 405);
            this.btnYoneticiTedarikciSil.Name = "btnYoneticiTedarikciSil";
            this.btnYoneticiTedarikciSil.Size = new System.Drawing.Size(100, 23);
            this.btnYoneticiTedarikciSil.TabIndex = 35;
            this.btnYoneticiTedarikciSil.Text = "SİL";
            this.btnYoneticiTedarikciSil.UseVisualStyleBackColor = true;
            // 
            // btnYoneticiTedarikciGuncelle
            // 
            this.btnYoneticiTedarikciGuncelle.Location = new System.Drawing.Point(114, 405);
            this.btnYoneticiTedarikciGuncelle.Name = "btnYoneticiTedarikciGuncelle";
            this.btnYoneticiTedarikciGuncelle.Size = new System.Drawing.Size(100, 23);
            this.btnYoneticiTedarikciGuncelle.TabIndex = 34;
            this.btnYoneticiTedarikciGuncelle.Text = "GÜNCELLE";
            this.btnYoneticiTedarikciGuncelle.UseVisualStyleBackColor = true;
            this.btnYoneticiTedarikciGuncelle.Click += new System.EventHandler(this.btnYoneticiTedarikciGuncelle_Click);
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(370, 381);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(33, 13);
            this.label57.TabIndex = 33;
            this.label57.Text = "İlçe : ";
            // 
            // comboBoxYoneticiEkleTedarikciIlce
            // 
            this.comboBoxYoneticiEkleTedarikciIlce.Enabled = false;
            this.comboBoxYoneticiEkleTedarikciIlce.FormattingEnabled = true;
            this.comboBoxYoneticiEkleTedarikciIlce.Location = new System.Drawing.Point(475, 378);
            this.comboBoxYoneticiEkleTedarikciIlce.Name = "comboBoxYoneticiEkleTedarikciIlce";
            this.comboBoxYoneticiEkleTedarikciIlce.Size = new System.Drawing.Size(218, 21);
            this.comboBoxYoneticiEkleTedarikciIlce.TabIndex = 32;
            this.comboBoxYoneticiEkleTedarikciIlce.Text = "Seçiniz..";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(370, 354);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(21, 13);
            this.label58.TabIndex = 31;
            this.label58.Text = "İl : ";
            // 
            // comboBoxYoneticiEkleTedarikciIl
            // 
            this.comboBoxYoneticiEkleTedarikciIl.FormattingEnabled = true;
            this.comboBoxYoneticiEkleTedarikciIl.Location = new System.Drawing.Point(475, 351);
            this.comboBoxYoneticiEkleTedarikciIl.Name = "comboBoxYoneticiEkleTedarikciIl";
            this.comboBoxYoneticiEkleTedarikciIl.Size = new System.Drawing.Size(218, 21);
            this.comboBoxYoneticiEkleTedarikciIl.TabIndex = 30;
            this.comboBoxYoneticiEkleTedarikciIl.Text = "Seçiniz..";
            this.comboBoxYoneticiEkleTedarikciIl.SelectedIndexChanged += new System.EventHandler(this.comboBoxYoneticiEkleTedarikciIl_SelectedIndexChanged);
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(370, 328);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(45, 13);
            this.label59.TabIndex = 29;
            this.label59.Text = "Adresi : ";
            // 
            // txtYoneticiEkleTedarikciAdres
            // 
            this.txtYoneticiEkleTedarikciAdres.Location = new System.Drawing.Point(475, 325);
            this.txtYoneticiEkleTedarikciAdres.Name = "txtYoneticiEkleTedarikciAdres";
            this.txtYoneticiEkleTedarikciAdres.Size = new System.Drawing.Size(218, 20);
            this.txtYoneticiEkleTedarikciAdres.TabIndex = 28;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(370, 302);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(99, 13);
            this.label60.TabIndex = 27;
            this.label60.Text = "Telefon Numarası : ";
            // 
            // txtYoneticiEkleTedarikciTelefon
            // 
            this.txtYoneticiEkleTedarikciTelefon.Location = new System.Drawing.Point(475, 299);
            this.txtYoneticiEkleTedarikciTelefon.Name = "txtYoneticiEkleTedarikciTelefon";
            this.txtYoneticiEkleTedarikciTelefon.Size = new System.Drawing.Size(218, 20);
            this.txtYoneticiEkleTedarikciTelefon.TabIndex = 26;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(370, 276);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(78, 13);
            this.label61.TabIndex = 25;
            this.label61.Text = "Tedarikci Adı : ";
            // 
            // txtYoneticiEkleTedarikciAdi
            // 
            this.txtYoneticiEkleTedarikciAdi.Location = new System.Drawing.Point(475, 273);
            this.txtYoneticiEkleTedarikciAdi.Name = "txtYoneticiEkleTedarikciAdi";
            this.txtYoneticiEkleTedarikciAdi.Size = new System.Drawing.Size(218, 20);
            this.txtYoneticiEkleTedarikciAdi.TabIndex = 24;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(370, 250);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(74, 13);
            this.label62.TabIndex = 23;
            this.label62.Text = "Tedarikci ID : ";
            // 
            // txtYoneticiEkleTedarikciId
            // 
            this.txtYoneticiEkleTedarikciId.Location = new System.Drawing.Point(475, 247);
            this.txtYoneticiEkleTedarikciId.Name = "txtYoneticiEkleTedarikciId";
            this.txtYoneticiEkleTedarikciId.Size = new System.Drawing.Size(218, 20);
            this.txtYoneticiEkleTedarikciId.TabIndex = 22;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(9, 381);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(33, 13);
            this.label56.TabIndex = 21;
            this.label56.Text = "İlçe : ";
            // 
            // comboBoxYoneticiGuncelleTedarikciIlce
            // 
            this.comboBoxYoneticiGuncelleTedarikciIlce.FormattingEnabled = true;
            this.comboBoxYoneticiGuncelleTedarikciIlce.Location = new System.Drawing.Point(114, 378);
            this.comboBoxYoneticiGuncelleTedarikciIlce.Name = "comboBoxYoneticiGuncelleTedarikciIlce";
            this.comboBoxYoneticiGuncelleTedarikciIlce.Size = new System.Drawing.Size(218, 21);
            this.comboBoxYoneticiGuncelleTedarikciIlce.TabIndex = 20;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(9, 354);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(21, 13);
            this.label55.TabIndex = 19;
            this.label55.Text = "İl : ";
            this.label55.Click += new System.EventHandler(this.label55_Click);
            // 
            // comboBoxYoneticiGuncelleTedarikciIl
            // 
            this.comboBoxYoneticiGuncelleTedarikciIl.FormattingEnabled = true;
            this.comboBoxYoneticiGuncelleTedarikciIl.Location = new System.Drawing.Point(114, 351);
            this.comboBoxYoneticiGuncelleTedarikciIl.Name = "comboBoxYoneticiGuncelleTedarikciIl";
            this.comboBoxYoneticiGuncelleTedarikciIl.Size = new System.Drawing.Size(218, 21);
            this.comboBoxYoneticiGuncelleTedarikciIl.TabIndex = 18;
            this.comboBoxYoneticiGuncelleTedarikciIl.SelectedIndexChanged += new System.EventHandler(this.comboBoxYoneticiGuncelleTedarikciIl_SelectedIndexChanged);
            this.comboBoxYoneticiGuncelleTedarikciIl.TextChanged += new System.EventHandler(this.comboBoxYoneticiGuncelleTedarikciIl_TextChanged);
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(9, 328);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(45, 13);
            this.label54.TabIndex = 17;
            this.label54.Text = "Adresi : ";
            // 
            // txtYoneticiGuncelleTedarikciAdres
            // 
            this.txtYoneticiGuncelleTedarikciAdres.Location = new System.Drawing.Point(114, 325);
            this.txtYoneticiGuncelleTedarikciAdres.Name = "txtYoneticiGuncelleTedarikciAdres";
            this.txtYoneticiGuncelleTedarikciAdres.Size = new System.Drawing.Size(218, 20);
            this.txtYoneticiGuncelleTedarikciAdres.TabIndex = 16;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(9, 302);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(99, 13);
            this.label53.TabIndex = 15;
            this.label53.Text = "Telefon Numarası : ";
            // 
            // txtYoneticiGuncelleTedarikciTelefon
            // 
            this.txtYoneticiGuncelleTedarikciTelefon.Location = new System.Drawing.Point(114, 299);
            this.txtYoneticiGuncelleTedarikciTelefon.Name = "txtYoneticiGuncelleTedarikciTelefon";
            this.txtYoneticiGuncelleTedarikciTelefon.Size = new System.Drawing.Size(218, 20);
            this.txtYoneticiGuncelleTedarikciTelefon.TabIndex = 14;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(9, 276);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(78, 13);
            this.label52.TabIndex = 13;
            this.label52.Text = "Tedarikci Adı : ";
            // 
            // txtYoneticiGuncelleTedarikciAdi
            // 
            this.txtYoneticiGuncelleTedarikciAdi.Location = new System.Drawing.Point(114, 273);
            this.txtYoneticiGuncelleTedarikciAdi.Name = "txtYoneticiGuncelleTedarikciAdi";
            this.txtYoneticiGuncelleTedarikciAdi.Size = new System.Drawing.Size(218, 20);
            this.txtYoneticiGuncelleTedarikciAdi.TabIndex = 12;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(9, 250);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(74, 13);
            this.label51.TabIndex = 11;
            this.label51.Text = "Tedarikci ID : ";
            // 
            // txtYoneticiGuncelleTedarikciId
            // 
            this.txtYoneticiGuncelleTedarikciId.Location = new System.Drawing.Point(114, 247);
            this.txtYoneticiGuncelleTedarikciId.Name = "txtYoneticiGuncelleTedarikciId";
            this.txtYoneticiGuncelleTedarikciId.ReadOnly = true;
            this.txtYoneticiGuncelleTedarikciId.Size = new System.Drawing.Size(218, 20);
            this.txtYoneticiGuncelleTedarikciId.TabIndex = 10;
            // 
            // dataGridViewYoneticiTedarikciler
            // 
            this.dataGridViewYoneticiTedarikciler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewYoneticiTedarikciler.Location = new System.Drawing.Point(7, 4);
            this.dataGridViewYoneticiTedarikciler.Name = "dataGridViewYoneticiTedarikciler";
            this.dataGridViewYoneticiTedarikciler.ReadOnly = true;
            this.dataGridViewYoneticiTedarikciler.Size = new System.Drawing.Size(686, 237);
            this.dataGridViewYoneticiTedarikciler.TabIndex = 2;
            // 
            // tabPageYoneticiUrunFiyatTakibi
            // 
            this.tabPageYoneticiUrunFiyatTakibi.Controls.Add(this.dataGridViewYoneticiUrunFiyatTakibi);
            this.tabPageYoneticiUrunFiyatTakibi.Location = new System.Drawing.Point(4, 22);
            this.tabPageYoneticiUrunFiyatTakibi.Name = "tabPageYoneticiUrunFiyatTakibi";
            this.tabPageYoneticiUrunFiyatTakibi.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageYoneticiUrunFiyatTakibi.Size = new System.Drawing.Size(702, 556);
            this.tabPageYoneticiUrunFiyatTakibi.TabIndex = 6;
            this.tabPageYoneticiUrunFiyatTakibi.Text = "Ürün Fiyat Takibi";
            this.tabPageYoneticiUrunFiyatTakibi.UseVisualStyleBackColor = true;
            // 
            // dataGridViewYoneticiUrunFiyatTakibi
            // 
            this.dataGridViewYoneticiUrunFiyatTakibi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewYoneticiUrunFiyatTakibi.Location = new System.Drawing.Point(6, 6);
            this.dataGridViewYoneticiUrunFiyatTakibi.Name = "dataGridViewYoneticiUrunFiyatTakibi";
            this.dataGridViewYoneticiUrunFiyatTakibi.ReadOnly = true;
            this.dataGridViewYoneticiUrunFiyatTakibi.Size = new System.Drawing.Size(684, 231);
            this.dataGridViewYoneticiUrunFiyatTakibi.TabIndex = 2;
            // 
            // tabPageYoneticiAyarlar
            // 
            this.tabPageYoneticiAyarlar.Controls.Add(this.label66);
            this.tabPageYoneticiAyarlar.Controls.Add(this.label65);
            this.tabPageYoneticiAyarlar.Controls.Add(this.label64);
            this.tabPageYoneticiAyarlar.Controls.Add(this.label63);
            this.tabPageYoneticiAyarlar.Controls.Add(this.txtYoneticiSifreDegistirTekrar);
            this.tabPageYoneticiAyarlar.Controls.Add(this.txtYoneticiSifreDegistirYeni);
            this.tabPageYoneticiAyarlar.Controls.Add(this.txtYoneticiSifreDegistirMevcut);
            this.tabPageYoneticiAyarlar.Controls.Add(this.btnYoneticiSifreDegistir);
            this.tabPageYoneticiAyarlar.Controls.Add(this.btnYoneticiCikis);
            this.tabPageYoneticiAyarlar.Location = new System.Drawing.Point(4, 22);
            this.tabPageYoneticiAyarlar.Name = "tabPageYoneticiAyarlar";
            this.tabPageYoneticiAyarlar.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageYoneticiAyarlar.Size = new System.Drawing.Size(702, 556);
            this.tabPageYoneticiAyarlar.TabIndex = 5;
            this.tabPageYoneticiAyarlar.Text = "Ayarlar";
            this.tabPageYoneticiAyarlar.UseVisualStyleBackColor = true;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label66.Location = new System.Drawing.Point(292, 152);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(136, 25);
            this.label66.TabIndex = 8;
            this.label66.Text = "Şifre Değiştir";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(191, 247);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(94, 13);
            this.label65.TabIndex = 7;
            this.label65.Text = "Yeni Şifre(tekrar) : ";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(191, 222);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(61, 13);
            this.label64.TabIndex = 6;
            this.label64.Text = "Yeni Şifre : ";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(191, 196);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(76, 13);
            this.label63.TabIndex = 5;
            this.label63.Text = "Mevcut Şifre : ";
            // 
            // txtYoneticiSifreDegistirTekrar
            // 
            this.txtYoneticiSifreDegistirTekrar.Location = new System.Drawing.Point(291, 244);
            this.txtYoneticiSifreDegistirTekrar.Name = "txtYoneticiSifreDegistirTekrar";
            this.txtYoneticiSifreDegistirTekrar.Size = new System.Drawing.Size(137, 20);
            this.txtYoneticiSifreDegistirTekrar.TabIndex = 4;
            this.txtYoneticiSifreDegistirTekrar.UseSystemPasswordChar = true;
            // 
            // txtYoneticiSifreDegistirYeni
            // 
            this.txtYoneticiSifreDegistirYeni.Location = new System.Drawing.Point(291, 219);
            this.txtYoneticiSifreDegistirYeni.Name = "txtYoneticiSifreDegistirYeni";
            this.txtYoneticiSifreDegistirYeni.Size = new System.Drawing.Size(137, 20);
            this.txtYoneticiSifreDegistirYeni.TabIndex = 3;
            this.txtYoneticiSifreDegistirYeni.UseSystemPasswordChar = true;
            // 
            // txtYoneticiSifreDegistirMevcut
            // 
            this.txtYoneticiSifreDegistirMevcut.Location = new System.Drawing.Point(291, 193);
            this.txtYoneticiSifreDegistirMevcut.Name = "txtYoneticiSifreDegistirMevcut";
            this.txtYoneticiSifreDegistirMevcut.Size = new System.Drawing.Size(137, 20);
            this.txtYoneticiSifreDegistirMevcut.TabIndex = 2;
            this.txtYoneticiSifreDegistirMevcut.UseSystemPasswordChar = true;
            // 
            // btnYoneticiSifreDegistir
            // 
            this.btnYoneticiSifreDegistir.Location = new System.Drawing.Point(309, 270);
            this.btnYoneticiSifreDegistir.Name = "btnYoneticiSifreDegistir";
            this.btnYoneticiSifreDegistir.Size = new System.Drawing.Size(99, 23);
            this.btnYoneticiSifreDegistir.TabIndex = 1;
            this.btnYoneticiSifreDegistir.Text = "Şifreyi Değiştir";
            this.btnYoneticiSifreDegistir.UseVisualStyleBackColor = true;
            this.btnYoneticiSifreDegistir.Click += new System.EventHandler(this.btnYoneticiSifreDegistir_Click);
            // 
            // btnYoneticiCikis
            // 
            this.btnYoneticiCikis.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnYoneticiCikis.Location = new System.Drawing.Point(281, 479);
            this.btnYoneticiCikis.Name = "btnYoneticiCikis";
            this.btnYoneticiCikis.Size = new System.Drawing.Size(152, 45);
            this.btnYoneticiCikis.TabIndex = 0;
            this.btnYoneticiCikis.Text = "ÇIKIŞ";
            this.btnYoneticiCikis.UseVisualStyleBackColor = true;
            this.btnYoneticiCikis.Click += new System.EventHandler(this.btnYoneticiCikis_Click);
            // 
            // panelYoneticiGiris
            // 
            this.panelYoneticiGiris.Controls.Add(this.linkLabelYoneticiGirisIptal);
            this.panelYoneticiGiris.Controls.Add(this.label48);
            this.panelYoneticiGiris.Controls.Add(this.label49);
            this.panelYoneticiGiris.Controls.Add(this.label50);
            this.panelYoneticiGiris.Controls.Add(this.txtYoneticiGirisSifre);
            this.panelYoneticiGiris.Controls.Add(this.txtYoneticiGirisKullaniciAdi);
            this.panelYoneticiGiris.Controls.Add(this.btnYoneticiGiris);
            this.panelYoneticiGiris.Location = new System.Drawing.Point(0, 0);
            this.panelYoneticiGiris.Name = "panelYoneticiGiris";
            this.panelYoneticiGiris.Size = new System.Drawing.Size(706, 582);
            this.panelYoneticiGiris.TabIndex = 5;
            // 
            // linkLabelYoneticiGirisIptal
            // 
            this.linkLabelYoneticiGirisIptal.AutoSize = true;
            this.linkLabelYoneticiGirisIptal.Location = new System.Drawing.Point(341, 330);
            this.linkLabelYoneticiGirisIptal.Name = "linkLabelYoneticiGirisIptal";
            this.linkLabelYoneticiGirisIptal.Size = new System.Drawing.Size(27, 13);
            this.linkLabelYoneticiGirisIptal.TabIndex = 119;
            this.linkLabelYoneticiGirisIptal.TabStop = true;
            this.linkLabelYoneticiGirisIptal.Text = "İptal";
            this.linkLabelYoneticiGirisIptal.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelYoneticiGirisIptal_LinkClicked);
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label48.Location = new System.Drawing.Point(276, 200);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(144, 25);
            this.label48.TabIndex = 117;
            this.label48.Text = "Yönetici Girişi";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(172, 271);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(37, 13);
            this.label49.TabIndex = 4;
            this.label49.Text = "Şifre : ";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(172, 245);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(73, 13);
            this.label50.TabIndex = 3;
            this.label50.Text = "Kullanıcı Adı : ";
            // 
            // txtYoneticiGirisSifre
            // 
            this.txtYoneticiGirisSifre.Location = new System.Drawing.Point(253, 268);
            this.txtYoneticiGirisSifre.Name = "txtYoneticiGirisSifre";
            this.txtYoneticiGirisSifre.Size = new System.Drawing.Size(200, 20);
            this.txtYoneticiGirisSifre.TabIndex = 2;
            this.txtYoneticiGirisSifre.UseSystemPasswordChar = true;
            // 
            // txtYoneticiGirisKullaniciAdi
            // 
            this.txtYoneticiGirisKullaniciAdi.Location = new System.Drawing.Point(253, 242);
            this.txtYoneticiGirisKullaniciAdi.Name = "txtYoneticiGirisKullaniciAdi";
            this.txtYoneticiGirisKullaniciAdi.Size = new System.Drawing.Size(200, 20);
            this.txtYoneticiGirisKullaniciAdi.TabIndex = 1;
            // 
            // btnYoneticiGiris
            // 
            this.btnYoneticiGiris.Location = new System.Drawing.Point(297, 297);
            this.btnYoneticiGiris.Name = "btnYoneticiGiris";
            this.btnYoneticiGiris.Size = new System.Drawing.Size(118, 23);
            this.btnYoneticiGiris.TabIndex = 0;
            this.btnYoneticiGiris.Text = "GİRİŞ";
            this.btnYoneticiGiris.UseVisualStyleBackColor = true;
            this.btnYoneticiGiris.Click += new System.EventHandler(this.btnYoneticiGiris_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(708, 581);
            this.Controls.Add(this.tabControlYoneticiGirisi);
            this.Controls.Add(this.tabControlKullaniciGirisi);
            this.Controls.Add(this.sifremiUnuttumPanel);
            this.Controls.Add(this.panelKayitOl);
            this.Controls.Add(this.panelYoneticiGiris);
            this.Controls.Add(this.PanelKullaniciGirisi);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControlKullaniciGirisi.ResumeLayout(false);
            this.tabPageUrunler.ResumeLayout(false);
            this.tabPageUrunler.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewKullaniciUrunler)).EndInit();
            this.tabPageSiparislerim.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewKullaniciSiparislerim)).EndInit();
            this.tabPageAdreslerim.ResumeLayout(false);
            this.tabPageAdreslerim.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewKullaniciAdreslerim)).EndInit();
            this.tabPageKullaniciAyarlar.ResumeLayout(false);
            this.tabPageKullaniciAyarlar.PerformLayout();
            this.PanelKullaniciGirisi.ResumeLayout(false);
            this.PanelKullaniciGirisi.PerformLayout();
            this.sifremiUnuttumPanel.ResumeLayout(false);
            this.sifremiUnuttumPanel.PerformLayout();
            this.panelKayitOl.ResumeLayout(false);
            this.panelKayitOl.PerformLayout();
            this.tabControlYoneticiGirisi.ResumeLayout(false);
            this.tabPageYoneticiKullanicilarVeSiparisler.ResumeLayout(false);
            this.tabPageYoneticiKullanicilarVeSiparisler.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewYoneticiSiparisler)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewYoneticiKullanicilar)).EndInit();
            this.tabPageYoneticiUrunler.ResumeLayout(false);
            this.tabPageYoneticiUrunler.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewYoneticiUrunler)).EndInit();
            this.tabPageKargoVeKategori.ResumeLayout(false);
            this.tabPageKargoVeKategori.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewYoneticiKategori)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewYoneticiKargo)).EndInit();
            this.tabPageYoneticiSilinenler.ResumeLayout(false);
            this.tabPageYoneticiSilinenler.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSilinenKargolar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSilinenAdresler)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSilinenKullanicilar)).EndInit();
            this.tabPageYoneticiGirisiTedarikciler.ResumeLayout(false);
            this.tabPageYoneticiGirisiTedarikciler.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewYoneticiTedarikciler)).EndInit();
            this.tabPageYoneticiUrunFiyatTakibi.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewYoneticiUrunFiyatTakibi)).EndInit();
            this.tabPageYoneticiAyarlar.ResumeLayout(false);
            this.tabPageYoneticiAyarlar.PerformLayout();
            this.panelYoneticiGiris.ResumeLayout(false);
            this.panelYoneticiGiris.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlKullaniciGirisi;
        private System.Windows.Forms.TabPage tabPageSiparislerim;
        private System.Windows.Forms.TabPage tabPageUrunler;
        private System.Windows.Forms.Panel PanelKullaniciGirisi;
        private System.Windows.Forms.TextBox txtGirisSifre;
        private System.Windows.Forms.TextBox txtGirisKullaniciAdi;
        private System.Windows.Forms.Button btnUyeGiris;
        private System.Windows.Forms.LinkLabel linkSifremiUnuttum;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel sifremiUnuttumPanel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtSifreDegistirYeniSifreTekrar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtSifreDegistirYeniSifre;
        private System.Windows.Forms.ComboBox comboBoxSifreDegistirGuvenlikSorusu;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtSifreDegistirGuvenlikSorusuCevabi;
        private System.Windows.Forms.Button btnSifreDegistir;
        private System.Windows.Forms.LinkLabel linkKayitOl;
        private System.Windows.Forms.Panel panelKayitOl;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.RadioButton kayitOlRadioButtonErkek;
        private System.Windows.Forms.RadioButton kayitOlRadioButtonKadin;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DateTimePicker kayitOlDogumTarihi;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtKayitOlTelefon;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtKayitOlSifreTekrar;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtKayitOlSoyisim;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtKayitOlisim;
        private System.Windows.Forms.LinkLabel linkLabelKayitOlIptal;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtKayitOlSifre;
        private System.Windows.Forms.TextBox txtKayitOlKullaniciAdi;
        private System.Windows.Forms.Button btnKayitOl;
        private System.Windows.Forms.ComboBox comboBoxKayitOlGuvenlikSorusu;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtKayitOlGuvenlikCevap;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.LinkLabel linkLabelSifreDegistirIptal;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtSifreDegistirKullaniciAdi;
        private System.Windows.Forms.TabPage tabPageAdreslerim;
        private System.Windows.Forms.TabControl tabControlYoneticiGirisi;
        private System.Windows.Forms.TabPage tabPageYoneticiKullanicilarVeSiparisler;
        private System.Windows.Forms.TabPage tabPageYoneticiUrunler;
        private System.Windows.Forms.ListBox listBoxYoneticiTedarikciler;
        private System.Windows.Forms.ListBox listBoxYoneticiKategoriler;
        private System.Windows.Forms.Label labelUrunGuncelleTedarikciler;
        private System.Windows.Forms.Label labelUrunGuncelleKategoriler;
        private System.Windows.Forms.Button btnYoneticiUrunGuncelle;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtYoneticiUrunGuncelleTedarikciId;
        private System.Windows.Forms.TextBox txtYoneticiUrunGuncelleSiparisAdedi;
        private System.Windows.Forms.TextBox txtYoneticiUrunGuncelleStokAdedi;
        private System.Windows.Forms.TextBox txtYoneticiUrunGuncelleBirimFiyati;
        private System.Windows.Forms.TextBox txtYoneticiUrunGuncelleKategoriId;
        private System.Windows.Forms.TextBox txtYoneticiUrunGuncelleAdi;
        private System.Windows.Forms.TextBox txtYoneticiUrunGuncelleId;
        private System.Windows.Forms.DataGridView dataGridViewYoneticiUrunler;
        private System.Windows.Forms.TabPage tabPageYoneticiSilinenler;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.DataGridView dataGridViewSilinenKargolar;
        private System.Windows.Forms.DataGridView dataGridViewSilinenAdresler;
        private System.Windows.Forms.DataGridView dataGridViewSilinenKullanicilar;
        private System.Windows.Forms.Button btnYoneticiUrunEkle;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtYoneticiUrunEkleTedarikciId;
        private System.Windows.Forms.TextBox txtYoneticiUrunEkleSiparisAdedi;
        private System.Windows.Forms.TextBox txtYoneticiUrunEkleStokAdedi;
        private System.Windows.Forms.TextBox txtYoneticiUrunEkleBirimFiyati;
        private System.Windows.Forms.TextBox txtYoneticiUrunEkleKategoriId;
        private System.Windows.Forms.TextBox txtYoneticiUrunEkleAdi;
        private System.Windows.Forms.TextBox txtYoneticiUrunEkleId;
        private System.Windows.Forms.Button btnYoneticiUrunSil;
        private System.Windows.Forms.DataGridView dataGridViewYoneticiKullanicilar;
        private System.Windows.Forms.TextBox txtYoneticiSilinecekKullanici;
        private System.Windows.Forms.Button btnYoneticiKullaniciSil;
        private System.Windows.Forms.TabPage tabPageKargoVeKategori;
        private System.Windows.Forms.DataGridView dataGridViewYoneticiKargo;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtYoneticiGuncelleKargoAdi;
        private System.Windows.Forms.TextBox txtYoneticiGuncelleKargoId;
        private System.Windows.Forms.Button btnYoneticiKargoEkle;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox txtYoneticiEkleKargoAdi;
        private System.Windows.Forms.TextBox txtYoneticiEkleKargoId;
        private System.Windows.Forms.Button btnYoneticiKargoSil;
        private System.Windows.Forms.Button btnYoneticiKargoGuncelle;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox txtYoneticiEkleKategoriAciklama;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox txtYoneticiGuncelleKategoriAciklama;
        private System.Windows.Forms.Button btnYoneticiKategoriEkle;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox txtYoneticiEkleKategoriAdi;
        private System.Windows.Forms.TextBox txtYoneticiEkleKategoriId;
        private System.Windows.Forms.Button btnYoneticiKategoriSil;
        private System.Windows.Forms.Button btnYoneticiKategoriGuncelle;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox txtYoneticiGuncelleKategoriAdi;
        private System.Windows.Forms.TextBox txtYoneticiGuncelleKategoriId;
        private System.Windows.Forms.DataGridView dataGridViewYoneticiKategori;
        private System.Windows.Forms.LinkLabel linkLabelKullaniciGirisiToYoneticiGirisi;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Panel panelYoneticiGiris;
        private System.Windows.Forms.LinkLabel linkLabelYoneticiGirisIptal;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox txtYoneticiGirisSifre;
        private System.Windows.Forms.TextBox txtYoneticiGirisKullaniciAdi;
        private System.Windows.Forms.Button btnYoneticiGiris;
        private System.Windows.Forms.DataGridView dataGridViewYoneticiSiparisler;
        private System.Windows.Forms.TabPage tabPageYoneticiGirisiTedarikciler;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox txtYoneticiGuncelleTedarikciId;
        private System.Windows.Forms.DataGridView dataGridViewYoneticiTedarikciler;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.ComboBox comboBoxYoneticiGuncelleTedarikciIl;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox txtYoneticiGuncelleTedarikciAdres;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox txtYoneticiGuncelleTedarikciTelefon;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox txtYoneticiGuncelleTedarikciAdi;
        private System.Windows.Forms.Button btnYoneticiTedarikciEkle;
        private System.Windows.Forms.Button btnYoneticiTedarikciSil;
        private System.Windows.Forms.Button btnYoneticiTedarikciGuncelle;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.ComboBox comboBoxYoneticiEkleTedarikciIlce;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.ComboBox comboBoxYoneticiEkleTedarikciIl;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox txtYoneticiEkleTedarikciAdres;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox txtYoneticiEkleTedarikciTelefon;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox txtYoneticiEkleTedarikciAdi;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox txtYoneticiEkleTedarikciId;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.ComboBox comboBoxYoneticiGuncelleTedarikciIlce;
        private System.Windows.Forms.TabPage tabPageYoneticiAyarlar;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox txtYoneticiSifreDegistirTekrar;
        private System.Windows.Forms.TextBox txtYoneticiSifreDegistirYeni;
        private System.Windows.Forms.TextBox txtYoneticiSifreDegistirMevcut;
        private System.Windows.Forms.Button btnYoneticiSifreDegistir;
        private System.Windows.Forms.Button btnYoneticiCikis;
        private System.Windows.Forms.TabPage tabPageKullaniciAyarlar;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TextBox txtKullaniciSifreDegistirTekrar;
        private System.Windows.Forms.TextBox txtKullaniciSifreDegistirYeni;
        private System.Windows.Forms.TextBox txtKullaniciSifreDegistirMevcut;
        private System.Windows.Forms.Button btnKullaniciSifreDegistir;
        private System.Windows.Forms.DataGridView dataGridViewKullaniciUrunler;
        private System.Windows.Forms.Label labelSiparisMiktari;
        private System.Windows.Forms.Label labelStokDurumu;
        private System.Windows.Forms.Label labelUrunFiyati;
        private System.Windows.Forms.Label labelUrunAdi;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Button btnKullaniciUrunSatinAl;
        private System.Windows.Forms.ComboBox comboBoxKullaniciUrunlerAdres;
        private System.Windows.Forms.Label labelUrunId;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.ComboBox comboBoxKullaniciUrunlerKargo;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.DataGridView dataGridViewKullaniciSiparislerim;
        private System.Windows.Forms.DataGridView dataGridViewKullaniciAdreslerim;
        private System.Windows.Forms.TextBox txtKullaniciAdresSilAdresNo;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.TextBox txtKullaniciAdresSilKulNo;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Button btnKullaniciAdresSil;
        private System.Windows.Forms.Button btnKullaniciAdresEkle;
        private System.Windows.Forms.TextBox txtKullaniciAdresEkleAdres;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.TextBox txtKullaniciAdresEkleIlceNo;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.TextBox txtKullaniciAdresEklePlakaNo;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.TextBox txtKullaniciAdresEkleAdresNo;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.TabPage tabPageYoneticiUrunFiyatTakibi;
        private System.Windows.Forms.DataGridView dataGridViewYoneticiUrunFiyatTakibi;
    }
}

