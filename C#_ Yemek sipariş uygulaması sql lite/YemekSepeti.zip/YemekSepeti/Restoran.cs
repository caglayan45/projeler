﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YemekSepeti
{
    public class Restoran
    {
        public List<Menuler> menus = new List<Menuler>();

        //restoran nesnesinin constructor ı
        public Restoran(int id, string name, string phone)
        {
            this.id = id;
            this.name = name;
            this.phone = phone;
        }

        //restorana menü ekler
        public void AddMenu(int id,string name, int price)
        {
            this.menus.Add(new Menuler(id, name, price));
        }

        public int id
        {
            get; set;
        }

        public string name
        {
            get; set;
        }

        public string phone
        {
            get; set;
        }

    }
}
