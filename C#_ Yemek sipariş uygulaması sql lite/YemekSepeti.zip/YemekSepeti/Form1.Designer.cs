﻿namespace YemekSepeti
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelGirisEkrani = new System.Windows.Forms.Panel();
            this.linkLabelKayitOl = new System.Windows.Forms.LinkLabel();
            this.btnGirisRestoran = new System.Windows.Forms.Button();
            this.txtGirisSifre = new System.Windows.Forms.TextBox();
            this.txtGirisKullaniciAdi = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btnGirisKullanici = new System.Windows.Forms.Button();
            this.panelKullaniciEkrani = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.btnKullaniciCikis = new System.Windows.Forms.Button();
            this.panelRestoranEkrani = new System.Windows.Forms.Panel();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnRestoranCikis = new System.Windows.Forms.Button();
            this.btnRestoranMenuSil = new System.Windows.Forms.Button();
            this.txtRestoranGuncelleMenuFiyati = new System.Windows.Forms.TextBox();
            this.txtRestoranGuncelleMenuAdi = new System.Windows.Forms.TextBox();
            this.btnRestoranMenuGuncelle = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.dataGridViewRestoranMenuler = new System.Windows.Forms.DataGridView();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnRestoranMenuEkle = new System.Windows.Forms.Button();
            this.txtRestoranMenuFiyati = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtRestoranMenuAdi = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnRestoranSiparisGuncelle = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.comboBoxRestoranSiparisDurumu = new System.Windows.Forms.ComboBox();
            this.comboBoxRestoranSiparis = new System.Windows.Forms.ComboBox();
            this.dataGridViewSiparisler = new System.Windows.Forms.DataGridView();
            this.panelKayitOl = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.linkLabelKayitOlGeriDon = new System.Windows.Forms.LinkLabel();
            this.label8 = new System.Windows.Forms.Label();
            this.txtRestoranSifre = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtRestoranKulAdi = new System.Windows.Forms.TextBox();
            this.btnRestoranEkle = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.txtRestoranTelefon = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtRestoranAdi = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnKullaniciEkle = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.txtKullaniciAdres = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtKullaniciTelefon = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtKullaniciSoyadi = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtKullaniciAdi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtKullaniciSifre = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtKullaniciKulAdi = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtKullaniciTC = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.panelRestoranIci = new System.Windows.Forms.Panel();
            this.btnSepettenCikar = new System.Windows.Forms.Button();
            this.btnSiparisVer = new System.Windows.Forms.Button();
            this.checkedListBoxSepet = new System.Windows.Forms.CheckedListBox();
            this.txtRestoranIciToplamUcret = new System.Windows.Forms.TextBox();
            this.btnCikisMenuler = new System.Windows.Forms.Button();
            this.panelGirisEkrani.SuspendLayout();
            this.panelKullaniciEkrani.SuspendLayout();
            this.panelRestoranEkrani.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRestoranMenuler)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSiparisler)).BeginInit();
            this.panelKayitOl.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panelRestoranIci.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelGirisEkrani
            // 
            this.panelGirisEkrani.Controls.Add(this.linkLabelKayitOl);
            this.panelGirisEkrani.Controls.Add(this.btnGirisRestoran);
            this.panelGirisEkrani.Controls.Add(this.txtGirisSifre);
            this.panelGirisEkrani.Controls.Add(this.txtGirisKullaniciAdi);
            this.panelGirisEkrani.Controls.Add(this.label12);
            this.panelGirisEkrani.Controls.Add(this.label11);
            this.panelGirisEkrani.Controls.Add(this.btnGirisKullanici);
            this.panelGirisEkrani.Location = new System.Drawing.Point(12, 12);
            this.panelGirisEkrani.Name = "panelGirisEkrani";
            this.panelGirisEkrani.Size = new System.Drawing.Size(776, 426);
            this.panelGirisEkrani.TabIndex = 0;
            // 
            // linkLabelKayitOl
            // 
            this.linkLabelKayitOl.AutoSize = true;
            this.linkLabelKayitOl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.linkLabelKayitOl.Location = new System.Drawing.Point(380, 278);
            this.linkLabelKayitOl.Name = "linkLabelKayitOl";
            this.linkLabelKayitOl.Size = new System.Drawing.Size(65, 17);
            this.linkLabelKayitOl.TabIndex = 6;
            this.linkLabelKayitOl.TabStop = true;
            this.linkLabelKayitOl.Text = "Sign Up";
            this.linkLabelKayitOl.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelKayitOl_LinkClicked);
            // 
            // btnGirisRestoran
            // 
            this.btnGirisRestoran.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnGirisRestoran.Location = new System.Drawing.Point(323, 242);
            this.btnGirisRestoran.Name = "btnGirisRestoran";
            this.btnGirisRestoran.Size = new System.Drawing.Size(185, 33);
            this.btnGirisRestoran.TabIndex = 5;
            this.btnGirisRestoran.Text = "Login as Restaurant";
            this.btnGirisRestoran.UseVisualStyleBackColor = true;
            this.btnGirisRestoran.Click += new System.EventHandler(this.btnGirisRestoran_Click);
            // 
            // txtGirisSifre
            // 
            this.txtGirisSifre.Location = new System.Drawing.Point(323, 177);
            this.txtGirisSifre.Name = "txtGirisSifre";
            this.txtGirisSifre.Size = new System.Drawing.Size(185, 20);
            this.txtGirisSifre.TabIndex = 4;
            this.txtGirisSifre.UseSystemPasswordChar = true;
            // 
            // txtGirisKullaniciAdi
            // 
            this.txtGirisKullaniciAdi.Location = new System.Drawing.Point(323, 151);
            this.txtGirisKullaniciAdi.Name = "txtGirisKullaniciAdi";
            this.txtGirisKullaniciAdi.Size = new System.Drawing.Size(185, 20);
            this.txtGirisKullaniciAdi.TabIndex = 3;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.Location = new System.Drawing.Point(225, 178);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(81, 15);
            this.label12.TabIndex = 2;
            this.label12.Text = "Password : ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.Location = new System.Drawing.Point(225, 152);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(85, 15);
            this.label11.TabIndex = 1;
            this.label11.Text = "Username : ";
            // 
            // btnGirisKullanici
            // 
            this.btnGirisKullanici.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnGirisKullanici.Location = new System.Drawing.Point(323, 203);
            this.btnGirisKullanici.Name = "btnGirisKullanici";
            this.btnGirisKullanici.Size = new System.Drawing.Size(185, 33);
            this.btnGirisKullanici.TabIndex = 0;
            this.btnGirisKullanici.Text = "Login as User";
            this.btnGirisKullanici.UseVisualStyleBackColor = true;
            this.btnGirisKullanici.Click += new System.EventHandler(this.btnGirisKullanici_Click);
            // 
            // panelKullaniciEkrani
            // 
            this.panelKullaniciEkrani.Controls.Add(this.label21);
            this.panelKullaniciEkrani.Controls.Add(this.btnKullaniciCikis);
            this.panelKullaniciEkrani.Location = new System.Drawing.Point(12, 12);
            this.panelKullaniciEkrani.Name = "panelKullaniciEkrani";
            this.panelKullaniciEkrani.Size = new System.Drawing.Size(776, 426);
            this.panelKullaniciEkrani.TabIndex = 1;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label21.Location = new System.Drawing.Point(308, 1);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(161, 25);
            this.label21.TabIndex = 1;
            this.label21.Text = "RESTAURANTS";
            // 
            // btnKullaniciCikis
            // 
            this.btnKullaniciCikis.Location = new System.Drawing.Point(698, 401);
            this.btnKullaniciCikis.Name = "btnKullaniciCikis";
            this.btnKullaniciCikis.Size = new System.Drawing.Size(75, 23);
            this.btnKullaniciCikis.TabIndex = 0;
            this.btnKullaniciCikis.Text = "Logout";
            this.btnKullaniciCikis.UseVisualStyleBackColor = true;
            this.btnKullaniciCikis.Click += new System.EventHandler(this.btnKullaniciCikis_Click);
            // 
            // panelRestoranEkrani
            // 
            this.panelRestoranEkrani.Controls.Add(this.groupBox5);
            this.panelRestoranEkrani.Controls.Add(this.dataGridViewRestoranMenuler);
            this.panelRestoranEkrani.Controls.Add(this.groupBox4);
            this.panelRestoranEkrani.Controls.Add(this.groupBox3);
            this.panelRestoranEkrani.Controls.Add(this.dataGridViewSiparisler);
            this.panelRestoranEkrani.Location = new System.Drawing.Point(12, 12);
            this.panelRestoranEkrani.Name = "panelRestoranEkrani";
            this.panelRestoranEkrani.Size = new System.Drawing.Size(776, 426);
            this.panelRestoranEkrani.TabIndex = 2;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnRestoranCikis);
            this.groupBox5.Controls.Add(this.btnRestoranMenuSil);
            this.groupBox5.Controls.Add(this.txtRestoranGuncelleMenuFiyati);
            this.groupBox5.Controls.Add(this.txtRestoranGuncelleMenuAdi);
            this.groupBox5.Controls.Add(this.btnRestoranMenuGuncelle);
            this.groupBox5.Controls.Add(this.label18);
            this.groupBox5.Controls.Add(this.label19);
            this.groupBox5.Location = new System.Drawing.Point(576, 216);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(191, 201);
            this.groupBox5.TabIndex = 4;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Update/Delete Menu";
            // 
            // btnRestoranCikis
            // 
            this.btnRestoranCikis.Location = new System.Drawing.Point(116, 178);
            this.btnRestoranCikis.Name = "btnRestoranCikis";
            this.btnRestoranCikis.Size = new System.Drawing.Size(75, 23);
            this.btnRestoranCikis.TabIndex = 8;
            this.btnRestoranCikis.Text = "Logout";
            this.btnRestoranCikis.UseVisualStyleBackColor = true;
            this.btnRestoranCikis.Click += new System.EventHandler(this.btnRestoranCikis_Click);
            // 
            // btnRestoranMenuSil
            // 
            this.btnRestoranMenuSil.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnRestoranMenuSil.Location = new System.Drawing.Point(67, 105);
            this.btnRestoranMenuSil.Name = "btnRestoranMenuSil";
            this.btnRestoranMenuSil.Size = new System.Drawing.Size(118, 23);
            this.btnRestoranMenuSil.TabIndex = 7;
            this.btnRestoranMenuSil.Text = "DELETE";
            this.btnRestoranMenuSil.UseVisualStyleBackColor = true;
            this.btnRestoranMenuSil.Click += new System.EventHandler(this.btnRestoranMenuSil_Click);
            // 
            // txtRestoranGuncelleMenuFiyati
            // 
            this.txtRestoranGuncelleMenuFiyati.Location = new System.Drawing.Point(67, 49);
            this.txtRestoranGuncelleMenuFiyati.Name = "txtRestoranGuncelleMenuFiyati";
            this.txtRestoranGuncelleMenuFiyati.Size = new System.Drawing.Size(118, 20);
            this.txtRestoranGuncelleMenuFiyati.TabIndex = 6;
            // 
            // txtRestoranGuncelleMenuAdi
            // 
            this.txtRestoranGuncelleMenuAdi.Location = new System.Drawing.Point(67, 23);
            this.txtRestoranGuncelleMenuAdi.Name = "txtRestoranGuncelleMenuAdi";
            this.txtRestoranGuncelleMenuAdi.Size = new System.Drawing.Size(118, 20);
            this.txtRestoranGuncelleMenuAdi.TabIndex = 5;
            // 
            // btnRestoranMenuGuncelle
            // 
            this.btnRestoranMenuGuncelle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnRestoranMenuGuncelle.Location = new System.Drawing.Point(67, 76);
            this.btnRestoranMenuGuncelle.Name = "btnRestoranMenuGuncelle";
            this.btnRestoranMenuGuncelle.Size = new System.Drawing.Size(118, 23);
            this.btnRestoranMenuGuncelle.TabIndex = 4;
            this.btnRestoranMenuGuncelle.Text = "UPDATE";
            this.btnRestoranMenuGuncelle.UseVisualStyleBackColor = true;
            this.btnRestoranMenuGuncelle.Click += new System.EventHandler(this.btnRestoranMenuGuncelle_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label18.Location = new System.Drawing.Point(6, 49);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(52, 15);
            this.label18.TabIndex = 3;
            this.label18.Text = "Price : ";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label19.Location = new System.Drawing.Point(6, 22);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(55, 15);
            this.label19.TabIndex = 2;
            this.label19.Text = "Menu : ";
            // 
            // dataGridViewRestoranMenuler
            // 
            this.dataGridViewRestoranMenuler.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewRestoranMenuler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewRestoranMenuler.Location = new System.Drawing.Point(392, 216);
            this.dataGridViewRestoranMenuler.Name = "dataGridViewRestoranMenuler";
            this.dataGridViewRestoranMenuler.ReadOnly = true;
            this.dataGridViewRestoranMenuler.Size = new System.Drawing.Size(178, 201);
            this.dataGridViewRestoranMenuler.TabIndex = 3;
            this.dataGridViewRestoranMenuler.SelectionChanged += new System.EventHandler(this.dataGridViewRestoranMenuler_SelectionChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnRestoranMenuEkle);
            this.groupBox4.Controls.Add(this.txtRestoranMenuFiyati);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.txtRestoranMenuAdi);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Location = new System.Drawing.Point(392, 105);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(375, 105);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Add Menu";
            // 
            // btnRestoranMenuEkle
            // 
            this.btnRestoranMenuEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnRestoranMenuEkle.Location = new System.Drawing.Point(109, 71);
            this.btnRestoranMenuEkle.Name = "btnRestoranMenuEkle";
            this.btnRestoranMenuEkle.Size = new System.Drawing.Size(184, 23);
            this.btnRestoranMenuEkle.TabIndex = 7;
            this.btnRestoranMenuEkle.Text = "INSERT";
            this.btnRestoranMenuEkle.UseVisualStyleBackColor = true;
            this.btnRestoranMenuEkle.Click += new System.EventHandler(this.btnRestoranMenuEkle_Click);
            // 
            // txtRestoranMenuFiyati
            // 
            this.txtRestoranMenuFiyati.Location = new System.Drawing.Point(109, 43);
            this.txtRestoranMenuFiyati.Name = "txtRestoranMenuFiyati";
            this.txtRestoranMenuFiyati.Size = new System.Drawing.Size(184, 20);
            this.txtRestoranMenuFiyati.TabIndex = 6;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label17.Location = new System.Drawing.Point(6, 47);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(52, 15);
            this.label17.TabIndex = 5;
            this.label17.Text = "Price : ";
            // 
            // txtRestoranMenuAdi
            // 
            this.txtRestoranMenuAdi.Location = new System.Drawing.Point(109, 17);
            this.txtRestoranMenuAdi.Name = "txtRestoranMenuAdi";
            this.txtRestoranMenuAdi.Size = new System.Drawing.Size(184, 20);
            this.txtRestoranMenuAdi.TabIndex = 4;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label16.Location = new System.Drawing.Point(6, 21);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(97, 15);
            this.label16.TabIndex = 3;
            this.label16.Text = "Menu Name : ";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnRestoranSiparisGuncelle);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.comboBoxRestoranSiparisDurumu);
            this.groupBox3.Controls.Add(this.comboBoxRestoranSiparis);
            this.groupBox3.Location = new System.Drawing.Point(392, 10);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(375, 89);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Update Order Status";
            // 
            // btnRestoranSiparisGuncelle
            // 
            this.btnRestoranSiparisGuncelle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnRestoranSiparisGuncelle.Location = new System.Drawing.Point(221, 44);
            this.btnRestoranSiparisGuncelle.Name = "btnRestoranSiparisGuncelle";
            this.btnRestoranSiparisGuncelle.Size = new System.Drawing.Size(124, 23);
            this.btnRestoranSiparisGuncelle.TabIndex = 4;
            this.btnRestoranSiparisGuncelle.Text = "UPDATE";
            this.btnRestoranSiparisGuncelle.UseVisualStyleBackColor = true;
            this.btnRestoranSiparisGuncelle.Click += new System.EventHandler(this.btnRestoranSiparisGuncelle_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label15.Location = new System.Drawing.Point(6, 49);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(59, 15);
            this.label15.TabIndex = 3;
            this.label15.Text = "Status : ";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.Location = new System.Drawing.Point(6, 22);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(55, 15);
            this.label14.TabIndex = 2;
            this.label14.Text = "Order : ";
            // 
            // comboBoxRestoranSiparisDurumu
            // 
            this.comboBoxRestoranSiparisDurumu.FormattingEnabled = true;
            this.comboBoxRestoranSiparisDurumu.Items.AddRange(new object[] {
            "Preparing",
            "On the way",
            "Was delivered"});
            this.comboBoxRestoranSiparisDurumu.Location = new System.Drawing.Point(76, 46);
            this.comboBoxRestoranSiparisDurumu.Name = "comboBoxRestoranSiparisDurumu";
            this.comboBoxRestoranSiparisDurumu.Size = new System.Drawing.Size(139, 21);
            this.comboBoxRestoranSiparisDurumu.TabIndex = 1;
            // 
            // comboBoxRestoranSiparis
            // 
            this.comboBoxRestoranSiparis.FormattingEnabled = true;
            this.comboBoxRestoranSiparis.Location = new System.Drawing.Point(76, 19);
            this.comboBoxRestoranSiparis.Name = "comboBoxRestoranSiparis";
            this.comboBoxRestoranSiparis.Size = new System.Drawing.Size(269, 21);
            this.comboBoxRestoranSiparis.TabIndex = 0;
            // 
            // dataGridViewSiparisler
            // 
            this.dataGridViewSiparisler.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewSiparisler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSiparisler.Location = new System.Drawing.Point(10, 10);
            this.dataGridViewSiparisler.Name = "dataGridViewSiparisler";
            this.dataGridViewSiparisler.ReadOnly = true;
            this.dataGridViewSiparisler.Size = new System.Drawing.Size(376, 407);
            this.dataGridViewSiparisler.TabIndex = 0;
            // 
            // panelKayitOl
            // 
            this.panelKayitOl.Controls.Add(this.groupBox2);
            this.panelKayitOl.Controls.Add(this.groupBox1);
            this.panelKayitOl.Location = new System.Drawing.Point(12, 12);
            this.panelKayitOl.Name = "panelKayitOl";
            this.panelKayitOl.Size = new System.Drawing.Size(776, 426);
            this.panelKayitOl.TabIndex = 3;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.linkLabelKayitOlGeriDon);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.txtRestoranSifre);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.txtRestoranKulAdi);
            this.groupBox2.Controls.Add(this.btnRestoranEkle);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.txtRestoranTelefon);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txtRestoranAdi);
            this.groupBox2.Location = new System.Drawing.Point(392, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(381, 419);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Restaurant Registration";
            // 
            // linkLabelKayitOlGeriDon
            // 
            this.linkLabelKayitOlGeriDon.AutoSize = true;
            this.linkLabelKayitOlGeriDon.Location = new System.Drawing.Point(267, 402);
            this.linkLabelKayitOlGeriDon.Name = "linkLabelKayitOlGeriDon";
            this.linkLabelKayitOlGeriDon.Size = new System.Drawing.Size(104, 13);
            this.linkLabelKayitOlGeriDon.TabIndex = 19;
            this.linkLabelKayitOlGeriDon.TabStop = true;
            this.linkLabelKayitOlGeriDon.Text = "Back to login screen";
            this.linkLabelKayitOlGeriDon.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelKayitOlGeriDon_LinkClicked);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(15, 149);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 15);
            this.label8.TabIndex = 18;
            this.label8.Text = "Password : ";
            // 
            // txtRestoranSifre
            // 
            this.txtRestoranSifre.Location = new System.Drawing.Point(133, 148);
            this.txtRestoranSifre.Name = "txtRestoranSifre";
            this.txtRestoranSifre.Size = new System.Drawing.Size(186, 20);
            this.txtRestoranSifre.TabIndex = 17;
            this.txtRestoranSifre.UseSystemPasswordChar = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.Location = new System.Drawing.Point(15, 123);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 15);
            this.label10.TabIndex = 16;
            this.label10.Text = "Username : ";
            // 
            // txtRestoranKulAdi
            // 
            this.txtRestoranKulAdi.Location = new System.Drawing.Point(133, 122);
            this.txtRestoranKulAdi.Name = "txtRestoranKulAdi";
            this.txtRestoranKulAdi.Size = new System.Drawing.Size(186, 20);
            this.txtRestoranKulAdi.TabIndex = 15;
            // 
            // btnRestoranEkle
            // 
            this.btnRestoranEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnRestoranEkle.Location = new System.Drawing.Point(133, 226);
            this.btnRestoranEkle.Name = "btnRestoranEkle";
            this.btnRestoranEkle.Size = new System.Drawing.Size(186, 36);
            this.btnRestoranEkle.TabIndex = 14;
            this.btnRestoranEkle.Text = "INSERT";
            this.btnRestoranEkle.UseVisualStyleBackColor = true;
            this.btnRestoranEkle.Click += new System.EventHandler(this.btnRestoranEkle_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.Location = new System.Drawing.Point(15, 201);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(115, 15);
            this.label9.TabIndex = 11;
            this.label9.Text = "Phone Number : ";
            // 
            // txtRestoranTelefon
            // 
            this.txtRestoranTelefon.Location = new System.Drawing.Point(133, 200);
            this.txtRestoranTelefon.Name = "txtRestoranTelefon";
            this.txtRestoranTelefon.Size = new System.Drawing.Size(186, 20);
            this.txtRestoranTelefon.TabIndex = 10;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.Location = new System.Drawing.Point(15, 175);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(57, 15);
            this.label13.TabIndex = 3;
            this.label13.Text = "Name : ";
            // 
            // txtRestoranAdi
            // 
            this.txtRestoranAdi.Location = new System.Drawing.Point(133, 174);
            this.txtRestoranAdi.Name = "txtRestoranAdi";
            this.txtRestoranAdi.Size = new System.Drawing.Size(186, 20);
            this.txtRestoranAdi.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnKullaniciEkle);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtKullaniciAdres);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtKullaniciTelefon);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtKullaniciSoyadi);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtKullaniciAdi);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtKullaniciSifre);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtKullaniciKulAdi);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtKullaniciTC);
            this.groupBox1.Location = new System.Drawing.Point(4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(382, 419);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "User Registration";
            // 
            // btnKullaniciEkle
            // 
            this.btnKullaniciEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKullaniciEkle.Location = new System.Drawing.Point(151, 275);
            this.btnKullaniciEkle.Name = "btnKullaniciEkle";
            this.btnKullaniciEkle.Size = new System.Drawing.Size(186, 36);
            this.btnKullaniciEkle.TabIndex = 14;
            this.btnKullaniciEkle.Text = "INSERT";
            this.btnKullaniciEkle.UseVisualStyleBackColor = true;
            this.btnKullaniciEkle.Click += new System.EventHandler(this.btnKullaniciEkle_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(31, 250);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 15);
            this.label7.TabIndex = 13;
            this.label7.Text = "Address : ";
            // 
            // txtKullaniciAdres
            // 
            this.txtKullaniciAdres.Location = new System.Drawing.Point(151, 249);
            this.txtKullaniciAdres.Name = "txtKullaniciAdres";
            this.txtKullaniciAdres.Size = new System.Drawing.Size(186, 20);
            this.txtKullaniciAdres.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(31, 224);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(115, 15);
            this.label6.TabIndex = 11;
            this.label6.Text = "Phone Number : ";
            // 
            // txtKullaniciTelefon
            // 
            this.txtKullaniciTelefon.Location = new System.Drawing.Point(151, 223);
            this.txtKullaniciTelefon.Name = "txtKullaniciTelefon";
            this.txtKullaniciTelefon.Size = new System.Drawing.Size(186, 20);
            this.txtKullaniciTelefon.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(31, 198);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 15);
            this.label5.TabIndex = 9;
            this.label5.Text = "Surname : ";
            // 
            // txtKullaniciSoyadi
            // 
            this.txtKullaniciSoyadi.Location = new System.Drawing.Point(151, 197);
            this.txtKullaniciSoyadi.Name = "txtKullaniciSoyadi";
            this.txtKullaniciSoyadi.Size = new System.Drawing.Size(186, 20);
            this.txtKullaniciSoyadi.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(31, 172);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 15);
            this.label4.TabIndex = 7;
            this.label4.Text = "Name : ";
            // 
            // txtKullaniciAdi
            // 
            this.txtKullaniciAdi.Location = new System.Drawing.Point(151, 171);
            this.txtKullaniciAdi.Name = "txtKullaniciAdi";
            this.txtKullaniciAdi.Size = new System.Drawing.Size(186, 20);
            this.txtKullaniciAdi.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(31, 146);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "Password : ";
            // 
            // txtKullaniciSifre
            // 
            this.txtKullaniciSifre.Location = new System.Drawing.Point(151, 145);
            this.txtKullaniciSifre.Name = "txtKullaniciSifre";
            this.txtKullaniciSifre.Size = new System.Drawing.Size(186, 20);
            this.txtKullaniciSifre.TabIndex = 4;
            this.txtKullaniciSifre.UseSystemPasswordChar = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(31, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Username : ";
            // 
            // txtKullaniciKulAdi
            // 
            this.txtKullaniciKulAdi.Location = new System.Drawing.Point(151, 119);
            this.txtKullaniciKulAdi.Name = "txtKullaniciKulAdi";
            this.txtKullaniciKulAdi.Size = new System.Drawing.Size(186, 20);
            this.txtKullaniciKulAdi.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(31, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Tc ID : ";
            // 
            // txtKullaniciTC
            // 
            this.txtKullaniciTC.Location = new System.Drawing.Point(151, 93);
            this.txtKullaniciTC.Name = "txtKullaniciTC";
            this.txtKullaniciTC.Size = new System.Drawing.Size(186, 20);
            this.txtKullaniciTC.TabIndex = 0;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label20.Location = new System.Drawing.Point(338, 31);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(84, 25);
            this.label20.TabIndex = 0;
            this.label20.Text = "MENUS";
            // 
            // panelRestoranIci
            // 
            this.panelRestoranIci.Controls.Add(this.btnSepettenCikar);
            this.panelRestoranIci.Controls.Add(this.btnSiparisVer);
            this.panelRestoranIci.Controls.Add(this.checkedListBoxSepet);
            this.panelRestoranIci.Controls.Add(this.txtRestoranIciToplamUcret);
            this.panelRestoranIci.Controls.Add(this.btnCikisMenuler);
            this.panelRestoranIci.Controls.Add(this.label20);
            this.panelRestoranIci.Location = new System.Drawing.Point(12, 12);
            this.panelRestoranIci.Name = "panelRestoranIci";
            this.panelRestoranIci.Size = new System.Drawing.Size(776, 426);
            this.panelRestoranIci.TabIndex = 4;
            // 
            // btnSepettenCikar
            // 
            this.btnSepettenCikar.Location = new System.Drawing.Point(590, 342);
            this.btnSepettenCikar.Name = "btnSepettenCikar";
            this.btnSepettenCikar.Size = new System.Drawing.Size(176, 23);
            this.btnSepettenCikar.TabIndex = 6;
            this.btnSepettenCikar.Text = "Remove selected menus from cart";
            this.btnSepettenCikar.UseVisualStyleBackColor = true;
            this.btnSepettenCikar.Click += new System.EventHandler(this.btnSepettenCikar_Click);
            // 
            // btnSiparisVer
            // 
            this.btnSiparisVer.Location = new System.Drawing.Point(590, 371);
            this.btnSiparisVer.Name = "btnSiparisVer";
            this.btnSiparisVer.Size = new System.Drawing.Size(176, 23);
            this.btnSiparisVer.TabIndex = 5;
            this.btnSiparisVer.Text = "Order";
            this.btnSiparisVer.UseVisualStyleBackColor = true;
            this.btnSiparisVer.Click += new System.EventHandler(this.btnSiparisVer_Click);
            // 
            // checkedListBoxSepet
            // 
            this.checkedListBoxSepet.FormattingEnabled = true;
            this.checkedListBoxSepet.Location = new System.Drawing.Point(590, 63);
            this.checkedListBoxSepet.Name = "checkedListBoxSepet";
            this.checkedListBoxSepet.Size = new System.Drawing.Size(176, 244);
            this.checkedListBoxSepet.TabIndex = 4;
            // 
            // txtRestoranIciToplamUcret
            // 
            this.txtRestoranIciToplamUcret.Location = new System.Drawing.Point(591, 316);
            this.txtRestoranIciToplamUcret.Name = "txtRestoranIciToplamUcret";
            this.txtRestoranIciToplamUcret.ReadOnly = true;
            this.txtRestoranIciToplamUcret.Size = new System.Drawing.Size(176, 20);
            this.txtRestoranIciToplamUcret.TabIndex = 3;
            this.txtRestoranIciToplamUcret.Text = "0";
            // 
            // btnCikisMenuler
            // 
            this.btnCikisMenuler.Location = new System.Drawing.Point(691, 400);
            this.btnCikisMenuler.Name = "btnCikisMenuler";
            this.btnCikisMenuler.Size = new System.Drawing.Size(75, 23);
            this.btnCikisMenuler.TabIndex = 1;
            this.btnCikisMenuler.Text = "Logout";
            this.btnCikisMenuler.UseVisualStyleBackColor = true;
            this.btnCikisMenuler.Click += new System.EventHandler(this.btnCikisMenuler_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelRestoranEkrani);
            this.Controls.Add(this.panelKullaniciEkrani);
            this.Controls.Add(this.panelKayitOl);
            this.Controls.Add(this.panelGirisEkrani);
            this.Controls.Add(this.panelRestoranIci);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(820, 493);
            this.MinimumSize = new System.Drawing.Size(820, 493);
            this.Name = "Form1";
            this.Text = "Food Ordering System";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelGirisEkrani.ResumeLayout(false);
            this.panelGirisEkrani.PerformLayout();
            this.panelKullaniciEkrani.ResumeLayout(false);
            this.panelKullaniciEkrani.PerformLayout();
            this.panelRestoranEkrani.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRestoranMenuler)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSiparisler)).EndInit();
            this.panelKayitOl.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panelRestoranIci.ResumeLayout(false);
            this.panelRestoranIci.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelGirisEkrani;
        private System.Windows.Forms.Panel panelKullaniciEkrani;
        private System.Windows.Forms.Panel panelRestoranEkrani;
        private System.Windows.Forms.Panel panelKayitOl;
        private System.Windows.Forms.Button btnGirisRestoran;
        private System.Windows.Forms.TextBox txtGirisSifre;
        private System.Windows.Forms.TextBox txtGirisKullaniciAdi;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnGirisKullanici;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtRestoranSifre;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtRestoranKulAdi;
        private System.Windows.Forms.Button btnRestoranEkle;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtRestoranTelefon;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtRestoranAdi;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnKullaniciEkle;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtKullaniciAdres;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtKullaniciTelefon;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtKullaniciSoyadi;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtKullaniciAdi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtKullaniciSifre;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtKullaniciKulAdi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtKullaniciTC;
        private System.Windows.Forms.LinkLabel linkLabelKayitOl;
        private System.Windows.Forms.LinkLabel linkLabelKayitOlGeriDon;
        private System.Windows.Forms.DataGridView dataGridViewSiparisler;
        private System.Windows.Forms.Button btnKullaniciCikis;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnRestoranSiparisGuncelle;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox comboBoxRestoranSiparisDurumu;
        private System.Windows.Forms.ComboBox comboBoxRestoranSiparis;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnRestoranMenuEkle;
        private System.Windows.Forms.TextBox txtRestoranMenuFiyati;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtRestoranMenuAdi;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnRestoranMenuGuncelle;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.DataGridView dataGridViewRestoranMenuler;
        private System.Windows.Forms.Button btnRestoranMenuSil;
        private System.Windows.Forms.TextBox txtRestoranGuncelleMenuFiyati;
        private System.Windows.Forms.TextBox txtRestoranGuncelleMenuAdi;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panelRestoranIci;
        private System.Windows.Forms.Button btnRestoranCikis;
        private System.Windows.Forms.Button btnCikisMenuler;
        private System.Windows.Forms.Button btnSepettenCikar;
        private System.Windows.Forms.Button btnSiparisVer;
        private System.Windows.Forms.CheckedListBox checkedListBoxSepet;
        private System.Windows.Forms.TextBox txtRestoranIciToplamUcret;
        private System.Windows.Forms.Label label21;
    }
}

