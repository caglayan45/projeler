﻿namespace AltinToplamaOyunu
{
    partial class altinToplamaOyunu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panelOyun = new System.Windows.Forms.Panel();
            this.labelOyunAdi = new System.Windows.Forms.Label();
            this.numericMDegeri = new System.Windows.Forms.NumericUpDown();
            this.numericNDegeri = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonOyunBaslat = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.numericBaslangicAltin = new System.Windows.Forms.NumericUpDown();
            this.numericHamleHakki = new System.Windows.Forms.NumericUpDown();
            this.numericGizliAltinOrani = new System.Windows.Forms.NumericUpDown();
            this.numericAltinOrani = new System.Windows.Forms.NumericUpDown();
            this.numericB_Hedef = new System.Windows.Forms.NumericUpDown();
            this.numericB_Hamle = new System.Windows.Forms.NumericUpDown();
            this.numericA_Hedef = new System.Windows.Forms.NumericUpDown();
            this.numericA_Hamle = new System.Windows.Forms.NumericUpDown();
            this.numericD_Hedef = new System.Windows.Forms.NumericUpDown();
            this.numericD_Hamle = new System.Windows.Forms.NumericUpDown();
            this.numericC_Hedef = new System.Windows.Forms.NumericUpDown();
            this.numericC_Hamle = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.panelGiris = new System.Windows.Forms.Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.labelOyuncuA = new System.Windows.Forms.Label();
            this.panelLog = new System.Windows.Forms.Panel();
            this.labelOyuncuB = new System.Windows.Forms.Label();
            this.labelOyuncuD = new System.Windows.Forms.Label();
            this.labelOyuncuC = new System.Windows.Forms.Label();
            this.listBoxLogEkrani = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericMDegeri)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericNDegeri)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericBaslangicAltin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericHamleHakki)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericGizliAltinOrani)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericAltinOrani)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericB_Hedef)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericB_Hamle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericA_Hedef)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericA_Hamle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericD_Hedef)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericD_Hamle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericC_Hedef)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericC_Hamle)).BeginInit();
            this.panelGiris.SuspendLayout();
            this.panelLog.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelOyun
            // 
            this.panelOyun.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panelOyun.BackColor = System.Drawing.Color.Transparent;
            this.panelOyun.Location = new System.Drawing.Point(0, 0);
            this.panelOyun.Name = "panelOyun";
            this.panelOyun.Size = new System.Drawing.Size(1010, 1010);
            this.panelOyun.TabIndex = 1;
            // 
            // labelOyunAdi
            // 
            this.labelOyunAdi.AutoSize = true;
            this.labelOyunAdi.Font = new System.Drawing.Font("Segoe Script", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelOyunAdi.Location = new System.Drawing.Point(282, 262);
            this.labelOyunAdi.Name = "labelOyunAdi";
            this.labelOyunAdi.Size = new System.Drawing.Size(374, 61);
            this.labelOyunAdi.TabIndex = 0;
            this.labelOyunAdi.Text = "ALTIN TOPLAMA";
            // 
            // numericMDegeri
            // 
            this.numericMDegeri.Location = new System.Drawing.Point(426, 340);
            this.numericMDegeri.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericMDegeri.Name = "numericMDegeri";
            this.numericMDegeri.Size = new System.Drawing.Size(40, 20);
            this.numericMDegeri.TabIndex = 5;
            this.numericMDegeri.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericMDegeri.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // numericNDegeri
            // 
            this.numericNDegeri.Location = new System.Drawing.Point(426, 375);
            this.numericNDegeri.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericNDegeri.Name = "numericNDegeri";
            this.numericNDegeri.Size = new System.Drawing.Size(40, 20);
            this.numericNDegeri.TabIndex = 6;
            this.numericNDegeri.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericNDegeri.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(248, 340);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 20);
            this.label1.TabIndex = 7;
            this.label1.Text = "M -";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(248, 375);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 20);
            this.label2.TabIndex = 8;
            this.label2.Text = "N -";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // buttonOyunBaslat
            // 
            this.buttonOyunBaslat.Location = new System.Drawing.Point(449, 632);
            this.buttonOyunBaslat.Name = "buttonOyunBaslat";
            this.buttonOyunBaslat.Size = new System.Drawing.Size(92, 20);
            this.buttonOyunBaslat.TabIndex = 9;
            this.buttonOyunBaslat.Text = "Oyunu Başlat";
            this.buttonOyunBaslat.UseVisualStyleBackColor = true;
            this.buttonOyunBaslat.Click += new System.EventHandler(this.buttonOyunBaslat_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(248, 410);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 20);
            this.label3.TabIndex = 12;
            this.label3.Text = "Altın Oranı -";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(248, 445);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 20);
            this.label4.TabIndex = 13;
            this.label4.Text = "Gizli Altın Oranı -";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(248, 480);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 20);
            this.label5.TabIndex = 14;
            this.label5.Text = "Hamle Hakkı -";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(248, 515);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(172, 20);
            this.label8.TabIndex = 16;
            this.label8.Text = "Başlangıç Altın Miktarı -";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(511, 340);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(193, 20);
            this.label7.TabIndex = 17;
            this.label7.Text = "A Oyuncu Hamle Maliyeti -";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.Location = new System.Drawing.Point(511, 375);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(191, 20);
            this.label9.TabIndex = 19;
            this.label9.Text = "A Oyuncu Hedef Maliyeti -";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.Location = new System.Drawing.Point(511, 410);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(193, 20);
            this.label11.TabIndex = 20;
            this.label11.Text = "B Oyuncu Hamle Maliyeti -";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.Location = new System.Drawing.Point(511, 445);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(191, 20);
            this.label10.TabIndex = 21;
            this.label10.Text = "B Oyuncu Hedef Maliyeti -";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label15.Location = new System.Drawing.Point(511, 480);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(193, 20);
            this.label15.TabIndex = 22;
            this.label15.Text = "C Oyuncu Hamle Maliyeti -";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.Location = new System.Drawing.Point(511, 515);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(191, 20);
            this.label14.TabIndex = 23;
            this.label14.Text = "C Oyuncu Hedef Maliyeti -";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.Location = new System.Drawing.Point(511, 550);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(194, 20);
            this.label13.TabIndex = 24;
            this.label13.Text = "D Oyuncu Hamle Maliyeti -";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.Location = new System.Drawing.Point(511, 585);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(192, 20);
            this.label12.TabIndex = 25;
            this.label12.Text = "D Oyuncu Hedef Maliyeti -";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // numericBaslangicAltin
            // 
            this.numericBaslangicAltin.Location = new System.Drawing.Point(426, 515);
            this.numericBaslangicAltin.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericBaslangicAltin.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericBaslangicAltin.Name = "numericBaslangicAltin";
            this.numericBaslangicAltin.Size = new System.Drawing.Size(40, 20);
            this.numericBaslangicAltin.TabIndex = 26;
            this.numericBaslangicAltin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericBaslangicAltin.Value = new decimal(new int[] {
            200,
            0,
            0,
            0});
            // 
            // numericHamleHakki
            // 
            this.numericHamleHakki.Location = new System.Drawing.Point(426, 480);
            this.numericHamleHakki.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericHamleHakki.Name = "numericHamleHakki";
            this.numericHamleHakki.Size = new System.Drawing.Size(40, 20);
            this.numericHamleHakki.TabIndex = 27;
            this.numericHamleHakki.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericHamleHakki.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // numericGizliAltinOrani
            // 
            this.numericGizliAltinOrani.Location = new System.Drawing.Point(426, 445);
            this.numericGizliAltinOrani.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericGizliAltinOrani.Name = "numericGizliAltinOrani";
            this.numericGizliAltinOrani.Size = new System.Drawing.Size(40, 20);
            this.numericGizliAltinOrani.TabIndex = 28;
            this.numericGizliAltinOrani.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericGizliAltinOrani.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // numericAltinOrani
            // 
            this.numericAltinOrani.Location = new System.Drawing.Point(426, 410);
            this.numericAltinOrani.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericAltinOrani.Name = "numericAltinOrani";
            this.numericAltinOrani.Size = new System.Drawing.Size(40, 20);
            this.numericAltinOrani.TabIndex = 29;
            this.numericAltinOrani.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericAltinOrani.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // numericB_Hedef
            // 
            this.numericB_Hedef.Location = new System.Drawing.Point(710, 445);
            this.numericB_Hedef.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericB_Hedef.Name = "numericB_Hedef";
            this.numericB_Hedef.Size = new System.Drawing.Size(40, 20);
            this.numericB_Hedef.TabIndex = 30;
            this.numericB_Hedef.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericB_Hedef.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // numericB_Hamle
            // 
            this.numericB_Hamle.Location = new System.Drawing.Point(710, 410);
            this.numericB_Hamle.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericB_Hamle.Name = "numericB_Hamle";
            this.numericB_Hamle.Size = new System.Drawing.Size(40, 20);
            this.numericB_Hamle.TabIndex = 31;
            this.numericB_Hamle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericB_Hamle.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // numericA_Hedef
            // 
            this.numericA_Hedef.Location = new System.Drawing.Point(710, 375);
            this.numericA_Hedef.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericA_Hedef.Name = "numericA_Hedef";
            this.numericA_Hedef.Size = new System.Drawing.Size(40, 20);
            this.numericA_Hedef.TabIndex = 32;
            this.numericA_Hedef.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericA_Hedef.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // numericA_Hamle
            // 
            this.numericA_Hamle.Location = new System.Drawing.Point(710, 340);
            this.numericA_Hamle.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericA_Hamle.Name = "numericA_Hamle";
            this.numericA_Hamle.Size = new System.Drawing.Size(40, 20);
            this.numericA_Hamle.TabIndex = 33;
            this.numericA_Hamle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericA_Hamle.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // numericD_Hedef
            // 
            this.numericD_Hedef.Location = new System.Drawing.Point(710, 585);
            this.numericD_Hedef.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericD_Hedef.Name = "numericD_Hedef";
            this.numericD_Hedef.Size = new System.Drawing.Size(40, 20);
            this.numericD_Hedef.TabIndex = 34;
            this.numericD_Hedef.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericD_Hedef.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // numericD_Hamle
            // 
            this.numericD_Hamle.Location = new System.Drawing.Point(710, 550);
            this.numericD_Hamle.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericD_Hamle.Name = "numericD_Hamle";
            this.numericD_Hamle.Size = new System.Drawing.Size(40, 20);
            this.numericD_Hamle.TabIndex = 35;
            this.numericD_Hamle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericD_Hamle.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // numericC_Hedef
            // 
            this.numericC_Hedef.Location = new System.Drawing.Point(710, 515);
            this.numericC_Hedef.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericC_Hedef.Name = "numericC_Hedef";
            this.numericC_Hedef.Size = new System.Drawing.Size(40, 20);
            this.numericC_Hedef.TabIndex = 36;
            this.numericC_Hedef.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericC_Hedef.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // numericC_Hamle
            // 
            this.numericC_Hamle.Location = new System.Drawing.Point(710, 480);
            this.numericC_Hamle.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericC_Hamle.Name = "numericC_Hamle";
            this.numericC_Hamle.Size = new System.Drawing.Size(40, 20);
            this.numericC_Hamle.TabIndex = 37;
            this.numericC_Hamle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericC_Hamle.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(249, 535);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 13);
            this.label6.TabIndex = 38;
            this.label6.Text = "(oyuncu)";
            // 
            // panelGiris
            // 
            this.panelGiris.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panelGiris.Controls.Add(this.label6);
            this.panelGiris.Controls.Add(this.numericC_Hamle);
            this.panelGiris.Controls.Add(this.numericC_Hedef);
            this.panelGiris.Controls.Add(this.numericD_Hamle);
            this.panelGiris.Controls.Add(this.numericD_Hedef);
            this.panelGiris.Controls.Add(this.numericA_Hamle);
            this.panelGiris.Controls.Add(this.numericA_Hedef);
            this.panelGiris.Controls.Add(this.numericB_Hamle);
            this.panelGiris.Controls.Add(this.numericB_Hedef);
            this.panelGiris.Controls.Add(this.numericAltinOrani);
            this.panelGiris.Controls.Add(this.numericGizliAltinOrani);
            this.panelGiris.Controls.Add(this.numericHamleHakki);
            this.panelGiris.Controls.Add(this.numericBaslangicAltin);
            this.panelGiris.Controls.Add(this.label12);
            this.panelGiris.Controls.Add(this.label13);
            this.panelGiris.Controls.Add(this.label14);
            this.panelGiris.Controls.Add(this.label15);
            this.panelGiris.Controls.Add(this.label10);
            this.panelGiris.Controls.Add(this.label11);
            this.panelGiris.Controls.Add(this.label9);
            this.panelGiris.Controls.Add(this.label7);
            this.panelGiris.Controls.Add(this.label8);
            this.panelGiris.Controls.Add(this.label5);
            this.panelGiris.Controls.Add(this.label4);
            this.panelGiris.Controls.Add(this.label3);
            this.panelGiris.Controls.Add(this.buttonOyunBaslat);
            this.panelGiris.Controls.Add(this.label2);
            this.panelGiris.Controls.Add(this.label1);
            this.panelGiris.Controls.Add(this.numericNDegeri);
            this.panelGiris.Controls.Add(this.numericMDegeri);
            this.panelGiris.Controls.Add(this.labelOyunAdi);
            this.panelGiris.Location = new System.Drawing.Point(0, 0);
            this.panelGiris.Name = "panelGiris";
            this.panelGiris.Size = new System.Drawing.Size(1010, 980);
            this.panelGiris.TabIndex = 0;
            // 
            // timer1
            // 
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick_1);
            // 
            // labelOyuncuA
            // 
            this.labelOyuncuA.AutoSize = true;
            this.labelOyuncuA.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelOyuncuA.ForeColor = System.Drawing.Color.Blue;
            this.labelOyuncuA.Location = new System.Drawing.Point(3, 9);
            this.labelOyuncuA.Name = "labelOyuncuA";
            this.labelOyuncuA.Size = new System.Drawing.Size(95, 18);
            this.labelOyuncuA.TabIndex = 0;
            this.labelOyuncuA.Text = "Oyuncu A : ";
            // 
            // panelLog
            // 
            this.panelLog.Controls.Add(this.listBoxLogEkrani);
            this.panelLog.Controls.Add(this.labelOyuncuC);
            this.panelLog.Controls.Add(this.labelOyuncuD);
            this.panelLog.Controls.Add(this.labelOyuncuB);
            this.panelLog.Controls.Add(this.labelOyuncuA);
            this.panelLog.Location = new System.Drawing.Point(1016, 0);
            this.panelLog.Name = "panelLog";
            this.panelLog.Size = new System.Drawing.Size(290, 1010);
            this.panelLog.TabIndex = 2;
            // 
            // labelOyuncuB
            // 
            this.labelOyuncuB.AutoSize = true;
            this.labelOyuncuB.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelOyuncuB.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.labelOyuncuB.Location = new System.Drawing.Point(145, 9);
            this.labelOyuncuB.Name = "labelOyuncuB";
            this.labelOyuncuB.Size = new System.Drawing.Size(96, 18);
            this.labelOyuncuB.TabIndex = 1;
            this.labelOyuncuB.Text = "Oyuncu B : ";
            // 
            // labelOyuncuD
            // 
            this.labelOyuncuD.AutoSize = true;
            this.labelOyuncuD.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelOyuncuD.ForeColor = System.Drawing.Color.Gold;
            this.labelOyuncuD.Location = new System.Drawing.Point(145, 48);
            this.labelOyuncuD.Name = "labelOyuncuD";
            this.labelOyuncuD.Size = new System.Drawing.Size(97, 18);
            this.labelOyuncuD.TabIndex = 2;
            this.labelOyuncuD.Text = "Oyuncu D : ";
            // 
            // labelOyuncuC
            // 
            this.labelOyuncuC.AutoSize = true;
            this.labelOyuncuC.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelOyuncuC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.labelOyuncuC.Location = new System.Drawing.Point(3, 48);
            this.labelOyuncuC.Name = "labelOyuncuC";
            this.labelOyuncuC.Size = new System.Drawing.Size(97, 18);
            this.labelOyuncuC.TabIndex = 3;
            this.labelOyuncuC.Text = "Oyuncu C : ";
            // 
            // listBoxLogEkrani
            // 
            this.listBoxLogEkrani.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.listBoxLogEkrani.FormattingEnabled = true;
            this.listBoxLogEkrani.ItemHeight = 16;
            this.listBoxLogEkrani.Location = new System.Drawing.Point(6, 77);
            this.listBoxLogEkrani.Name = "listBoxLogEkrani";
            this.listBoxLogEkrani.Size = new System.Drawing.Size(274, 916);
            this.listBoxLogEkrani.TabIndex = 4;
            // 
            // altinToplamaOyunu
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1308, 1011);
            this.Controls.Add(this.panelLog);
            this.Controls.Add(this.panelGiris);
            this.Controls.Add(this.panelOyun);
            this.MaximumSize = new System.Drawing.Size(1324, 1050);
            this.MinimumSize = new System.Drawing.Size(750, 726);
            this.Name = "altinToplamaOyunu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Altın Toplama Oyunu";
            this.Load += new System.EventHandler(this.altinToplamaOyunu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericMDegeri)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericNDegeri)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericBaslangicAltin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericHamleHakki)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericGizliAltinOrani)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericAltinOrani)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericB_Hedef)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericB_Hamle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericA_Hedef)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericA_Hamle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericD_Hedef)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericD_Hamle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericC_Hedef)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericC_Hamle)).EndInit();
            this.panelGiris.ResumeLayout(false);
            this.panelGiris.PerformLayout();
            this.panelLog.ResumeLayout(false);
            this.panelLog.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panelOyun;
        private System.Windows.Forms.Label labelOyunAdi;
        private System.Windows.Forms.NumericUpDown numericMDegeri;
        private System.Windows.Forms.NumericUpDown numericNDegeri;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonOyunBaslat;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown numericBaslangicAltin;
        private System.Windows.Forms.NumericUpDown numericHamleHakki;
        private System.Windows.Forms.NumericUpDown numericGizliAltinOrani;
        private System.Windows.Forms.NumericUpDown numericAltinOrani;
        private System.Windows.Forms.NumericUpDown numericB_Hedef;
        private System.Windows.Forms.NumericUpDown numericB_Hamle;
        private System.Windows.Forms.NumericUpDown numericA_Hedef;
        private System.Windows.Forms.NumericUpDown numericA_Hamle;
        private System.Windows.Forms.NumericUpDown numericD_Hedef;
        private System.Windows.Forms.NumericUpDown numericD_Hamle;
        private System.Windows.Forms.NumericUpDown numericC_Hedef;
        private System.Windows.Forms.NumericUpDown numericC_Hamle;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panelGiris;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label labelOyuncuA;
        private System.Windows.Forms.Panel panelLog;
        private System.Windows.Forms.Label labelOyuncuC;
        private System.Windows.Forms.Label labelOyuncuD;
        private System.Windows.Forms.Label labelOyuncuB;
        private System.Windows.Forms.ListBox listBoxLogEkrani;
    }
}

