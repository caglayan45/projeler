/**
* Node.hpp
* Avl ağacının düğümlerinin başlık dosyası
* Yaz okulu 
* Final ödevi
* 22/08/2020
* Yavuz KAYA
*/
#ifndef NODE_HPP
#define NODE_HPP
#include <cstddef>
#include <iostream>
#include "Yigin.hpp"

using namespace std;

struct node{
	public:
		string data;
		string isim;
        int yas;
        int kilo;
        node *left;
        node *right;
		yigin *root;
		int yukseklik;
		int denge;
};

class Node{
	public:
		Node();
		static node *Ekle(node*,string,string,int,int);
		static int Yukseklik(node*);
		static int YukseklikDenge(node*);
		static int DengeFaktoru(node*);
		static int Buyuk(int,int);
		static node *IlkKisi(string,string,int,int);
		static node *SolaDondur(node*);
		static node *SagaDondur(node*);
		static void PostOrder(node*);
		static void ElemanSayisi(int);
		static void PostOrderDengeler(node*);
		static void yazdir();
		static void DengeDuzenle(node*);
		static void Sifirla();
		static void DugumSayisi(int);
		static void OncekiDugumSayisi(int);
		static void YiginaEkle(node*);
};

#endif