/**
* Yigin.hpp
* Yığının bulunduğu başlık dosyası.
* Yaz okulu 
* Final ödevi
* 25/08/2020
* Yavuz KAYA
*/
#ifndef YIGIN_HPP
#define YIGIN_HPP
#include <cstddef>
#include <iostream>

using namespace std;

struct yigin{
	public:
        char data;
        yigin *next; 
};

class Yigin{
	public:
		Yigin();
		static yigin* Push(yigin*,char);
		static void Pop(yigin*);
		static void ShowStack(yigin*);
};

#endif